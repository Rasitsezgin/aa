# Çocuk Şarkı MV Stüdyosu

MP3/WAV/FLAC şarkını ve sözlerini yükle → sahne planı → video sahneleri → FFmpeg ile birleştirme
(final ses = senin şarkın) → SRT altyazı → thumbnail → YouTube paketi → **final.mp4**.

Tarayıcı otomasyonu, Chrome, X11 veya Playwright **gerekmez**. Başsız (headless) Ubuntu VPS'te çalışır.

## 1. Kurulum (Ubuntu 22.04 / 24.04)

```bash
# Gerekli paketler
sudo apt update
sudo apt install -y ffmpeg fonts-dejavu-core curl nginx
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
sudo npm install -g pm2

# Projeyi kopyaladığınız klasörde
cd cocuk-sarki-mv
npm install --omit=dev
cp .env.example .env
nano .env        # ADMIN_PASSWORD'ü mutlaka değiştirin, API anahtarlarını girin

# Çalıştır
pm2 start ecosystem.config.js
pm2 save && pm2 startup     # sunucu yeniden başlayınca otomatik açılır
```

Uygulama `127.0.0.1:3000` üzerinde dinler (dışarıya doğrudan açık değildir).

## 2. Alan adı + HTTPS (nginx)

```bash
sudo cp nginx.conf.example /etc/nginx/sites-available/cocuk-sarki
sudo nano /etc/nginx/sites-available/cocuk-sarki     # server_name'i düzenleyin
sudo ln -s /etc/nginx/sites-available/cocuk-sarki /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
sudo apt install -y certbot python3-certbot-nginx && sudo certbot --nginx -d ORNEK.ALANADI.COM
```

**Önemli:** Giriş, tarayıcının kullanıcı adı/şifre penceresiyle yapılır. Şifre açık gönderildiği için
mutlaka HTTPS (certbot) kullanın.

## 3. Ortam değişkenleri (.env)

| Değişken | Zorunlu | Açıklama |
|---|---|---|
| `ADMIN_USER` | Hayır (varsayılan `admin`) | Giriş kullanıcı adı |
| `ADMIN_PASSWORD` | **Evet** | Giriş şifresi (yoksa uygulama açılmaz) |
| `PORT` | Hayır (3000) | Dinlenen port |
| `MAX_UPLOAD_MB` | Hayır (100) | En büyük şarkı dosyası |
| `CONCURRENCY` | Hayır (2) | Aynı anda üretilen sahne sayısı |
| `PROJECTS_DIR` | Hayır | Proje dosyalarının klasörü (varsayılan `./projects`) |
| `OPENAI_API_KEY` | Hayır | Akıllı sahne planı, altyazı çevirisi, yayın paketi. Yoksa basit şablon çalışır |
| `OPENAI_MODEL` | Hayır | Varsayılan `gpt-4o-mini` |
| `GOOGLE_AI_API_KEY` | Hayır | Google Veo ile video üretimi |
| `VEO_MODEL` | Hayır | Varsayılan `veo-3.0-fast-generate-001` |
| `LUMA_API_KEY` | Hayır | Luma ile video üretimi |
| `LUMA_MODEL` | Hayır | Varsayılan `ray-2` |
| `SUNO_API_KEY` | Hayır | Şimdilik kullanılmıyor |

Hiçbir video anahtarı yoksa **Demo Modu** çalışır (renkli sahte sahneler, ücretsiz): tüm hattı denemek için idealdir.

## 4. Kullanım

1. **Yeni Proje** → şarkıyı yükle, sözleri yapıştır, stil/karakter/ayarları seç.
2. **Sahne Planı** → “Analiz Et ve Sahne Planı Oluştur”. İstemleri düzenle, sahneleri çoğalt/sil/taşı.
3. **Planı Onayla ve Videoyu Üret** → maliyet uyarısını onayla; ilerlemeyi izle. Başarısız sahneler tek tek yeniden denenebilir.
4. **Final Videoyu Oluştur** → tüm sahneler hazırsa birleştirir, şarkını ses olarak ekler.
5. **Altyazılar**, **Thumbnail**, **Yayın Planlayıcı** sekmelerinden paketi tamamla; **Çıktılar**'dan indir.

## 5. Sık sorunlar

- **“FFmpeg çalıştırılamadı”** → `sudo apt install ffmpeg`
- **Thumbnail'de yazı yok** → `sudo apt install fonts-dejavu-core`
- **“Bu sağlayıcı için API anahtarı eksik.”** → `.env` içine anahtarı yazıp `pm2 restart cocuk-sarki-mv`
- **Yükleme 413 hatası** → nginx'te `client_max_body_size` değerini artırın
- Kontrol: `curl http://127.0.0.1:3000/healthz` → `{"ok":true}` ; loglar: `pm2 logs cocuk-sarki-mv`

## 6. Notlar

- Proje verisi `projects/<id>/` altında JSON + dosya olarak saklanır (veritabanı/Redis kurulumu yok). Yedek için bu klasörü kopyalayın.
- İşler sunucu içinde arka planda çalışır; sunucu yeniden başlarsa tamamlanan sahneler korunur, yarım kalan üretim otomatik devam eder.
- Söz zamanlaması, satır uzunluğuna göre **tahminidir** (ses analizi yapılmaz). Altyazıları sekmeden düzenleyebilirsiniz.
- Veo ve Luma adaptörleri gerçek API'lere göre yazıldı ancak sizin anahtarlarınızla canlı test edilmedi; ilk denemede tek sahne üretmenizi öneririz. Model adları değişirse `.env` içindeki `VEO_MODEL` / `LUMA_MODEL` ile güncelleyin.
- Yeni sağlayıcı (ör. Runway) eklemek için `server.js` içindeki `PROVIDERS` nesnesine `submit / status / download` fonksiyonlarını yazmak yeterlidir.
