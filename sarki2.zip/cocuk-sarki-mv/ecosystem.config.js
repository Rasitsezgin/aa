module.exports = { apps: [{ name: 'cocuk-sarki-mv', script: 'server.js', max_memory_restart: '800M', autorestart: true }] };
