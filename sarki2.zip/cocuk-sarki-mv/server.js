'use strict';
// Çocuk Şarkı MV Stüdyosu - tek dosyalık, bağımlılığı az sunucu (Express + FFmpeg)
const fs = require('fs'), path = require('path'), os = require('os'), crypto = require('crypto');
const { spawn } = require('child_process');
try { // .env okuyucu (ek paket gerekmez)
  for (const l of fs.readFileSync(path.join(__dirname, '.env'), 'utf8').split('\n')) {
    const m = l.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (m && !(m[1] in process.env)) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
} catch {}
const express = require('express'), multer = require('multer');

const PORT = +process.env.PORT || 3000;
const ROOT = path.resolve(process.env.PROJECTS_DIR || path.join(__dirname, 'projects'));
const FONT = [process.env.FONT_FILE, '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', '/usr/share/fonts/dejavu/DejaVuSans-Bold.ttf']
  .find(f => f && fs.existsSync(f));
if (!process.env.ADMIN_PASSWORD) { console.error('HATA: .env dosyasında ADMIN_PASSWORD tanımlanmalı.'); process.exit(1); }
fs.mkdirSync(ROOT, { recursive: true });

const httpErr = (s, m, d) => Object.assign(new Error(m), { status: s, detail: d });
const sleep = ms => new Promise(r => setTimeout(r, ms));
const pad = n => String(n).padStart(2, '0');

// ---------- Komut çalıştırma (shell yok, argüman dizisi) ----------
function run(cmd, args, opts = {}) {
  return new Promise((res, rej) => {
    let out = '', err = '';
    const p = spawn(cmd, args, opts);
    p.stdout.on('data', d => out = (out + d).slice(-20000));
    p.stderr.on('data', d => err = (err + d).slice(-4000));
    p.on('error', e => rej(httpErr(500, cmd + ' çalıştırılamadı. Kurulu olduğundan emin olun.', e.message)));
    p.on('close', c => c === 0 ? res(out) : rej(httpErr(500, cmd + ' işlemi başarısız oldu.', err)));
  });
}
const ffmpeg = (args, cwd) => run('ffmpeg', ['-y', '-hide_banner', '-loglevel', 'error', ...args], { cwd });
async function probeDuration(file) {
  const o = await run('ffprobe', ['-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', file]);
  const d = parseFloat(o); return isFinite(d) ? d : 0;
}

// ---------- Proje depolama (JSON dosyaları, bellekte önbellek) ----------
const cache = new Map();
const pdir = id => path.join(ROOT, id);
const validId = id => /^[a-f0-9]{12}$/.test(id);
function load(id) {
  if (!validId(id)) throw httpErr(404, 'Proje bulunamadı.');
  if (cache.has(id)) return cache.get(id);
  try { const p = JSON.parse(fs.readFileSync(path.join(pdir(id), 'project.json'), 'utf8')); cache.set(id, p); return p; }
  catch { throw httpErr(404, 'Proje bulunamadı.'); }
}
function save(p) { p.updatedAt = new Date().toISOString(); fs.writeFileSync(path.join(pdir(p.id), 'project.json'), JSON.stringify(p, null, 1)); }
const listProjects = () => fs.readdirSync(ROOT).filter(validId).filter(id => fs.existsSync(path.join(pdir(id), 'project.json'))).map(load)
  .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
const wr = (p, rel, data) => fs.writeFileSync(path.join(pdir(p.id), rel), typeof data === 'string' ? data : JSON.stringify(data, null, 2));

// ---------- Boyutlar ve stiller ----------
function dims(aspect, res) {
  const s = res === '720p' ? 720 : 1080, e = v => Math.round(v / 2) * 2;
  return aspect === '9:16' ? [s, e(s * 16 / 9)] : aspect === '1:1' ? [s, s] : [e(s * 16 / 9), s];
}
const STYLES = {
  '3d': '3D animated children\'s cartoon, soft rounded shapes, vibrant colors, family-friendly',
  '2d': '2D hand-drawn children\'s cartoon, bold outlines, flat bright colors',
  'pixar': 'high-quality family 3D animation, warm cinematic lighting, expressive original characters',
  'anime': 'anime-inspired gentle children\'s animation, soft pastel palette',
  'okuloncesi': 'colorful preschool animation, simple shapes, cheerful bright palette',
  'egitici': 'educational children\'s animation, clear simple visuals, friendly tone',
  'gercekci': 'realistic, warm and bright family-friendly cinematography',
};

// ---------- LLM (OpenAI, isteğe bağlı) ----------
async function llmJSON(system, user) {
  if (!process.env.OPENAI_API_KEY) return null;
  const r = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + process.env.OPENAI_API_KEY },
    body: JSON.stringify({ model: process.env.OPENAI_MODEL || 'gpt-4o-mini', response_format: { type: 'json_object' },
      messages: [{ role: 'system', content: system }, { role: 'user', content: user }] }),
  });
  if (!r.ok) throw httpErr(502, 'Yapay zekâ servisi hata verdi.', r.status + ' ' + (await r.text()).slice(0, 300));
  return JSON.parse((await r.json()).choices[0].message.content);
}

// ---------- Video sağlayıcıları (adaptörler) ----------
// Arayüz: configured(), clip (üretilen klip süresi sn), submit(input) -> {id}, status(id) -> {state, url, error}, download(url, dosya)
const download = async (url, out, headers = {}) => {
  const r = await fetch(url, { headers });
  if (!r.ok) throw httpErr(502, 'Video indirilemedi.', 'HTTP ' + r.status);
  fs.writeFileSync(out, Buffer.from(await r.arrayBuffer()));
};
const DEMO_COLORS = ['3b82f6', 'ef476f', '06d6a0', 'f59e0b', '8b5cf6', '14b8a6', 'f97316', 'ec4899'];
const PROVIDERS = {
  demo: {
    label: 'Demo Modu (sahte video, kredi harcamaz)', clip: 5, poll: 300, configured: () => true,
    async submit(i) {
      const [w, h] = dims(i.aspect, '720p').map(v => v / 2), d = Math.min(i.duration, 5);
      fs.mkdirSync(path.join(i.dir, 'scenes'), { recursive: true });
      const txt = `scenes/t${i.index}.txt`;
      fs.writeFileSync(path.join(i.dir, txt), `Sahne ${i.index}\n(demo)`);
      const vf = FONT ? `drawtext=fontfile=${FONT}:textfile=${txt}:fontsize=${Math.round(h / 9)}:fontcolor=white:x=(w-text_w)/2+(w/12)*sin(2*t):y=(h-text_h)/2` : 'null';
      await ffmpeg(['-f', 'lavfi', '-i', `color=c=0x${DEMO_COLORS[i.index % 8]}:s=${w}x${h}:d=${d}:r=30`, '-vf', vf,
        '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-t', String(d), i.out], i.dir);
      return { id: 'local' };
    },
    async status() { return { state: 'done' }; },
    async download() {},
  },
  veo: {
    label: 'Google Veo', clip: 8, poll: 8000, configured: () => !!process.env.GOOGLE_AI_API_KEY,
    base: 'https://generativelanguage.googleapis.com/v1beta',
    hdr: () => ({ 'x-goog-api-key': process.env.GOOGLE_AI_API_KEY, 'Content-Type': 'application/json' }),
    async submit(i) {
      const params = { aspectRatio: i.aspect === '9:16' ? '9:16' : '16:9' }; // 1:1 render aşamasında kırpılır
      if (i.negative) params.negativePrompt = i.negative;
      const r = await fetch(`${this.base}/models/${process.env.VEO_MODEL || 'veo-3.0-fast-generate-001'}:predictLongRunning`, {
        method: 'POST', headers: this.hdr(), body: JSON.stringify({ instances: [{ prompt: i.prompt }], parameters: params }) });
      if (!r.ok) throw httpErr(502, 'Veo isteği reddedildi.', r.status + ' ' + (await r.text()).slice(0, 400));
      return { id: (await r.json()).name };
    },
    async status(id) {
      const r = await fetch(`${this.base}/${id}`, { headers: this.hdr() });
      if (!r.ok) throw httpErr(502, 'Veo durum sorgusu başarısız.', r.status);
      const j = await r.json();
      if (!j.done) return { state: 'pending' };
      if (j.error) return { state: 'failed', error: j.error.message || 'Veo üretimi başarısız oldu.' };
      const v = j.response?.generateVideoResponse?.generatedSamples?.[0]?.video?.uri;
      return v ? { state: 'done', url: v } : { state: 'failed', error: 'Veo video döndürmedi (içerik filtresi olabilir).' };
    },
    download: (url, out) => download(url, out, { 'x-goog-api-key': process.env.GOOGLE_AI_API_KEY }),
  },
  luma: {
    label: 'Luma Dream Machine', clip: 5, poll: 6000, configured: () => !!process.env.LUMA_API_KEY,
    base: 'https://api.lumalabs.ai/dream-machine/v1',
    hdr: () => ({ Authorization: 'Bearer ' + process.env.LUMA_API_KEY, 'Content-Type': 'application/json' }),
    async submit(i) {
      const r = await fetch(`${this.base}/generations`, { method: 'POST', headers: this.hdr(), body: JSON.stringify({
        prompt: i.prompt, model: process.env.LUMA_MODEL || 'ray-2', aspect_ratio: i.aspect,
        resolution: i.resolution === '720p' ? '720p' : '1080p', duration: '5s' }) });
      if (!r.ok) throw httpErr(502, 'Luma isteği reddedildi.', r.status + ' ' + (await r.text()).slice(0, 400));
      return { id: (await r.json()).id };
    },
    async status(id) {
      const r = await fetch(`${this.base}/generations/${id}`, { headers: this.hdr() });
      if (!r.ok) throw httpErr(502, 'Luma durum sorgusu başarısız.', r.status);
      const j = await r.json();
      if (j.state === 'completed') return { state: 'done', url: j.assets?.video };
      if (j.state === 'failed') return { state: 'failed', error: j.failure_reason || 'Luma üretimi başarısız oldu.' };
      return { state: 'pending' };
    },
    download: (url, out) => download(url, out),
  },
};

// ---------- Şarkı sözü, zamanlama, altyazı ----------
function parseLines(lyrics) {
  return String(lyrics || '').split(/\r?\n/).map(l => l.trim()).filter(l => l && !/^[\[(].*[\])]$/.test(l));
}
function timeLines(lines, dur) { // tahmini zamanlama: satır uzunluğuna göre orantılı
  const total = lines.reduce((a, l) => a + l.length + 8, 0); let t = 0;
  return lines.map(text => { const d = dur * (text.length + 8) / total; const o = { text, start: +t.toFixed(2), end: +(t + d).toFixed(2) }; t += d; return o; });
}
const tc = s => { const ms = Math.round(s * 1000); return `${pad(Math.floor(ms / 3600000))}:${pad(Math.floor(ms / 60000) % 60)}:${pad(Math.floor(ms / 1000) % 60)},${String(ms % 1000).padStart(3, '0')}`; };
const toSrt = lines => lines.map((l, i) => `${i + 1}\n${tc(l.start)} --> ${tc(l.end)}\n${l.text}\n`).join('\n');
function groupScenes(lines, target) {
  const groups = []; let cur = null;
  for (const l of lines) {
    if (!cur) cur = { start: l.start, end: l.end, texts: [] };
    cur.texts.push(l.text); cur.end = l.end;
    if (cur.end - cur.start >= target) { groups.push(cur); cur = null; }
  }
  if (cur) { if (groups.length && cur.end - cur.start < target / 2) { const g = groups[groups.length - 1]; g.texts.push(...cur.texts); g.end = cur.end; } else groups.push(cur); }
  return groups;
}
function retime(p) { // sahne süreleri toplamı = şarkı süresi
  const total = p.scenes.reduce((a, s) => a + s.duration, 0) || 1, f = p.audio.duration / total; let t = 0;
  for (const s of p.scenes) { s.duration = +(s.duration * f).toFixed(2); s.start = +t.toFixed(2); t += s.duration; s.end = +t.toFixed(2); }
}

// ---------- Prompt oluşturma (Global stil + Karakter + Ortam + Aksiyon + Kamera + Işık + Süreklilik) ----------
const bible = p => p.characters.map(c => `${c.name}: ${c.desc}`).join('; ');
function styleText(p) { return [STYLES[p.style], p.customStyle].filter(Boolean).join('. ') || STYLES['3d']; }
const CONT = { yuksek: 'Keep characters, clothing, colors and art style strictly identical to previous scenes.', orta: 'Keep characters and art style consistent with previous scenes.', dusuk: 'Loosely keep the overall look consistent.' };
function buildPrompt(p, s) {
  const chars = bible(p);
  return [`Style: ${styleText(p)}.`, chars && `Characters (must look identical in every scene): ${chars}.`,
    `Setting: ${s.location}.`, `Action: ${s.action}.`, `Camera: ${s.camera}.`, `Lighting: ${s.lighting}.`,
    `Continuity: ${CONT[p.settings.continuity] || CONT.yuksek} ${s.continuity || ''}`.trim(),
    'No text, no subtitles, no logos, child-safe content.'].filter(Boolean).join(' ');
}
const NEGATIVE = 'text, watermark, subtitles, logo, scary, violence, distorted face, extra fingers, inconsistent character design';

// ---------- Şarkı analizi + sahne planı ----------
async function makePlan(p) {
  const lines = parseLines(p.lyrics);
  if (!lines.length) throw httpErr(400, 'Şarkı sözleri boş. Önce sözleri girin.');
  const prov = PROVIDERS[p.settings.provider];
  p.lines = timeLines(lines, p.audio.duration);
  const target = p.settings.sceneDuration === 'auto' ? prov.clip : +p.settings.sceneDuration || prov.clip;
  const groups = groupScenes(p.lines, target);
  let ai = null, note = '';
  try {
    ai = await llmJSON('You are a children\'s music video director. Reply with JSON only.',
      `Song title: ${p.title}\nVisual style: ${styleText(p)}\nCharacters: ${bible(p) || 'invent 1-2 friendly characters'}\n` +
      `Scenes (lyrics are Turkish): ${JSON.stringify(groups.map((g, i) => ({ i, lyrics: g.texts.join(' / ') })))}\n` +
      'Return JSON: {"theme":"(Turkish)","story_arc":"(Turkish, 2 sentences)","mood":"","locations":["..."],"scenes":[{"i":0,"purpose":"(Turkish)","location":"(English)","action":"(English, concrete visual action for a video model)","camera":"(English)","lighting":"(English)","continuity":"(English)"}]} ' +
      `Exactly ${groups.length} scenes. Keep it child-friendly.`);
  } catch (e) { note = 'Yapay zekâ kullanılamadı, basit plan oluşturuldu. ' + e.message; }
  if (!ai) note = note || 'OPENAI_API_KEY tanımlı değil; sözlerden basit bir sahne planı oluşturuldu.';
  const str = (v, d) => typeof v === 'string' && v.trim() ? v.trim() : d;
  const aiScenes = Array.isArray(ai?.scenes) ? ai.scenes : [];
  p.scenes = groups.map((g, i) => {
    const a = aiScenes.find(x => x && x.i === i) || {};
    const s = { id: 's' + crypto.randomBytes(4).toString('hex'), start: +g.start.toFixed(2), end: +g.end.toFixed(2), duration: +(g.end - g.start).toFixed(2),
      lyrics: g.texts.join('\n'), purpose: str(a.purpose, 'Şarkı sözlerini görselleştirme'),
      location: str(a.location, 'a colorful, child-friendly place'),
      action: str(a.action, `the characters act out these Turkish song lyrics: "${g.texts.join(' / ')}"`),
      camera: str(a.camera, 'smooth gentle camera movement, medium shot'), lighting: str(a.lighting, 'bright warm daylight'),
      continuity: str(a.continuity, ''), transition: 'cut', negative: NEGATIVE, status: 'pending', error: null, file: null };
    s.prompt = buildPrompt(p, s); return s;
  });
  retime(p);
  p.analysis = { title: p.title, theme: str(ai?.theme, ''), story_arc: str(ai?.story_arc, ''), mood: str(ai?.mood, ''),
    locations: Array.isArray(ai?.locations) ? ai.locations.filter(x => typeof x === 'string') : [],
    characters: p.characters, sections: p.lines.length, visual_style: styleText(p), note };
  writePlanFiles(p);
  wr(p, 'subtitles/TR.srt', toSrt(p.lines));
  p.subtitles = ['TR'];
  save(p);
}
function writePlanFiles(p) {
  wr(p, 'analysis/song-analysis.json', p.analysis); wr(p, 'storyboard/storyboard.json', p.scenes);
  wr(p, 'characters/character-bible.json', { style: styleText(p), characters: p.characters });
  p.scenes.forEach((s, i) => wr(p, `prompts/scene-${pad(i + 1)}.txt`, s.prompt + '\n\nNEGATIVE: ' + s.negative));
}

// ---------- Sahne üretimi (arka plan) ----------
const busy = new Map();
const IN_PROGRESS = ['submitting', 'generating', 'downloading', 'retrying'];
async function genScene(p, s) {
  const prov = PROVIDERS[p.settings.provider], idx = p.scenes.indexOf(s) + 1;
  const rel = `scenes/scene-${pad(idx)}.mp4`, out = path.join(pdir(p.id), rel);
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      s.status = attempt ? 'retrying' : 'submitting'; s.error = null; save(p);
      const { id } = await prov.submit({ prompt: s.prompt, negative: s.negative, aspect: p.settings.aspect, resolution: p.settings.resolution,
        duration: prov.clip, out, dir: pdir(p.id), index: idx });
      s.status = 'generating'; save(p);
      let done = false;
      for (let n = 0; n < 200 && !done; n++) {
        await sleep(prov.poll);
        const st = await prov.status(id);
        if (st.state === 'failed') throw httpErr(502, st.error);
        if (st.state === 'done') { s.status = 'downloading'; save(p); await prov.download(st.url, out); done = true; }
      }
      if (!done) throw httpErr(504, 'Video üretimi zaman aşımına uğradı.');
      if (!fs.existsSync(out) || fs.statSync(out).size < 1000) throw httpErr(500, 'İndirilen video dosyası geçersiz.');
      s.status = 'completed'; s.file = rel; s.error = null; save(p); return;
    } catch (e) {
      s.error = { message: e.message, detail: e.detail || '' };
      if (attempt === 1) { s.status = 'failed'; save(p); }
    }
  }
}
function startGenerate(p, ids, force) {
  const prov = PROVIDERS[p.settings.provider];
  if (!prov?.configured()) throw httpErr(400, 'Bu sağlayıcı için API anahtarı eksik.');
  if (busy.has(p.id)) throw httpErr(409, 'Bu proje için bir işlem zaten çalışıyor.');
  if (!p.scenes?.length) throw httpErr(400, 'Önce sahne planını oluşturun.');
  const todo = p.scenes.filter(s => !ids || ids.includes(s.id)).filter(s => force || s.status !== 'completed');
  if (!todo.length) throw httpErr(400, 'Üretilecek sahne yok. Tüm sahneler zaten tamamlanmış.');
  todo.forEach(s => { s.status = 'queued'; s.error = null; if (force) s.file = null; });
  p.job = { type: 'generate', state: 'running', message: 'Sahneler üretiliyor…', cancel: false };
  busy.set(p.id, 'generate'); save(p);
  (async () => {
    let i = 0;
    const worker = async () => { while (i < todo.length && !p.job.cancel) await genScene(p, todo[i++]); };
    await Promise.all(Array.from({ length: Math.min(+process.env.CONCURRENCY || 2, todo.length) }, worker));
    todo.forEach(s => { if (s.status === 'queued') s.status = 'cancelled'; });
    const failed = p.scenes.filter(s => s.status === 'failed').length;
    p.job = p.job.cancel ? { type: 'generate', state: 'cancelled', message: 'Üretim durduruldu.' }
      : failed ? { type: 'generate', state: 'failed', message: `${failed} sahne üretilemedi. Başarısız sahneleri yeniden deneyebilirsiniz.` }
      : { type: 'generate', state: 'done', message: 'Tüm sahneler hazır. Final videoyu oluşturabilirsiniz.' };
    busy.delete(p.id); save(p);
  })();
}

// ---------- Final render + kalite kontrol ----------
async function qualityCheck(p) {
  if (!p.scenes?.length) throw httpErr(400, 'Sahne planı yok.');
  p.scenes.forEach((s, i) => {
    if (s.status !== 'completed' || !s.file || !fs.existsSync(path.join(pdir(p.id), s.file)))
      throw httpErr(400, `Sahne ${i + 1} eksik veya üretilmemiş. Final video oluşturulamaz; önce bu sahneyi üretin.`);
  });
  for (const [i, s] of p.scenes.entries())
    if (!(await probeDuration(path.join(pdir(p.id), s.file)) > 0)) throw httpErr(400, `Sahne ${i + 1} bozuk veya süresi sıfır. Bu sahneyi yeniden üretin.`);
  if (!fs.existsSync(path.join(pdir(p.id), p.audio.file))) throw httpErr(400, 'Şarkı dosyası bulunamadı.');
  if (!fs.existsSync(path.join(pdir(p.id), 'subtitles/TR.srt'))) throw httpErr(400, 'Altyazı dosyası bulunamadı. Sahne planını yeniden oluşturun.');
}
async function renderFinal(p) {
  const dir = pdir(p.id), tmp = path.join(dir, 'output', 'tmp');
  fs.rmSync(tmp, { recursive: true, force: true }); fs.mkdirSync(tmp, { recursive: true });
  const [w, h] = dims(p.settings.aspect, p.settings.resolution);
  const list = [];
  for (const [i, s] of p.scenes.entries()) {
    p.job.message = `Sahne ${i + 1}/${p.scenes.length} işleniyor…`; save(p);
    const name = `n-${pad(i + 1)}.mp4`;
    await ffmpeg(['-i', path.join(dir, s.file), '-vf', `scale=${w}:${h}:force_original_aspect_ratio=increase,crop=${w}:${h},setsar=1,fps=30,tpad=stop_mode=clone:stop_duration=${Math.ceil(s.duration) + 10}`,
      '-t', s.duration.toFixed(3), '-an', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-pix_fmt', 'yuv420p', path.join(tmp, name)]);
    list.push(`file '${name}'`);
  }
  p.job.message = 'Sahneler birleştiriliyor ve şarkı ekleniyor…'; save(p);
  fs.writeFileSync(path.join(tmp, 'list.txt'), list.join('\n'));
  await ffmpeg(['-f', 'concat', '-safe', '0', '-i', 'list.txt', '-c', 'copy', 'video.mp4'], tmp);
  await ffmpeg(['-i', path.join(tmp, 'video.mp4'), '-i', path.join(dir, p.audio.file), '-map', '0:v', '-map', '1:a',
    '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-shortest', '-movflags', '+faststart', path.join(dir, 'output/final.mp4')]);
  await ffmpeg(['-i', path.join(dir, 'output/final.mp4'), '-vf', 'scale=-2:360', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '30',
    '-c:a', 'aac', '-b:a', '96k', path.join(dir, 'output/preview.mp4')]);
  fs.rmSync(tmp, { recursive: true, force: true });
}
function startRender(p) {
  if (busy.has(p.id)) throw httpErr(409, 'Bu proje için bir işlem zaten çalışıyor.');
  p.job = { type: 'render', state: 'running', message: 'Kalite kontrol yapılıyor…' }; busy.set(p.id, 'render'); save(p);
  (async () => {
    try { await qualityCheck(p); await renderFinal(p); p.outputs = { final: 'output/final.mp4', preview: 'output/preview.mp4' };
      p.job = { type: 'render', state: 'done', message: 'Final video hazır! 🎬' };
    } catch (e) { p.job = { type: 'render', state: 'failed', message: e.message, detail: e.detail || '' }; }
    busy.delete(p.id); save(p);
  })();
}

// ---------- Altyazı çevirisi, thumbnail, yayın paketi ----------
const LANGS = { EN: 'English', DE: 'German', ES: 'Spanish', AR: 'Arabic' };
async function makeSubtitles(p) {
  if (!p.lines) throw httpErr(400, 'Önce sahne planını oluşturun.');
  wr(p, 'subtitles/TR.srt', toSrt(p.lines)); const notes = [];
  if (!process.env.OPENAI_API_KEY) notes.push('Çeviri için OPENAI_API_KEY gerekli; yalnızca Türkçe altyazı oluşturuldu.');
  else for (const [code, name] of Object.entries(LANGS)) {
    try {
      const r = await llmJSON('You translate children\'s song lyrics. Reply with JSON only.',
        `Translate these Turkish lyric lines to ${name}, one output line per input line, same order. Keep character/proper names unchanged: ${p.characters.map(c => c.name).join(', ') || '-'}.\n` +
        `Return {"lines":[...]} with exactly ${p.lines.length} strings.\n` + JSON.stringify(p.lines.map(l => l.text)));
      if (!Array.isArray(r?.lines) || r.lines.length !== p.lines.length) throw new Error('Satır sayısı uyuşmadı');
      wr(p, `subtitles/${code}.srt`, toSrt(p.lines.map((l, i) => ({ ...l, text: String(r.lines[i]) }))));
    } catch (e) { notes.push(`${code} çevirisi başarısız: ${e.message}`); }
  }
  p.subtitles = ['TR', ...Object.keys(LANGS)].filter(c => fs.existsSync(path.join(pdir(p.id), `subtitles/${c}.srt`)));
  save(p); return { notes };
}
async function makeThumbnail(p, text, time) {
  const dir = pdir(p.id);
  let src = path.join(dir, 'output/final.mp4');
  if (!fs.existsSync(src)) { const s = p.scenes?.find(x => x.file && fs.existsSync(path.join(dir, x.file))); if (!s) throw httpErr(400, 'Thumbnail için önce en az bir sahne üretilmeli.'); src = path.join(dir, s.file); }
  const dur = await probeDuration(src);
  let t = isFinite(+time) && time !== '' && time != null ? +time : dur / 2; t = Math.max(0, Math.min(t, Math.max(0, dur - 0.2)));
  const words = String(text || 'Neler Oldu?').trim().split(/\s+/).slice(0, 3).join(' ');
  fs.mkdirSync(path.join(dir, 'thumbnail'), { recursive: true });
  fs.writeFileSync(path.join(dir, 'thumbnail/text.txt'), words);
  let vf = 'scale=1280:720:force_original_aspect_ratio=increase,crop=1280:720';
  if (FONT) vf += `,drawtext=fontfile=${FONT}:textfile=thumbnail/text.txt:fontsize=130:fontcolor=white:borderw=10:bordercolor=black:x=(w-text_w)/2:y=h-text_h-70`;
  await ffmpeg(['-ss', String(t), '-i', src, '-frames:v', '1', '-vf', vf, '-q:v', '2', 'thumbnail/thumbnail.jpg'], dir);
  p.thumbnail = { text: words, time: +t.toFixed(1), file: 'thumbnail/thumbnail.jpg', rev: Date.now() };
  save(p); return { fontMissing: !FONT };
}
async function makePublish(p) {
  let r = null, note = '';
  try {
    r = await llmJSON('You are a YouTube growth expert for Turkish children\'s music channels. Reply with JSON only.',
      `Şarkı: ${p.title}\nTema: ${p.analysis?.theme || ''}\nSözler:\n${p.lyrics.slice(0, 1500)}\n` +
      'Turkish, natural title (max 70 chars), short curiosity-driven description (do not reveal the whole story), long description, hashtags, tags, thumbnail_text (max 3 words), pinned_comment, playlist suggestion. ' +
      'Return {"title","short_description","long_description","hashtags":[],"tags":[],"thumbnail_text","pinned_comment","playlist"}');
  } catch (e) { note = 'Yapay zekâ kullanılamadı: ' + e.message; }
  const arr = v => Array.isArray(v) ? v.map(String) : [];
  const pub = { title: r?.title || `${p.title} | Çocuk Şarkısı`, short_description: r?.short_description || 'Bu şarkıda neler olacak dersin? 🎶 Sonuna kadar izle ve birlikte söyle!',
    long_description: r?.long_description || `${p.title} - yeni çocuk şarkımız! Birlikte söyleyin, dans edin ve eğlenin.\n\nAbone olmayı unutma!`,
    hashtags: arr(r?.hashtags).length ? arr(r.hashtags) : ['#çocukşarkıları', '#çocuk', '#şarkı'], tags: arr(r?.tags).length ? arr(r.tags) : ['çocuk şarkısı', 'çocuk şarkıları', p.title],
    thumbnail_text: r?.thumbnail_text || 'Neler Oldu?', pinned_comment: r?.pinned_comment || 'En sevdiğin sahne hangisiydi? 👇', playlist: r?.playlist || 'Çocuk Şarkıları', note: note || (r ? '' : 'OPENAI_API_KEY tanımlı değil; şablon metin kullanıldı.') };
  p.publish = pub;
  wr(p, 'publish/youtube.json', pub);
  wr(p, 'publish/youtube.txt', `BAŞLIK:\n${pub.title}\n\nKISA AÇIKLAMA:\n${pub.short_description}\n\nUZUN AÇIKLAMA:\n${pub.long_description}\n\nHASHTAG:\n${pub.hashtags.join(' ')}\n\nETİKETLER:\n${pub.tags.join(', ')}\n\nTHUMBNAIL YAZISI:\n${pub.thumbnail_text}\n\nSABİT YORUM:\n${pub.pinned_comment}\n\nOYNATMA LİSTESİ:\n${pub.playlist}\n`);
  save(p);
}

// ---------- Express ----------
const app = express();
app.disable('x-powered-by');
const sha = s => crypto.createHash('sha256').update(String(s)).digest();
const eq = (a, b) => crypto.timingSafeEqual(sha(a), sha(b));
app.get('/healthz', (q, r) => r.json({ ok: true }));
app.use((req, res, next) => { // kimlik doğrulama (Basic) + CSRF koruması
  const h = req.headers.authorization || '';
  const cred = h.startsWith('Basic ') ? Buffer.from(h.slice(6), 'base64').toString() : '', i = cred.indexOf(':');
  if (i < 0 || !eq(cred.slice(0, i), process.env.ADMIN_USER || 'admin') || !eq(cred.slice(i + 1), process.env.ADMIN_PASSWORD)) {
    res.set('WWW-Authenticate', 'Basic realm="Cocuk Sarki MV Studyosu"'); return res.status(401).send('Giriş gerekli.');
  }
  if (req.method !== 'GET' && req.headers['x-studio'] !== '1') return res.status(403).json({ error: 'İstek doğrulanamadı.' });
  next();
});
const hits = new Map(); // basit hız sınırı
app.use('/api', (req, res, next) => {
  const k = req.ip, n = Date.now(), e = hits.get(k);
  if (!e || n - e.t > 60000) hits.set(k, { t: n, c: 1 }); else if (++e.c > 600) return res.status(429).json({ error: 'Çok fazla istek. Lütfen biraz bekleyin.' });
  next();
});
app.use(express.json({ limit: '2mb' }));
app.use('/files', express.static(ROOT, { dotfiles: 'deny', index: false }));
app.use(express.static(path.join(__dirname, 'public')));
const h = fn => (req, res, next) => Promise.resolve(fn(req, res)).then(r => r !== undefined && res.json(r)).catch(next);
const upload = multer({ dest: os.tmpdir(), limits: { fileSize: (+process.env.MAX_UPLOAD_MB || 100) * 1024 * 1024 } });

app.get('/api/health', h(async () => {
  const chk = async c => { try { await run(c, ['-version']); return true; } catch { return false; } };
  return { ffmpeg: await chk('ffmpeg'), ffprobe: await chk('ffprobe'), font: !!FONT, llm: !!process.env.OPENAI_API_KEY, storage: ROOT,
    providers: Object.entries(PROVIDERS).map(([id, p]) => ({ id, label: p.label, configured: p.configured(), clip: p.clip })) };
}));
app.get('/api/projects', h(() => listProjects()));
app.get('/api/projects/:id', h(req => load(req.params.id)));

app.post('/api/projects', upload.single('audio'), h(async (req) => {
  const f = req.file, b = req.body;
  try {
    if (!f) throw httpErr(400, 'Şarkı dosyası seçilmedi.');
    const ext = path.extname(f.originalname).toLowerCase();
    if (!['.mp3', '.wav', '.flac'].includes(ext)) throw httpErr(400, 'Desteklenmeyen dosya biçimi. Yalnızca MP3, WAV veya FLAC yükleyin.');
    let duration = 0; try { duration = await probeDuration(f.path); } catch {}
    if (!(duration > 1)) throw httpErr(400, 'Ses dosyası bozuk veya okunamıyor.');
    const provider = PROVIDERS[b.provider] ? b.provider : 'demo';
    let chars = []; try { chars = JSON.parse(b.characters || '[]'); } catch {}
    chars = chars.filter(c => c && String(c.name || '').trim()).slice(0, 8).map(c => ({ name: String(c.name).trim().slice(0, 60), desc: String(c.desc || '').trim().slice(0, 500) }));
    const id = crypto.randomBytes(6).toString('hex');
    for (const d of ['input', 'analysis', 'storyboard', 'prompts', 'characters', 'scenes', 'subtitles', 'thumbnail', 'output', 'publish']) fs.mkdirSync(path.join(pdir(id), d), { recursive: true });
    fs.copyFileSync(f.path, path.join(pdir(id), 'input', 'song' + ext));
    const opt = (v, list, d) => list.includes(v) ? v : d;
    const p = { id, title: String(b.title || 'Adsız Şarkı').trim().slice(0, 100), lyrics: String(b.lyrics || '').slice(0, 20000),
      style: opt(b.style, [...Object.keys(STYLES), 'ozel'], '3d'), customStyle: String(b.customStyle || '').slice(0, 500), characters: chars,
      settings: { provider, aspect: opt(b.aspect, ['16:9', '9:16', '1:1'], '16:9'), resolution: opt(b.resolution, ['720p', '1080p'], '1080p'),
        sceneDuration: opt(b.sceneDuration, ['auto', '5', '6', '8'], 'auto'), continuity: opt(b.continuity, ['yuksek', 'orta', 'dusuk'], 'yuksek') },
      audio: { file: 'input/song' + ext, duration: +duration.toFixed(2), size: f.size, format: ext.slice(1).toUpperCase() },
      scenes: [], job: null, createdAt: new Date().toISOString() };
    save(p); cache.set(id, p); return p;
  } finally { if (f) fs.rm(f.path, { force: true }, () => {}); }
}));
app.put('/api/projects/:id', h(req => { // sözler / başlık / ayar güncelle
  const p = load(req.params.id), b = req.body;
  if (typeof b.lyrics === 'string') p.lyrics = b.lyrics.slice(0, 20000);
  if (typeof b.title === 'string' && b.title.trim()) p.title = b.title.trim().slice(0, 100);
  if (b.settings?.provider && PROVIDERS[b.settings.provider]) p.settings.provider = b.settings.provider;
  save(p); return p;
}));
app.delete('/api/projects/:id', h(req => {
  const p = load(req.params.id); if (busy.has(p.id)) throw httpErr(409, 'Çalışan işlem bitmeden proje silinemez.');
  cache.delete(p.id); fs.rmSync(pdir(p.id), { recursive: true, force: true }); return { ok: true };
}));
app.post('/api/projects/:id/plan', h(async req => {
  const p = load(req.params.id); if (busy.has(p.id)) throw httpErr(409, 'Bu proje için bir işlem zaten çalışıyor.');
  busy.set(p.id, 'plan'); try { await makePlan(p); } finally { busy.delete(p.id); } return p;
}));
app.put('/api/projects/:id/scenes/:sid', h(req => {
  const p = load(req.params.id), s = p.scenes.find(x => x.id === req.params.sid); if (!s) throw httpErr(404, 'Sahne bulunamadı.');
  const b = req.body, t = (v, n) => String(v).slice(0, n);
  for (const k of ['action', 'location', 'camera', 'lighting']) if (typeof b[k] === 'string' && b[k].trim()) s[k] = t(b[k], 500);
  if (b.rebuild) s.prompt = buildPrompt(p, s); else if (typeof b.prompt === 'string' && b.prompt.trim()) s.prompt = t(b.prompt, 4000);
  if (typeof b.negative === 'string') s.negative = t(b.negative, 500);
  if (['completed'].includes(s.status) && (b.prompt || b.rebuild)) s.note = 'Prompt değişti; yeni prompt ile yeniden üretmeniz gerekir.';
  writePlanFiles(p); save(p); return p;
}));
app.post('/api/projects/:id/scenes/:sid/op', h(req => {
  const p = load(req.params.id), i = p.scenes.findIndex(x => x.id === req.params.sid); if (i < 0) throw httpErr(404, 'Sahne bulunamadı.');
  if (busy.has(p.id)) throw httpErr(409, 'Çalışan işlem bitmeden sahne düzeni değiştirilemez.');
  const op = req.body.op;
  if (op === 'up' && i > 0) [p.scenes[i - 1], p.scenes[i]] = [p.scenes[i], p.scenes[i - 1]];
  else if (op === 'down' && i < p.scenes.length - 1) [p.scenes[i + 1], p.scenes[i]] = [p.scenes[i], p.scenes[i + 1]];
  else if (op === 'dup') p.scenes.splice(i + 1, 0, { ...p.scenes[i], id: 's' + crypto.randomBytes(4).toString('hex'), status: 'pending', file: null, error: null });
  else if (op === 'del') { if (p.scenes.length < 2) throw httpErr(400, 'Son sahne silinemez.'); p.scenes.splice(i, 1); }
  // dosya adları sıraya bağlı olduğundan taşınan sahneler yeniden üretilmeli
  p.scenes.forEach((s, k) => { if (s.file && s.file !== `scenes/scene-${pad(k + 1)}.mp4`) { const old = path.join(pdir(p.id), s.file); const nw = `scenes/scene-${pad(k + 1)}.mp4`; s._mv = [old, nw]; } });
  const tmpNames = p.scenes.filter(s => s._mv);
  tmpNames.forEach(s => { try { fs.renameSync(s._mv[0], s._mv[0] + '.mv'); } catch {} });
  tmpNames.forEach(s => { try { fs.renameSync(s._mv[0] + '.mv', path.join(pdir(p.id), s._mv[1])); s.file = s._mv[1]; } catch { s.file = null; s.status = 'pending'; } delete s._mv; });
  retime(p); writePlanFiles(p); save(p); return p;
}));
app.post('/api/projects/:id/generate', h(req => {
  const p = load(req.params.id), ids = Array.isArray(req.body.ids) ? req.body.ids : null;
  startGenerate(p, ids, !!req.body.force); return p;
}));
app.post('/api/projects/:id/cancel', h(req => { const p = load(req.params.id); if (p.job?.state === 'running') p.job.cancel = true; save(p); return p; }));
app.post('/api/projects/:id/render', h(req => { const p = load(req.params.id); startRender(p); return p; }));
app.post('/api/projects/:id/subtitles', h(async req => { const p = load(req.params.id); const r = await makeSubtitles(p); return { project: p, ...r }; }));
app.put('/api/projects/:id/subtitles/:lang', h(req => {
  const p = load(req.params.id), l = req.params.lang; if (!['TR', ...Object.keys(LANGS)].includes(l)) throw httpErr(400, 'Geçersiz dil.');
  wr(p, `subtitles/${l}.srt`, String(req.body.text || '').slice(0, 200000)); if (!p.subtitles.includes(l)) p.subtitles.push(l); save(p); return p;
}));
app.post('/api/projects/:id/thumbnail', h(async req => { const p = load(req.params.id); const r = await makeThumbnail(p, req.body.text, req.body.time); return { project: p, ...r }; }));
app.post('/api/projects/:id/publish', h(async req => { const p = load(req.params.id); await makePublish(p); return p; }));

app.use((e, req, res, next) => { // Türkçe hata çıktısı
  if (e.code === 'LIMIT_FILE_SIZE') e = httpErr(413, `Dosya çok büyük. En fazla ${process.env.MAX_UPLOAD_MB || 100} MB yükleyebilirsiniz.`);
  const s = e.status || 500; if (s === 500) console.error(e);
  res.status(s).json({ error: e.status ? e.message : 'Beklenmeyen bir hata oluştu.', detail: e.detail || e.message });
});

// ---------- Yeniden başlatma sonrası devam ----------
for (const p of listProjects()) {
  if (p.job?.state !== 'running') continue;
  if (p.job.type === 'generate') {
    const resume = p.scenes.filter(s => IN_PROGRESS.includes(s.status) || s.status === 'queued');
    resume.forEach(s => s.status = 'queued');
    try { startGenerate(p, resume.map(s => s.id), false); } catch (e) { p.job = { type: 'generate', state: 'failed', message: e.message }; save(p); }
  } else { p.job = { type: p.job.type, state: 'failed', message: 'Sunucu yeniden başladı. İşlemi tekrar başlatın.' }; save(p); }
}
app.listen(PORT, '127.0.0.1', () => console.log(`Stüdyo hazır: http://127.0.0.1:${PORT}`));
