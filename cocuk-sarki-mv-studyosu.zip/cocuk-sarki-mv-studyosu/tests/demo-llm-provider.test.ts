import { describe, it, expect } from 'vitest';
import { DemoLLMProvider } from '@/providers/llm/demo-llm-provider';

describe('DemoLLMProvider (gerçek API çağrısı yapmaz)', () => {
  const provider = new DemoLLMProvider();

  it('şarkı sözlerinden geçerli bir analiz üretir', async () => {
    const analysis = await provider.analyzeSong({
      lyrics: 'Güneş doğdu\nKuşlar öttü\nGüneş doğdu\nKuşlar öttü\nHadi gel oynayalım',
      durationSeconds: 30
    });
    expect(analysis.sections.length).toBeGreaterThan(0);
    expect(analysis.title).toBeTruthy();
  });

  it('storyboard sahnelerinin toplam süresi şarkı süresine yakın olur', async () => {
    const analysis = await provider.analyzeSong({ lyrics: 'satır bir\nsatır iki\nsatır üç', durationSeconds: 24 });
    const scenes = await provider.createStoryboard({
      analysis,
      lyrics: 'satır bir\nsatır iki\nsatır üç',
      durationSeconds: 24,
      videoStyle: 'Renkli okul öncesi animasyon',
      characterNames: ['Elif'],
      sceneDurationPreference: '6'
    });
    const total = scenes[scenes.length - 1].endTime;
    expect(Math.abs(total - 24)).toBeLessThan(6);
  });
});
