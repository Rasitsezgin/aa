import { describe, it, expect } from 'vitest';
import { assembleScenePrompt } from '@/services/visual-bible.service';
import { VisualBible, StoryboardScene } from '@/types';

describe('assembleScenePrompt (görsel süreklilik)', () => {
  it('karakter incilini her sahne prompt\'una dahil eder', () => {
    const bible: VisualBible = {
      globalStyle: 'sıcak, parlak animasyon',
      characterBible: 'Elif: kırmızı elbiseli, sarı saçlı',
      environmentBible: 'renkli orman',
      colorPalette: ['#fff'],
      recurringProps: [],
      visualRules: []
    };
    const scene: StoryboardScene = {
      order: 0,
      startTime: 0,
      endTime: 6,
      duration: 6,
      lyricsSegment: 'örnek',
      characters: ['Elif'],
      videoPrompt: ''
    };
    const prompt = assembleScenePrompt(bible, scene);
    expect(prompt).toContain('Elif: kırmızı elbiseli, sarı saçlı');
    expect(prompt).toContain('sıcak, parlak animasyon');
  });
});
