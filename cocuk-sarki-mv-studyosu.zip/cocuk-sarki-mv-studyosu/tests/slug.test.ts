import { describe, it, expect } from 'vitest';
import { slugify } from '@/lib/slug';

describe('slugify (Türkçe karakter desteği)', () => {
  it('Türkçe karakterleri doğru şekilde dönüştürür', () => {
    const result = slugify('Çılgın Şarkı Öğretici');
    expect(result).toMatch(/^cilgin-sarki-ogretici-[a-z0-9]+$/);
  });

  it('boş girişte bile geçerli bir slug üretir', () => {
    const result = slugify('');
    expect(result).toMatch(/^proje-[a-z0-9]+$/);
  });
});
