import { describe, it, expect } from 'vitest';
import { StoryboardSceneSchema } from '@/types';

describe('StoryboardSceneSchema (sahne doğrulama)', () => {
  it('geçerli bir sahneyi kabul eder', () => {
    const scene = {
      order: 0,
      startTime: 0,
      endTime: 6,
      duration: 6,
      lyricsSegment: 'Örnek söz',
      videoPrompt: 'Örnek prompt'
    };
    expect(() => StoryboardSceneSchema.parse(scene)).not.toThrow();
  });

  it('sıfır veya negatif süreli sahneyi reddeder', () => {
    const scene = { order: 0, startTime: 0, endTime: 0, duration: 0, lyricsSegment: 'x', videoPrompt: 'y' };
    expect(() => StoryboardSceneSchema.parse(scene)).toThrow();
  });
});
