import { describe, it, expect } from 'vitest';
import { assertSafeSlug } from '@/lib/paths';

describe('assertSafeSlug (path traversal koruması)', () => {
  it('geçerli slug kabul eder', () => {
    expect(() => assertSafeSlug('renkli-orman-sarkisi-ab12c')).not.toThrow();
  });

  it('path traversal denemesini reddeder', () => {
    expect(() => assertSafeSlug('../../etc/passwd')).toThrow();
  });

  it('boşluk veya özel karakter içeren slug reddedilir', () => {
    expect(() => assertSafeSlug('kötü slug!')).toThrow();
  });
});
