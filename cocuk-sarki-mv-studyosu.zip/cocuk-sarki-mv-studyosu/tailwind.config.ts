import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./src/**/*.{ts,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        studio: {
          bg: '#0b0c10',
          panel: '#14161d',
          panel2: '#1b1e27',
          border: '#262a36',
          accent: '#8b5cf6',
          accent2: '#22d3ee',
          text: '#e6e7ec',
          muted: '#9297a8',
          success: '#34d399',
          warning: '#fbbf24',
          danger: '#f87171'
        }
      },
      fontFamily: {
        sans: ['ui-sans-serif', 'system-ui', 'Inter', 'sans-serif']
      }
    }
  },
  plugins: []
};
export default config;
