#!/usr/bin/env bash
# Çocuk Şarkı MV Stüdyosu — Ubuntu VPS ilk kurulum yardımcı betiği.
# Bu betik yalnızca sistem bağımlılıklarını kurar; uygulamanın kendisini
# kurmaz (bkz. README.md "Kurulum Adımları").
#
# Kullanım: sudo bash deploy/vps-kurulum.sh
set -euo pipefail

echo "== Paket listesi güncelleniyor =="
apt update && apt upgrade -y

echo "== Temel araçlar kuruluyor =="
apt install -y curl git build-essential ca-certificates gnupg nginx ufw

echo "== Node.js 20.x kuruluyor =="
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs

echo "== FFmpeg kuruluyor =="
apt install -y ffmpeg
ffmpeg -version | head -1

echo "== Docker + Docker Compose kuruluyor (PostgreSQL/Redis için) =="
curl -fsSL https://get.docker.com | sh
systemctl enable --now docker

echo "== PM2 kuruluyor =="
npm install -g pm2

echo "== Güvenlik duvarı (UFW) temel kuralları =="
ufw allow OpenSSH
ufw allow 'Nginx Full'
ufw --force enable

echo ""
echo "Kurulum tamamlandı. Şimdi:"
echo "  1) Bu projeyi VPS'e kopyalayın (git clone veya scp)"
echo "  2) cp .env.example .env  ve .env dosyasını doldurun"
echo "  3) docker compose up -d   (PostgreSQL + Redis başlatır)"
echo "  4) npm install            (postinstall otomatik 'prisma generate' çalıştırır)"
echo "  5) npx prisma migrate deploy"
echo "  6) npm run build"
echo "  7) pm2 start ecosystem.config.js && pm2 save && pm2 startup"
echo "  8) Nginx için deploy/nginx.conf.example dosyasını kullanın"
