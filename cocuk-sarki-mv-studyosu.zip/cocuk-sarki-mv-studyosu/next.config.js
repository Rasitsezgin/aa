/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: { serverActions: { bodySizeLimit: '200mb' } }
  // NOT: "output: 'standalone'" kasıtlı olarak kullanılmıyor çünkü PM2 +
  // `npm run start` (next start) ile çalıştırıyoruz; ikisi birlikte uyumsuz
  // ("next start does not work with output: standalone" uyarısı verir).
};
module.exports = nextConfig;
