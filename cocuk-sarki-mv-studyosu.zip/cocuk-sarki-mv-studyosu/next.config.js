/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: { serverActions: { bodySizeLimit: '200mb' } },
  output: 'standalone'
};
module.exports = nextConfig;
