// PM2 process yöneticisi yapılandırması.
// Web sunucusu ve arka plan işçisi (worker) BİLİNÇLİ OLARAK ayrı process'ler
// olarak çalışır: video üretimi / FFmpeg render asla web isteklerini bloklamaz.
//
// Kullanım:
//   pm2 start ecosystem.config.js
//   pm2 save
//   pm2 startup   (VPS yeniden başladığında otomatik başlatma için)

module.exports = {
  apps: [
    {
      name: 'csms-web',
      script: 'node_modules/.bin/next',
      args: 'start -p 3000',
      cwd: __dirname,
      instances: 1,
      exec_mode: 'fork',
      env: { NODE_ENV: 'production' },
      max_memory_restart: '512M',
      out_file: './logs/web-out.log',
      error_file: './logs/web-error.log'
    },
    {
      name: 'csms-worker',
      script: 'node_modules/.bin/tsx',
      args: 'src/jobs/worker-runner.ts',
      cwd: __dirname,
      instances: 1,
      exec_mode: 'fork',
      env: { NODE_ENV: 'production' },
      max_memory_restart: '1024M',
      out_file: './logs/worker-out.log',
      error_file: './logs/worker-error.log'
    }
  ]
};
