/**
 * Demo Modu Uçtan Uca Doğrulama Betiği
 * ------------------------------------
 * Hiçbir API anahtarı gerektirmez. Şunları sırasıyla çalıştırır:
 *   1) Sentetik bir "şarkı" (test tonu) üretir (gerçek kullanımda kullanıcı yükler)
 *   2) Proje + şarkı + söz kayıtlarını oluşturur
 *   3) Demo LLM sağlayıcısıyla şarkı analizini çalıştırır
 *   4) Storyboard + Görsel İncil (Visual Bible) oluşturur ve onaylar
 *   5) Her sahne için Demo video sağlayıcısıyla gerçek, oynatılabilir MP4 klip üretir
 *   6) FFmpeg ile sahneleri birleştirir ve ORİJİNAL şarkıyı final ses parçası yapar
 *   7) Altyazı (TR + çeviriler), thumbnail ve YouTube paketini üretir
 *   8) Sonuçları ve final.mp4 yolunu ekrana yazar
 *
 * Çalıştırma (VPS'te, docker compose up -d sonrası):
 *   npm run demo:e2e
 *
 * NOT: Bu betik gerçek PostgreSQL + Redis bağlantısı gerektirir (DATABASE_URL,
 * REDIS_URL .env'de tanımlı olmalı). BullMQ kuyruğunu ATLAYIP sahne üretimini
 * doğrudan çağırır — böylece ayrı bir worker process'i çalıştırmadan da tüm
 * pipeline'ı tek komutla doğrulayabilirsiniz.
 */

import 'dotenv/config';
import fs from 'node:fs/promises';
import path from 'node:path';
import ffmpeg from 'fluent-ffmpeg';
import { prisma } from '../src/lib/prisma';
import { slugify } from '../src/lib/slug';
import { ensureProjectDirs, projectSubPath } from '../src/lib/paths';
import { processSceneGeneration } from '../src/services/video-generation.service';
import { renderFinalVideo } from '../src/services/ffmpeg.service';
import { generateAllSubtitles } from '../src/services/subtitle.service';
import { generateThumbnail } from '../src/services/thumbnail.service';
import { generateYoutubePublishPackage } from '../src/services/youtube-package.service';
import { getLLMProvider } from '../src/providers/llm';
import { assembleAllScenePrompts } from '../src/services/visual-bible.service';

const DEMO_LYRICS = `Güneş doğdu, kuşlar öttü
Hep birlikte gülelim
Ormanda yeni bir gün
Dostlarımla oynayalım

Güneş doğdu, kuşlar öttü
Hep birlikte gülelim
Küçük bir kitap bulduk
Sırları beraber çözelim

Artık akşam oldu, yıldızlar parlıyor
Yorgun ama mutluyuz
Yarın yine buluşuruz`;

async function createTestTone(destPath: string, seconds = 20) {
  await fs.mkdir(path.dirname(destPath), { recursive: true });
  return new Promise<void>((resolve, reject) => {
    ffmpeg()
      .input(`sine=frequency=440:duration=${seconds}`)
      .inputFormat('lavfi')
      .outputOptions(['-c:a libmp3lame'])
      .save(destPath)
      .on('end', () => resolve())
      .on('error', reject);
  });
}

async function main() {
  console.log('🎬 Demo Modu uçtan uca doğrulama başlıyor...\n');
  process.env.DEMO_MODE = 'true';

  // 0) Kullanıcı ve proje
  const email = `demo-${Date.now()}@example.com`;
  const user = await prisma.user.create({
    data: { email, passwordHash: 'demo-not-used', name: 'Demo Kullanıcı', role: 'ADMIN' }
  });
  const title = 'Renkli Orman Şarkısı (Demo)';
  const slug = slugify(title);
  await ensureProjectDirs(slug);
  const project = await prisma.project.create({
    data: { title, slug, ownerId: user.id, videoProviderKey: 'demo', sceneDuration: '6' }
  });
  console.log(`✅ Proje oluşturuldu: ${project.title} (${project.id})`);

  // 1) Sentetik şarkı + sözler
  const songPath = projectSubPath(slug, 'input', 'song.mp3');
  await createTestTone(songPath, 20);
  const song = await prisma.song.create({
    data: {
      projectId: project.id,
      originalFilename: 'demo-song.mp3',
      storagePath: songPath,
      format: 'mp3',
      durationSeconds: 20,
      fileSizeBytes: (await fs.stat(songPath)).size
    }
  });
  await prisma.lyrics.create({ data: { projectId: project.id, content: DEMO_LYRICS, source: 'MANUAL' } });
  console.log(`✅ Test şarkısı üretildi: ${songPath} (${song.durationSeconds}s)`);

  // 2) Karakter
  await prisma.character.create({
    data: {
      projectId: project.id,
      name: 'Elif',
      age: '6',
      appearance: 'kısa boylu, yuvarlak yüzlü',
      clothing: 'sarı elbise',
      hair: 'kısa, kahverengi, perçemli',
      colors: 'sarı, kahverengi',
      bibleText: 'Elif: 6 yaşında, kısa boylu, sarı elbiseli, kısa kahverengi saçlı'
    }
  });
  console.log('✅ Karakter oluşturuldu: Elif');

  // 3) Şarkı analizi (Demo LLM)
  const llm = getLLMProvider();
  const analysis = await llm.analyzeSong({ lyrics: DEMO_LYRICS, songTitleHint: title, durationSeconds: 20 });
  await prisma.lyrics.update({ where: { projectId: project.id }, data: { analysis: analysis as unknown as object } });
  await fs.writeFile(projectSubPath(slug, 'analysis', 'song-analysis.json'), JSON.stringify(analysis, null, 2), 'utf-8');
  console.log(`✅ Şarkı analizi tamamlandı: ${analysis.sections.length} bölüm tespit edildi`);

  // 4) Storyboard + Visual Bible
  const characters = await prisma.character.findMany({ where: { projectId: project.id } });
  const storyboardInput = {
    analysis,
    lyrics: DEMO_LYRICS,
    durationSeconds: 20,
    videoStyle: 'Renkli okul öncesi animasyon',
    characterNames: characters.map((c) => c.name),
    sceneDurationPreference: '6'
  };
  const [rawScenes, visualBible] = await Promise.all([
    llm.createStoryboard(storyboardInput),
    llm.buildVisualBible(storyboardInput)
  ]);
  const scenes = assembleAllScenePrompts(visualBible, rawScenes);

  const storyboard = await prisma.storyboard.create({
    data: {
      projectId: project.id,
      title: analysis.title,
      theme: analysis.theme,
      storyArc: analysis.story_arc,
      visualBible: visualBible as unknown as object,
      approvedAt: new Date(), // demo betiğinde otomatik onay
      scenes: {
        create: scenes.map((s) => ({
          order: s.order,
          startTime: s.startTime,
          endTime: s.endTime,
          duration: s.duration,
          lyricsSegment: s.lyricsSegment,
          narrativePurpose: s.narrativePurpose,
          location: s.location,
          characters: s.characters,
          characterActions: s.characterActions,
          camera: s.camera,
          lighting: s.lighting,
          environment: s.environment,
          visualStyle: s.visualStyle,
          transition: s.transition,
          videoPrompt: s.videoPrompt,
          negativePrompt: s.negativePrompt,
          continuityNotes: s.continuityNotes
        }))
      }
    },
    include: { scenes: { orderBy: { order: 'asc' } } }
  });
  console.log(`✅ Storyboard oluşturuldu ve onaylandı: ${storyboard.scenes.length} sahne`);

  // 5) Her sahneyi üret (kuyruk atlanarak doğrudan çağrılır)
  for (const scene of storyboard.scenes) {
    const job = await prisma.generationJob.create({
      data: { projectId: project.id, sceneId: scene.id, type: 'GENERATE_SCENE', status: 'QUEUED', provider: 'demo' }
    });
    await processSceneGeneration(scene.id, job.id);
    console.log(`  ✅ Sahne ${scene.order + 1}/${storyboard.scenes.length} üretildi`);
  }

  // 6) FFmpeg final render — orijinal şarkı final ses parçası olur
  const { finalPath, previewPath } = await renderFinalVideo(project.id);
  console.log(`✅ Final video oluşturuldu: ${finalPath}`);
  console.log(`✅ Önizleme oluşturuldu: ${previewPath}`);

  // 7) Altyazı, thumbnail, YouTube paketi
  await generateAllSubtitles(project.id);
  console.log('✅ Altyazılar oluşturuldu: TR, EN, DE, ES, AR');

  await generateThumbnail(project.id);
  console.log('✅ Thumbnail oluşturuldu');

  const publish = await generateYoutubePublishPackage(project.id);
  console.log(`✅ YouTube paketi oluşturuldu: "${publish.title}"`);

  console.log('\n🎉 TÜM ADIMLAR BAŞARIYLA TAMAMLANDI');
  console.log(`\nProje dizini: projects/${slug}/`);
  console.log(`Final video:  ${finalPath}`);
  console.log(`\nWeb arayüzünden görüntülemek için: /projeler/${project.id}`);

  await prisma.$disconnect();
  process.exit(0);
}

main().catch(async (err) => {
  console.error('\n❌ Demo doğrulama başarısız oldu:', err);
  await prisma.$disconnect();
  process.exit(1);
});
