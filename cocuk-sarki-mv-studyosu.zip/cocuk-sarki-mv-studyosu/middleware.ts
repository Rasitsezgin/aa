import { NextRequest, NextResponse } from 'next/server';

// NOT: Burada sadece çerezin VARLIĞI kontrol edilir (Edge Runtime'da
// node:crypto tam desteklenmediği için). Gerçek imza doğrulaması
// src/lib/auth.ts::getCurrentUser() içinde, sunucu tarafında yapılır.
// Bu middleware yalnızca kullanıcı deneyimini iyileştirir (hızlı yönlendirme),
// gerçek güvenlik sınırı API route'larındaki withApiHandler'dır.

const PUBLIC_PATHS = ['/giris', '/api/auth/login', '/api/health'];

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  if (PUBLIC_PATHS.some((p) => pathname.startsWith(p)) || pathname.startsWith('/_next') || pathname.startsWith('/api/providers')) {
    return NextResponse.next();
  }

  const hasSession = req.cookies.has('csms_session');
  if (!hasSession && !pathname.startsWith('/api')) {
    const url = req.nextUrl.clone();
    url.pathname = '/giris';
    return NextResponse.redirect(url);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico).*)']
};
