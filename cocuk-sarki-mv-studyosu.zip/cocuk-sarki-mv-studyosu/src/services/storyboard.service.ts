import { prisma } from '@/lib/prisma';
import { getLLMProvider } from '@/providers/llm';
import { assembleAllScenePrompts } from './visual-bible.service';
import { projectSubPath, ensureProjectDirs } from '@/lib/paths';
import fs from 'node:fs/promises';
import { KullaniciDostuHata, SongAnalysis, SongAnalysisSchema } from '@/types';

export async function createStoryboardForProject(projectId: string) {
  const project = await prisma.project.findUnique({
    where: { id: projectId },
    include: { song: true, lyrics: true, characters: true }
  });

  if (!project) throw new KullaniciDostuHata('Proje bulunamadı.');
  if (!project.lyrics?.analysis) {
    throw new KullaniciDostuHata('Önce şarkı analizini çalıştırmalısınız.', 'Lyrics.analysis boş.');
  }
  if (!project.song) throw new KullaniciDostuHata('Şarkı dosyası bulunamadı.');

  const analysisResult = SongAnalysisSchema.safeParse(project.lyrics.analysis);
  if (!analysisResult.success) {
    throw new KullaniciDostuHata('Kayıtlı şarkı analizi bozuk görünüyor. Analizi yeniden çalıştırın.', analysisResult.error.message);
  }
  const analysis: SongAnalysis = analysisResult.data;

  const llm = getLLMProvider();
  const characterNames = project.characters.map((c) => c.name);

  const input = {
    analysis,
    lyrics: project.lyrics.content,
    durationSeconds: project.song.durationSeconds,
    videoStyle: project.videoStyle || 'Renkli okul öncesi animasyon',
    styleNotes: project.styleNotes ?? undefined,
    characterNames,
    sceneDurationPreference: project.sceneDuration
  };

  const [rawScenes, visualBible] = await Promise.all([llm.createStoryboard(input), llm.buildVisualBible(input)]);

  const scenesWithPrompts = assembleAllScenePrompts(visualBible, rawScenes);

  // Validate: no gaps, no zero-length scenes, covers full song duration (rule §26 groundwork).
  validateStoryboardTiming(scenesWithPrompts, project.song.durationSeconds);

  const storyboard = await prisma.storyboard.upsert({
    where: { projectId },
    update: {
      title: analysis.title,
      theme: analysis.theme,
      storyArc: analysis.story_arc,
      visualBible: visualBible as unknown as object,
      scenes: { deleteMany: {}, create: scenesWithPrompts.map(toSceneCreateInput) }
    },
    create: {
      projectId,
      title: analysis.title,
      theme: analysis.theme,
      storyArc: analysis.story_arc,
      visualBible: visualBible as unknown as object,
      scenes: { create: scenesWithPrompts.map(toSceneCreateInput) }
    },
    include: { scenes: { orderBy: { order: 'asc' } } }
  });

  await ensureProjectDirs(project.slug);
  await fs.writeFile(
    projectSubPath(project.slug, 'storyboard', 'storyboard.json'),
    JSON.stringify(storyboard, null, 2),
    'utf-8'
  );
  for (const scene of storyboard.scenes) {
    await fs.writeFile(
      projectSubPath(project.slug, 'prompts', `scene-${String(scene.order + 1).padStart(2, '0')}.txt`),
      scene.videoPrompt,
      'utf-8'
    );
  }

  return storyboard;
}

function toSceneCreateInput(scene: ReturnType<typeof assembleAllScenePrompts>[number]) {
  return {
    order: scene.order,
    startTime: scene.startTime,
    endTime: scene.endTime,
    duration: scene.duration,
    lyricsSegment: scene.lyricsSegment,
    narrativePurpose: scene.narrativePurpose,
    location: scene.location,
    characters: scene.characters,
    characterActions: scene.characterActions,
    camera: scene.camera,
    lighting: scene.lighting,
    environment: scene.environment,
    visualStyle: scene.visualStyle,
    transition: scene.transition,
    videoPrompt: scene.videoPrompt,
    negativePrompt: scene.negativePrompt,
    continuityNotes: scene.continuityNotes
  };
}

function validateStoryboardTiming(scenes: { startTime: number; endTime: number; duration: number }[], songDuration: number) {
  if (scenes.length === 0) {
    throw new KullaniciDostuHata('Hiç sahne oluşturulamadı. Lütfen şarkı sözlerini kontrol edip tekrar deneyin.');
  }
  for (const s of scenes) {
    if (s.duration <= 0) {
      throw new KullaniciDostuHata('Sıfır veya negatif süreli bir sahne tespit edildi. Sahne planı geçersiz.');
    }
  }
  const totalCovered = scenes[scenes.length - 1].endTime;
  if (Math.abs(totalCovered - songDuration) > songDuration * 0.15) {
    // Tolerans dahilinde uyar, engelleme (auto scene sizing yaklaşık olabilir).
    console.warn(
      `[storyboard] Uyarı: sahne planı toplam süresi (${totalCovered}s) şarkı süresinden (${songDuration}s) belirgin şekilde farklı.`
    );
  }
}

export async function approveStoryboard(projectId: string) {
  const storyboard = await prisma.storyboard.findUnique({ where: { projectId } });
  if (!storyboard) throw new KullaniciDostuHata('Sahne planı bulunamadı.');
  return prisma.storyboard.update({ where: { projectId }, data: { approvedAt: new Date() } });
}
