import ffmpeg from 'fluent-ffmpeg';
import fs from 'node:fs/promises';
import fsSync from 'node:fs';
import path from 'node:path';
import { prisma } from '@/lib/prisma';
import { projectSubPath, ensureProjectDirs } from '@/lib/paths';
import { KullaniciDostuHata } from '@/types';

if (process.env.FFMPEG_PATH) ffmpeg.setFfmpegPath(process.env.FFMPEG_PATH);
if (process.env.FFPROBE_PATH) ffmpeg.setFfprobePath(process.env.FFPROBE_PATH);

interface RenderResult {
  previewPath: string;
  finalPath: string;
}

/**
 * runQualityControl — final render öncesi zorunlu kontrol (bkz. §26).
 * Eksik/bozuk bir şey varsa render BAŞLAMAZ ve Türkçe açık bir hata döner.
 */
async function runQualityControl(projectId: string) {
  const storyboard = await prisma.storyboard.findUnique({
    where: { projectId },
    include: { scenes: { orderBy: { order: 'asc' }, include: { asset: true } }, project: { include: { song: true } } }
  });
  if (!storyboard) throw new KullaniciDostuHata('Sahne planı bulunamadı.');
  if (!storyboard.project.song) {
    throw new KullaniciDostuHata('Orijinal şarkı dosyası bulunamadı. Final video oluşturulamaz.');
  }

  const missing = storyboard.scenes.filter((s) => s.generationStatus !== 'COMPLETED' || !s.asset);
  if (missing.length > 0) {
    const list = missing.map((s) => `Sahne ${s.order + 1}`).join(', ');
    throw new KullaniciDostuHata(
      `Final video oluşturulamıyor: şu sahneler eksik veya tamamlanmamış: ${list}. ` +
        'Lütfen eksik sahneleri önce üretin ya da yeniden deneyin.',
      `Eksik sahne sayısı: ${missing.length}`
    );
  }

  for (const scene of storyboard.scenes) {
    const p = scene.asset!.storagePath;
    if (!fsSync.existsSync(p)) {
      throw new KullaniciDostuHata(`Sahne ${scene.order + 1} için video dosyası diskte bulunamadı.`, p);
    }
    const stat = await fs.stat(p);
    if (stat.size === 0) {
      throw new KullaniciDostuHata(`Sahne ${scene.order + 1} dosyası boş (0 byte). Video bozuk olabilir.`, p);
    }
  }

  return storyboard;
}

function probe(filePath: string): Promise<ffmpeg.FfprobeData> {
  return new Promise((resolve, reject) => {
    ffmpeg.ffprobe(filePath, (err, data) => (err ? reject(err) : resolve(data)));
  });
}

/**
 * Tüm sahneleri normalize edip birleştirir, ardından kullanıcının orijinal
 * şarkısını NİHAİ ses parçası olarak kullanır (video modelinin ürettiği ses
 * KULLANILMAZ — bkz. spesifikasyon "The user's uploaded song MUST remain the
 * primary/final audio track").
 */
export async function renderFinalVideo(projectId: string): Promise<RenderResult> {
  const storyboard = await runQualityControl(projectId);
  const project = storyboard.project;
  await ensureProjectDirs(project.slug);

  await prisma.project.update({ where: { id: projectId }, data: { status: 'RENDERING' } });

  const [targetW, targetH] = resolveDims(project.aspectRatio, project.resolution);
  const tmpDir = path.join(process.cwd(), 'projects', project.slug, 'output', '.tmp');
  await fs.mkdir(tmpDir, { recursive: true });

  // 1) Normalize each scene to the same codec/resolution/fps (avoid concat errors across providers).
  const normalizedPaths: string[] = [];
  for (const scene of storyboard.scenes) {
    const src = scene.asset!.storagePath;
    const dst = path.join(tmpDir, `norm-${String(scene.order + 1).padStart(2, '0')}.mp4`);
    await normalizeClip(src, dst, targetW, targetH);
    normalizedPaths.push(dst);
  }

  // 2) Concatenate normalized scenes (video only, no audio yet).
  const concatListPath = path.join(tmpDir, 'concat.txt');
  await fs.writeFile(concatListPath, normalizedPaths.map((p) => `file '${p.replace(/'/g, "'\\''")}'`).join('\n'), 'utf-8');
  const concatenatedPath = path.join(tmpDir, 'concatenated.mp4');
  await concatClips(concatListPath, concatenatedPath);

  // 3) Mux with the user's original song as the ONLY audio track; video length wins, song is trimmed/padded to match.
  const songPath = project.song!.storagePath;
  const finalPath = projectSubPath(project.slug, 'output', 'final.mp4');
  const previewPath = projectSubPath(project.slug, 'output', 'preview.mp4');

  await muxWithSong(concatenatedPath, songPath, finalPath);
  await createPreview(finalPath, previewPath);

  await prisma.videoAsset.create({
    data: { projectId, kind: 'FINAL', storagePath: finalPath, provider: null }
  });
  await prisma.videoAsset.create({
    data: { projectId, kind: 'PREVIEW', storagePath: previewPath, provider: null }
  });

  await fs.rm(tmpDir, { recursive: true, force: true });
  await prisma.project.update({ where: { id: projectId }, data: { status: 'COMPLETED' } });

  return { previewPath, finalPath };
}

function normalizeClip(src: string, dst: string, w: number, h: number): Promise<void> {
  return new Promise((resolve, reject) => {
    ffmpeg(src)
      .videoFilters([`scale=${w}:${h}:force_original_aspect_ratio=decrease`, `pad=${w}:${h}:(ow-iw)/2:(oh-ih)/2`])
      .outputOptions(['-r 30', '-pix_fmt yuv420p', '-c:v libx264', '-preset veryfast', '-crf 20', '-an'])
      .save(dst)
      .on('end', () => resolve())
      .on('error', (err) => reject(new KullaniciDostuHata('Sahne normalize edilirken hata oluştu.', String(err))));
  });
}

function concatClips(listPath: string, dst: string): Promise<void> {
  return new Promise((resolve, reject) => {
    ffmpeg()
      .input(listPath)
      .inputOptions(['-f concat', '-safe 0'])
      .outputOptions(['-c copy'])
      .save(dst)
      .on('end', () => resolve())
      .on('error', (err) => reject(new KullaniciDostuHata('Sahneler birleştirilirken hata oluştu.', String(err))));
  });
}

function muxWithSong(videoPath: string, songPath: string, dst: string): Promise<void> {
  return new Promise((resolve, reject) => {
    ffmpeg()
      .input(videoPath)
      .input(songPath)
      .outputOptions(['-map 0:v:0', '-map 1:a:0', '-c:v copy', '-c:a aac', '-b:a 192k', '-shortest'])
      .save(dst)
      .on('end', () => resolve())
      .on('error', (err) => reject(new KullaniciDostuHata('Final video, şarkı ile birleştirilirken hata oluştu.', String(err))));
  });
}

function createPreview(finalPath: string, previewPath: string): Promise<void> {
  return new Promise((resolve, reject) => {
    ffmpeg(finalPath)
      .outputOptions(['-t 20', '-c:v libx264', '-crf 28', '-preset veryfast', '-c:a aac', '-b:a 96k'])
      .save(previewPath)
      .on('end', () => resolve())
      .on('error', (err) => reject(new KullaniciDostuHata('Önizleme videosu oluşturulurken hata oluştu.', String(err))));
  });
}

export async function getAudioDuration(filePath: string): Promise<number> {
  const data = await probe(filePath);
  return data.format.duration ?? 0;
}

/**
 * Bir sahne klibinin SON karesini bir JPEG olarak çıkarır. Bu, bir sonraki
 * sahnenin "image-to-video" referansı olarak kullanılır ve görsel
 * sürekliliği artırır (bkz. video-generation.service.ts).
 */
export async function extractLastFrame(videoPath: string, destPath: string): Promise<void> {
  await fs.mkdir(path.dirname(destPath), { recursive: true });
  return new Promise((resolve, reject) => {
    ffmpeg(videoPath)
      .seekInput('99%')
      .frames(1)
      .save(destPath)
      .on('end', () => resolve())
      .on('error', (err) => reject(new KullaniciDostuHata('Referans kare çıkarılırken hata oluştu.', String(err))));
  });
}

function resolveDims(aspect: string, resolution: string): [number, number] {
  const base: Record<string, number> = { '720p': 720, '1080p': 1080, '4K': 2160 };
  const h = base[resolution] ?? 1080;
  if (aspect === '9:16') return [Math.round((h * 9) / 16 / 2) * 2, h];
  if (aspect === '1:1') return [h, h];
  return [Math.round((h * 16) / 9 / 2) * 2, h];
}
