import { prisma } from '@/lib/prisma';
import { getLLMProvider } from '@/providers/llm';
import { projectSubPath, ensureProjectDirs } from '@/lib/paths';
import fs from 'node:fs/promises';
import { KullaniciDostuHata } from '@/types';

interface TimedLine {
  index: number;
  startMs: number;
  endMs: number;
  text: string;
}

function msToSrtTime(ms: number): string {
  const h = Math.floor(ms / 3600000);
  const m = Math.floor((ms % 3600000) / 60000);
  const s = Math.floor((ms % 60000) / 1000);
  const millis = ms % 1000;
  return `${pad(h, 2)}:${pad(m, 2)}:${pad(s, 2)},${pad(millis, 3)}`;
}
function pad(n: number, len: number) {
  return String(n).padStart(len, '0');
}

function linesToSrt(lines: TimedLine[]): string {
  return lines
    .map((l) => `${l.index}\n${msToSrtTime(l.startMs)} --> ${msToSrtTime(l.endMs)}\n${l.text}\n`)
    .join('\n');
}

/**
 * Şarkı sözlerinden makul satır zamanlamaları üretir. Kelime bazlı kesin
 * zamanlama yoksa (forced-alignment entegre edilmemişse) sahne planındaki
 * sahne sürelerine göre orantılı bir dağıtım yapılır — bkz. §12.
 */
export async function generateOriginalSubtitles(projectId: string): Promise<TimedLine[]> {
  const project = await prisma.project.findUnique({
    where: { id: projectId },
    include: { lyrics: true, song: true, storyboard: { include: { scenes: { orderBy: { order: 'asc' } } } } }
  });
  if (!project?.lyrics?.content) throw new KullaniciDostuHata('Şarkı sözleri bulunamadı.');
  if (!project.song) throw new KullaniciDostuHata('Şarkı dosyası bulunamadı.');

  const rawLines = project.lyrics.content.split('\n').map((l) => l.trim()).filter(Boolean);
  const scenes = project.storyboard?.scenes ?? [];

  let timedLines: TimedLine[];
  if (scenes.length > 0) {
    // Sahne planı varsa satırları sahne zamanlarına orantılı dağıt.
    timedLines = rawLines.map((text, i) => {
      const scene = scenes[Math.min(i % scenes.length, scenes.length - 1)];
      const segmentDuration = (scene.endTime - scene.startTime) * 1000;
      const linesInScene = Math.max(1, Math.ceil(rawLines.length / scenes.length));
      const localIndex = i % linesInScene;
      const start = scene.startTime * 1000 + localIndex * (segmentDuration / linesInScene);
      const end = start + segmentDuration / linesInScene;
      return { index: i + 1, startMs: Math.round(start), endMs: Math.round(end), text };
    });
  } else {
    // Sahne planı yoksa şarkı süresine eşit aralıklarla dağıt.
    const totalMs = project.song.durationSeconds * 1000;
    const perLine = totalMs / Math.max(1, rawLines.length);
    timedLines = rawLines.map((text, i) => ({
      index: i + 1,
      startMs: Math.round(i * perLine),
      endMs: Math.round((i + 1) * perLine),
      text
    }));
  }

  await ensureProjectDirs(project.slug);
  const srt = linesToSrt(timedLines);
  const filePath = projectSubPath(project.slug, 'subtitles', 'TR.srt');
  await fs.writeFile(filePath, srt, 'utf-8');

  await prisma.subtitle.upsert({
    where: { projectId_language: { projectId, language: 'TR' } },
    update: { content: srt, storagePath: filePath, isOriginal: true },
    create: { projectId, language: 'TR', content: srt, storagePath: filePath, isOriginal: true }
  });

  return timedLines;
}

const TARGET_LANGUAGES = ['EN', 'DE', 'ES', 'AR'] as const;

export async function translateAllSubtitles(projectId: string, originalLines: TimedLine[]) {
  const project = await prisma.project.findUnique({ where: { id: projectId }, include: { characters: true } });
  if (!project) throw new KullaniciDostuHata('Proje bulunamadı.');

  const llm = getLLMProvider();
  const protectedNames = project.characters.map((c) => c.name);

  const results: Record<string, string> = {};
  for (const lang of TARGET_LANGUAGES) {
    const translated = await llm.translateSubtitles({ lines: originalLines, targetLanguage: lang, protectedNames });
    const srt = linesToSrt(translated);
    const filePath = projectSubPath(project.slug, 'subtitles', `${lang}.srt`);
    await fs.writeFile(filePath, srt, 'utf-8');
    await prisma.subtitle.upsert({
      where: { projectId_language: { projectId, language: lang } },
      update: { content: srt, storagePath: filePath, isOriginal: false },
      create: { projectId, language: lang, content: srt, storagePath: filePath, isOriginal: false }
    });
    results[lang] = srt;
  }
  return results;
}

export async function generateAllSubtitles(projectId: string) {
  const original = await generateOriginalSubtitles(projectId);
  await translateAllSubtitles(projectId, original);
}
