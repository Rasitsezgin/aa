import ffmpeg from 'fluent-ffmpeg';
import fs from 'node:fs/promises';
import { prisma } from '@/lib/prisma';
import { projectSubPath, ensureProjectDirs } from '@/lib/paths';
import { KullaniciDostuHata } from '@/types';

if (process.env.FFMPEG_PATH) ffmpeg.setFfmpegPath(process.env.FFMPEG_PATH);

function escapeForDrawtext(text: string) {
  return text.replace(/\\/g, '\\\\').replace(/:/g, '\\:').replace(/'/g, "\\'");
}

/**
 * Gerçek üretilen videodan ilginç bir kare seçer (varsayılan: videonun ~%35
 * noktası — genelde en canlı sahne aralığıdır) ve üzerine en fazla 3
 * kelimelik, okunaklı Türkçe metin bindirir (bkz. §13, §27).
 * Alakasız stok görseller KULLANILMAZ.
 */
export async function generateThumbnail(projectId: string, overlayTextInput?: string, frameSeekSeconds?: number) {
  const project = await prisma.project.findUnique({
    where: { id: projectId },
    include: { assets: { where: { kind: 'FINAL' } }, publishPackage: true }
  });
  if (!project) throw new KullaniciDostuHata('Proje bulunamadı.');

  const finalAsset = project.assets[0];
  if (!finalAsset) {
    throw new KullaniciDostuHata('Thumbnail oluşturulamıyor: önce final video oluşturulmalı.');
  }

  const overlayText = (overlayTextInput || project.publishPackage?.thumbnailText || 'Neler Oldu?')
    .split(/\s+/)
    .slice(0, 3)
    .join(' ');

  await ensureProjectDirs(project.slug);
  const thumbPath = projectSubPath(project.slug, 'thumbnail', 'thumbnail.jpg');

  const [w] = resolveThumbDims(project.aspectRatio);

  await new Promise<void>((resolve, reject) => {
    const seek = frameSeekSeconds ?? undefined;
    const cmd = ffmpeg(finalAsset.storagePath);
    if (seek != null) {
      cmd.seekInput(seek);
    } else {
      cmd.seekInput('35%');
    }
    cmd
      .frames(1)
      .videoFilters([
        { filter: 'scale', options: `${w}:-2` },
        {
          filter: 'drawtext',
          options: {
            text: escapeForDrawtext(overlayText),
            fontcolor: 'white',
            fontsize: Math.round(w / 12),
            borderw: 8,
            bordercolor: 'black',
            x: '(w-text_w)/2',
            y: 'h-text_h-(h*0.08)'
          }
        }
      ])
      .save(thumbPath)
      .on('end', () => resolve())
      .on('error', (err) => reject(new KullaniciDostuHata('Thumbnail oluşturulurken hata oluştu.', String(err))));
  });

  await prisma.thumbnail.upsert({
    where: { projectId },
    update: { storagePath: thumbPath, overlayText, sourceFrame: `${frameSeekSeconds ?? '35%'}` },
    create: { projectId, storagePath: thumbPath, overlayText, sourceFrame: `${frameSeekSeconds ?? '35%'}` }
  });

  return thumbPath;
}

function resolveThumbDims(aspect: string): [number, number] {
  if (aspect === '9:16') return [1080, 1920];
  if (aspect === '1:1') return [1080, 1080];
  return [1280, 720]; // YouTube standard thumbnail width for 16:9
}
