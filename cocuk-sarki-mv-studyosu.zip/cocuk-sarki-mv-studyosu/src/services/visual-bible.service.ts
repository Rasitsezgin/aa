import { VisualBible, StoryboardScene } from '@/types';

/**
 * assembleScenePrompt — her sahne prompt'unu şu sırayla birleştirir:
 * GLOBAL STYLE + CHARACTER BIBLE + ENVIRONMENT BIBLE + SCENE ACTION +
 * CAMERA + LIGHTING + CONTINUITY REQUIREMENTS (bkz. spesifikasyon §8).
 *
 * Bu, her sahnenin karakter görünümünü bağımsız olarak "icat etmesini"
 * önleyen tek kaynak (single source of truth) mekanizmasıdır.
 */
export function assembleScenePrompt(bible: VisualBible, scene: StoryboardScene): string {
  const parts = [
    `[GENEL STİL] ${bible.globalStyle}`,
    `[KARAKTER İNCİLİ] ${bible.characterBible}`,
    `[ORTAM İNCİLİ] ${bible.environmentBible}`,
    scene.location ? `[MEKAN] ${scene.location}` : null,
    `[SAHNE AKSİYONU] ${scene.characterActions ?? scene.narrativePurpose ?? ''}`,
    scene.camera ? `[KAMERA] ${scene.camera}` : bible.cameraLanguage ? `[KAMERA] ${bible.cameraLanguage}` : null,
    scene.lighting ? `[IŞIK] ${scene.lighting}` : bible.lighting ? `[IŞIK] ${bible.lighting}` : null,
    bible.recurringProps.length ? `[TEKRARLAYAN ÖĞELER] ${bible.recurringProps.join(', ')}` : null,
    bible.colorPalette.length ? `[RENK PALETİ] ${bible.colorPalette.join(', ')}` : null,
    `[SÜREKLİLİK] ${scene.continuityNotes ?? 'Önceki sahnedeki karakter görünümü birebir korunmalı.'}`,
    bible.visualRules.length ? `[KURALLAR] ${bible.visualRules.join(' | ')}` : null
  ].filter(Boolean);

  return parts.join('\n');
}

export function assembleAllScenePrompts(bible: VisualBible, scenes: StoryboardScene[]): StoryboardScene[] {
  return scenes.map((scene) => ({
    ...scene,
    videoPrompt: assembleScenePrompt(bible, scene)
  }));
}
