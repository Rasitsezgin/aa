import { prisma } from '@/lib/prisma';
import { getLLMProvider } from '@/providers/llm';
import { projectSubPath, ensureProjectDirs } from '@/lib/paths';
import fs from 'node:fs/promises';
import { KullaniciDostuHata } from '@/types';

export async function analyzeSongForProject(projectId: string) {
  const project = await prisma.project.findUnique({
    where: { id: projectId },
    include: { song: true, lyrics: true }
  });

  if (!project) throw new KullaniciDostuHata('Proje bulunamadı.');
  if (!project.lyrics?.content) {
    throw new KullaniciDostuHata('Önce şarkı sözlerini girmelisiniz.', 'Lyrics.content boş.');
  }
  if (!project.song) {
    throw new KullaniciDostuHata('Önce bir şarkı dosyası yüklemelisiniz.', 'Song kaydı yok.');
  }

  await prisma.project.update({ where: { id: projectId }, data: { status: 'ANALYZING' } });

  const llm = getLLMProvider();
  const analysis = await llm.analyzeSong({
    lyrics: project.lyrics.content,
    songTitleHint: project.title,
    durationSeconds: project.song.durationSeconds
  });

  await prisma.lyrics.update({
    where: { projectId },
    data: { analysis: analysis as unknown as object }
  });

  await ensureProjectDirs(project.slug);
  const outPath = projectSubPath(project.slug, 'analysis', 'song-analysis.json');
  await fs.writeFile(outPath, JSON.stringify(analysis, null, 2), 'utf-8');

  await prisma.project.update({ where: { id: projectId }, data: { status: 'STORYBOARD_READY' } });

  return analysis;
}
