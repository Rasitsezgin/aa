import { prisma } from '@/lib/prisma';
import { getLLMProvider } from '@/providers/llm';
import { projectSubPath, ensureProjectDirs } from '@/lib/paths';
import fs from 'node:fs/promises';
import { KullaniciDostuHata, SongAnalysis, SongAnalysisSchema } from '@/types';

export async function generateYoutubePublishPackage(projectId: string) {
  const project = await prisma.project.findUnique({ where: { id: projectId }, include: { lyrics: true } });
  if (!project) throw new KullaniciDostuHata('Proje bulunamadı.');
  if (!project.lyrics?.analysis) {
    throw new KullaniciDostuHata('Önce şarkı analizi çalıştırılmalı.');
  }

  const parsed = SongAnalysisSchema.safeParse(project.lyrics.analysis);
  if (!parsed.success) throw new KullaniciDostuHata('Kayıtlı analiz bozuk. Analizi yeniden çalıştırın.');
  const analysis: SongAnalysis = parsed.data;

  const llm = getLLMProvider();
  const draft = await llm.generateYoutubePackage({ analysis, title: project.title });

  const saved = await prisma.publishPackage.upsert({
    where: { projectId },
    update: draft,
    create: { projectId, ...draft }
  });

  await ensureProjectDirs(project.slug);
  await fs.writeFile(projectSubPath(project.slug, 'publish', 'youtube.json'), JSON.stringify(draft, null, 2), 'utf-8');
  await fs.writeFile(
    projectSubPath(project.slug, 'publish', 'youtube.txt'),
    [
      `BAŞLIK:\n${draft.title}`,
      `\nKISA AÇIKLAMA:\n${draft.shortDescription}`,
      `\nUZUN AÇIKLAMA:\n${draft.longDescription}`,
      `\nETİKETLER (HASHTAG):\n${draft.hashtags.join(' ')}`,
      `\nARAMA ETİKETLERİ:\n${draft.tags.join(', ')}`,
      `\nTHUMBNAIL METNİ:\n${draft.thumbnailText}`,
      `\nSABİTLENECEK YORUM:\n${draft.pinnedComment}`,
      `\nÖNERİLEN OYNATMA LİSTESİ:\n${draft.playlistSuggestion}`
    ].join('\n'),
    'utf-8'
  );

  return saved;
}
