import fs from 'node:fs/promises';
import { prisma } from '@/lib/prisma';
import { getVideoProvider } from '@/providers/video';
import { projectSubPath, ensureProjectDirs } from '@/lib/paths';
import { extractLastFrame } from '@/services/ffmpeg.service';
import { KullaniciDostuHata } from '@/types';
import type { GenerationStatus } from '@prisma/client';

/**
 * Bir sahnenin üretim işini kuyruğa alır (asenkron — bu fonksiyon web
 * isteğini bloklamaz; gerçek üretim BullMQ worker'ında yürütülür, bkz.
 * src/jobs/workers/generate-scene.worker.ts).
 */
export async function enqueueSceneGeneration(sceneId: string, opts?: { force?: boolean }) {
  const scene = await prisma.scene.findUnique({
    where: { id: sceneId },
    include: { storyboard: { include: { project: true } } }
  });
  if (!scene) throw new KullaniciDostuHata('Sahne bulunamadı.');

  if (scene.generationStatus === 'COMPLETED' && !opts?.force) {
    // Kural §9: başarılı sahneler kullanıcı açıkça istemedikçe yeniden üretilmez.
    return scene;
  }

  await prisma.scene.update({ where: { id: sceneId }, data: { generationStatus: 'QUEUED' } });

  const job = await prisma.generationJob.create({
    data: {
      projectId: scene.storyboard.projectId,
      sceneId: scene.id,
      type: 'GENERATE_SCENE',
      status: 'QUEUED',
      provider: scene.storyboard.project.videoProviderKey
    }
  });

  const { videoGenerationQueue } = await import('@/lib/queue');
  await videoGenerationQueue.add('generate-scene', { sceneId, jobId: job.id }, { attempts: 3, backoff: { type: 'exponential', delay: 5000 } });

  return scene;
}

export async function enqueueAllScenes(projectId: string, opts?: { onlySceneIds?: string[] }) {
  const storyboard = await prisma.storyboard.findUnique({
    where: { projectId },
    include: { scenes: { orderBy: { order: 'asc' } } }
  });
  if (!storyboard) throw new KullaniciDostuHata('Sahne planı bulunamadı. Önce storyboard oluşturun.');
  if (!storyboard.approvedAt) {
    throw new KullaniciDostuHata('Video üretimi başlamadan önce sahne planını onaylamalısınız.');
  }

  const targetScenes = opts?.onlySceneIds
    ? storyboard.scenes.filter((s) => opts.onlySceneIds!.includes(s.id))
    : storyboard.scenes;

  await prisma.project.update({ where: { id: projectId }, data: { status: 'GENERATING' } });

  for (const scene of targetScenes) {
    await enqueueSceneGeneration(scene.id);
  }
  return targetScenes.length;
}

/**
 * Maliyet/kullanım tahmini — pahalı toplu üretimden önce kullanıcıya gösterilir (bkz. §10).
 */
export async function estimateGenerationCost(projectId: string) {
  const storyboard = await prisma.storyboard.findUnique({
    where: { projectId },
    include: { scenes: true, project: true }
  });
  if (!storyboard) throw new KullaniciDostuHata('Sahne planı bulunamadı.');

  const provider = storyboard.project.videoProviderKey;
  const totalDuration = storyboard.scenes.reduce((sum, s) => sum + s.duration, 0);

  // Sağlayıcıya göre yaklaşık birim maliyet (gerçek fiyatlandırma sağlayıcıdan alınmalı).
  const approxCostPerSecond: Record<string, number | null> = {
    demo: 0,
    veo: null,
    runway: null,
    luma: null
  };

  return {
    sceneCount: storyboard.scenes.length,
    estimatedTotalDurationSeconds: Number(totalDuration.toFixed(1)),
    provider,
    estimatedCostUsd: approxCostPerSecond[provider] != null ? approxCostPerSecond[provider]! * totalDuration : null,
    note:
      approxCostPerSecond[provider] == null
        ? 'Bu sağlayıcı için maliyet bilgisi mevcut değil; lütfen sağlayıcının güncel fiyatlandırmasını kontrol edin.'
        : undefined
  };
}

/**
 * Tek bir sahnenin gerçek üretim/indirme adımı. BullMQ worker'ı tarafından çağrılır.
 */
export async function processSceneGeneration(sceneId: string, jobId: string) {
  const scene = await prisma.scene.findUnique({
    where: { id: sceneId },
    include: { storyboard: { include: { project: true } } }
  });
  if (!scene) throw new KullaniciDostuHata('Sahne bulunamadı.');

  const project = scene.storyboard.project;
  const providerKey = project.videoProviderKey;

  const updateStatus = async (status: GenerationStatus, extra?: Record<string, unknown>) => {
    await prisma.scene.update({ where: { id: sceneId }, data: { generationStatus: status } });
    await prisma.generationJob.update({ where: { id: jobId }, data: { status, ...extra } });
  };

  try {
    await updateStatus('SUBMITTING');
    const { provider, usedDemoFallback } = getVideoProvider(providerKey);

    const [w, h] = resolveDims(project.aspectRatio, project.resolution);

    // Görsel süreklilik: "orta/yüksek" seçiliyse ve önceki sahne tamamlanmışsa,
    // önceki sahnenin SON karesini bu sahnenin referans görseli olarak
    // kullanırız (image-to-video). Bu, karakterlerin sahneler arasında aynı
    // kalması olasılığını artırır — ancak sağlayıcının kendi yeteneğine
    // bağlıdır, mutlak bir garanti değildir.
    let referenceImageUrl: string | undefined;
    if (project.continuity !== 'low' && scene.order > 0 && providerKey !== 'demo') {
      referenceImageUrl = await buildContinuityReferenceUrl(project, scene.order);
    }

    const commonInput = {
      prompt: scene.videoPrompt,
      negativePrompt: scene.negativePrompt ?? undefined,
      aspectRatio: project.aspectRatio as '16:9' | '9:16' | '1:1',
      resolution: project.resolution as '720p' | '1080p' | '4K',
      durationSeconds: Math.min(scene.duration, provider.maxSceneDurationSeconds)
    };

    const handle = referenceImageUrl
      ? await provider.generateImageToVideo({ ...commonInput, imageUrl: referenceImageUrl })
      : await provider.generateTextToVideo(commonInput);

    await prisma.generationJob.update({
      where: { id: jobId },
      data: { externalJobId: handle.externalJobId, status: 'GENERATING', startedAt: new Date() }
    });
    await updateStatus('GENERATING');

    // Poll until completion (demo provider resolves almost immediately).
    let attempts = 0;
    let status = await provider.getGenerationStatus(handle.externalJobId);
    while (status.status !== 'completed' && status.status !== 'failed' && attempts < 60) {
      await sleep(2000);
      status = await provider.getGenerationStatus(handle.externalJobId);
      attempts += 1;
    }

    if (status.status !== 'completed') {
      throw new KullaniciDostuHata(
        'Video üretimi tamamlanamadı. Lütfen sahneyi yeniden deneyin.',
        status.errorMessage || 'Zaman aşımı veya sağlayıcı hatası.'
      );
    }

    await updateStatus('DOWNLOADING');
    await ensureProjectDirs(project.slug);
    const destPath = projectSubPath(project.slug, 'scenes', `scene-${String(scene.order + 1).padStart(2, '0')}.mp4`);
    await provider.downloadVideo(handle.externalJobId, destPath);

    // Bir sonraki sahnenin referans karesi için bu sahnenin son karesini çıkar.
    try {
      const framePath = projectSubPath(project.slug, 'scenes', `scene-${String(scene.order + 1).padStart(2, '0')}-ref.jpg`);
      await extractLastFrame(destPath, framePath);
    } catch (frameErr) {
      console.warn(`[video-generation] Referans kare çıkarılamadı (sahne ${scene.order + 1}):`, frameErr);
    }

    await updateStatus('PROCESSING');
    await prisma.videoAsset.upsert({
      where: { sceneId },
      update: { storagePath: destPath, provider: usedDemoFallback ? 'demo' : providerKey, width: w, height: h },
      create: {
        projectId: project.id,
        sceneId,
        kind: 'SCENE_RAW',
        storagePath: destPath,
        provider: usedDemoFallback ? 'demo' : providerKey,
        width: w,
        height: h
      }
    });

    const note = usedDemoFallback
      ? `Uyarı: "${providerKey}" için API anahtarı bulunamadığı için bu sahne Demo Modu ile üretildi.`
      : referenceImageUrl
        ? 'Önceki sahnenin son karesi referans görsel olarak kullanıldı.'
        : undefined;

    await updateStatus('COMPLETED', { finishedAt: new Date(), resultJson: { videoUrl: status.videoUrl, not: note } });
    return { success: true, path: destPath };
  } catch (err) {
    const message = err instanceof KullaniciDostuHata ? err.turkceMesaj : 'Sahne üretimi sırasında beklenmeyen bir hata oluştu.';
    const detail = err instanceof KullaniciDostuHata ? err.teknikDetay : String(err);
    await updateStatus('FAILED', { errorMessage: message, errorDetail: detail, finishedAt: new Date() });
    throw err;
  }
}

function resolveDims(aspect: string, resolution: string): [number, number] {
  const base: Record<string, number> = { '720p': 720, '1080p': 1080, '4K': 2160 };
  const h = base[resolution] ?? 1080;
  if (aspect === '9:16') return [Math.round((h * 9) / 16), h];
  if (aspect === '1:1') return [h, h];
  return [Math.round((h * 16) / 9), h];
}

/**
 * Önceki sahnenin son karesini, sağlayıcının internetten çekebileceği bir
 * genel (public) URL'e çevirir. APP_URL .env'de tanımlı olmalı ve sunucu
 * dışarıdan erişilebilir olmalıdır (bkz. deploy/nginx.conf.example).
 * APP_URL tanımlı değilse veya kare dosyası yoksa sessizce atlanır — bu
 * durumda sahne normal text-to-video ile üretilmeye devam eder.
 */
async function buildContinuityReferenceUrl(
  project: { slug: string },
  currentOrder: number
): Promise<string | undefined> {
  const appUrl = process.env.APP_URL;
  if (!appUrl) return undefined;

  const prevOrder = currentOrder; // önceki sahne dosya adı 1-indeksli: order 0 → scene-01
  const frameFilename = `scene-${String(prevOrder).padStart(2, '0')}-ref.jpg`;
  const framePath = projectSubPath(project.slug, 'scenes', frameFilename);

  try {
    await fs.access(framePath);
  } catch {
    return undefined; // önceki sahnenin karesi henüz yok — sorun değil, atla
  }

  return `${appUrl.replace(/\/$/, '')}/api/assets/${project.slug}/scenes/${frameFilename}`;
}

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
