import { prisma } from '@/lib/prisma';
import { getVideoProvider } from '@/providers/video';
import { projectSubPath, ensureProjectDirs } from '@/lib/paths';
import { KullaniciDostuHata } from '@/types';
import type { GenerationStatus } from '@prisma/client';

/**
 * Bir sahnenin üretim işini kuyruğa alır (asenkron — bu fonksiyon web
 * isteğini bloklamaz; gerçek üretim BullMQ worker'ında yürütülür, bkz.
 * src/jobs/workers/generate-scene.worker.ts).
 */
export async function enqueueSceneGeneration(sceneId: string, opts?: { force?: boolean }) {
  const scene = await prisma.scene.findUnique({
    where: { id: sceneId },
    include: { storyboard: { include: { project: true } } }
  });
  if (!scene) throw new KullaniciDostuHata('Sahne bulunamadı.');

  if (scene.generationStatus === 'COMPLETED' && !opts?.force) {
    // Kural §9: başarılı sahneler kullanıcı açıkça istemedikçe yeniden üretilmez.
    return scene;
  }

  await prisma.scene.update({ where: { id: sceneId }, data: { generationStatus: 'QUEUED' } });

  const job = await prisma.generationJob.create({
    data: {
      projectId: scene.storyboard.projectId,
      sceneId: scene.id,
      type: 'GENERATE_SCENE',
      status: 'QUEUED',
      provider: scene.storyboard.project.videoProviderKey
    }
  });

  const { videoGenerationQueue } = await import('@/lib/queue');
  await videoGenerationQueue.add('generate-scene', { sceneId, jobId: job.id }, { attempts: 3, backoff: { type: 'exponential', delay: 5000 } });

  return scene;
}

export async function enqueueAllScenes(projectId: string, opts?: { onlySceneIds?: string[] }) {
  const storyboard = await prisma.storyboard.findUnique({
    where: { projectId },
    include: { scenes: { orderBy: { order: 'asc' } } }
  });
  if (!storyboard) throw new KullaniciDostuHata('Sahne planı bulunamadı. Önce storyboard oluşturun.');
  if (!storyboard.approvedAt) {
    throw new KullaniciDostuHata('Video üretimi başlamadan önce sahne planını onaylamalısınız.');
  }

  const targetScenes = opts?.onlySceneIds
    ? storyboard.scenes.filter((s) => opts.onlySceneIds!.includes(s.id))
    : storyboard.scenes;

  await prisma.project.update({ where: { id: projectId }, data: { status: 'GENERATING' } });

  for (const scene of targetScenes) {
    await enqueueSceneGeneration(scene.id);
  }
  return targetScenes.length;
}

/**
 * Maliyet/kullanım tahmini — pahalı toplu üretimden önce kullanıcıya gösterilir (bkz. §10).
 */
export async function estimateGenerationCost(projectId: string) {
  const storyboard = await prisma.storyboard.findUnique({
    where: { projectId },
    include: { scenes: true, project: true }
  });
  if (!storyboard) throw new KullaniciDostuHata('Sahne planı bulunamadı.');

  const provider = storyboard.project.videoProviderKey;
  const totalDuration = storyboard.scenes.reduce((sum, s) => sum + s.duration, 0);

  // Sağlayıcıya göre yaklaşık birim maliyet (gerçek fiyatlandırma sağlayıcıdan alınmalı).
  const approxCostPerSecond: Record<string, number | null> = {
    demo: 0,
    veo: null,
    runway: null,
    luma: null
  };

  return {
    sceneCount: storyboard.scenes.length,
    estimatedTotalDurationSeconds: Number(totalDuration.toFixed(1)),
    provider,
    estimatedCostUsd: approxCostPerSecond[provider] != null ? approxCostPerSecond[provider]! * totalDuration : null,
    note:
      approxCostPerSecond[provider] == null
        ? 'Bu sağlayıcı için maliyet bilgisi mevcut değil; lütfen sağlayıcının güncel fiyatlandırmasını kontrol edin.'
        : undefined
  };
}

/**
 * Tek bir sahnenin gerçek üretim/indirme adımı. BullMQ worker'ı tarafından çağrılır.
 */
export async function processSceneGeneration(sceneId: string, jobId: string) {
  const scene = await prisma.scene.findUnique({
    where: { id: sceneId },
    include: { storyboard: { include: { project: true } } }
  });
  if (!scene) throw new KullaniciDostuHata('Sahne bulunamadı.');

  const project = scene.storyboard.project;
  const providerKey = project.videoProviderKey;

  const updateStatus = async (status: GenerationStatus, extra?: Record<string, unknown>) => {
    await prisma.scene.update({ where: { id: sceneId }, data: { generationStatus: status } });
    await prisma.generationJob.update({ where: { id: jobId }, data: { status, ...extra } });
  };

  try {
    await updateStatus('SUBMITTING');
    const provider = getVideoProvider(providerKey);

    const [w, h] = resolveDims(project.aspectRatio, project.resolution);
    const handle = await provider.generateTextToVideo({
      prompt: scene.videoPrompt,
      negativePrompt: scene.negativePrompt ?? undefined,
      aspectRatio: project.aspectRatio as '16:9' | '9:16' | '1:1',
      resolution: project.resolution as '720p' | '1080p' | '4K',
      durationSeconds: Math.min(scene.duration, provider.maxSceneDurationSeconds)
    });

    await prisma.generationJob.update({
      where: { id: jobId },
      data: { externalJobId: handle.externalJobId, status: 'GENERATING', startedAt: new Date() }
    });
    await updateStatus('GENERATING');

    // Poll until completion (demo provider resolves almost immediately).
    let attempts = 0;
    let status = await provider.getGenerationStatus(handle.externalJobId);
    while (status.status !== 'completed' && status.status !== 'failed' && attempts < 60) {
      await sleep(2000);
      status = await provider.getGenerationStatus(handle.externalJobId);
      attempts += 1;
    }

    if (status.status !== 'completed') {
      throw new KullaniciDostuHata(
        'Video üretimi tamamlanamadı. Lütfen sahneyi yeniden deneyin.',
        status.errorMessage || 'Zaman aşımı veya sağlayıcı hatası.'
      );
    }

    await updateStatus('DOWNLOADING');
    await ensureProjectDirs(project.slug);
    const destPath = projectSubPath(project.slug, 'scenes', `scene-${String(scene.order + 1).padStart(2, '0')}.mp4`);
    await provider.downloadVideo(handle.externalJobId, destPath);

    await updateStatus('PROCESSING');
    await prisma.videoAsset.upsert({
      where: { sceneId },
      update: { storagePath: destPath, provider: providerKey, width: w, height: h },
      create: {
        projectId: project.id,
        sceneId,
        kind: 'SCENE_RAW',
        storagePath: destPath,
        provider: providerKey,
        width: w,
        height: h
      }
    });

    await updateStatus('COMPLETED', { finishedAt: new Date(), resultJson: { videoUrl: status.videoUrl } });
    return { success: true, path: destPath };
  } catch (err) {
    const message = err instanceof KullaniciDostuHata ? err.turkceMesaj : 'Sahne üretimi sırasında beklenmeyen bir hata oluştu.';
    const detail = err instanceof KullaniciDostuHata ? err.teknikDetay : String(err);
    await updateStatus('FAILED', { errorMessage: message, errorDetail: detail, finishedAt: new Date() });
    throw err;
  }
}

function resolveDims(aspect: string, resolution: string): [number, number] {
  const base: Record<string, number> = { '720p': 720, '1080p': 1080, '4K': 2160 };
  const h = base[resolution] ?? 1080;
  if (aspect === '9:16') return [Math.round((h * 9) / 16), h];
  if (aspect === '1:1') return [h, h];
  return [Math.round((h * 16) / 9), h];
}

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
