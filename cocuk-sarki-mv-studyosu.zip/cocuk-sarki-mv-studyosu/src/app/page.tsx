import Link from 'next/link';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export default async function DashboardPage() {
  // AÇIK MOD: giriş ekranı yok, panel doğrudan tek "Yerel Kullanıcı" ile açılır.
  const user = await getCurrentUser();

  const [toplamProje, tamamlanan, devamEden, basarisiz, toplamSahne, sonProjeler] = await Promise.all([
    prisma.project.count({ where: { ownerId: user.id } }),
    prisma.project.count({ where: { ownerId: user.id, status: 'COMPLETED' } }),
    prisma.project.count({ where: { ownerId: user.id, status: { in: ['GENERATING', 'RENDERING', 'ANALYZING'] } } }),
    prisma.project.count({ where: { ownerId: user.id, status: 'FAILED' } }),
    prisma.scene.count({ where: { storyboard: { project: { ownerId: user.id } } } }),
    prisma.project.findMany({ where: { ownerId: user.id }, orderBy: { updatedAt: 'desc' }, take: 5 })
  ]);

  const stats = [
    { label: 'Toplam Proje', value: toplamProje, icon: '📁' },
    { label: 'Tamamlanan Videolar', value: tamamlanan, icon: '✅' },
    { label: 'Devam Eden Üretimler', value: devamEden, icon: '⏳' },
    { label: 'Başarısız Üretimler', value: basarisiz, icon: '⚠️' },
    { label: 'Toplam Sahne', value: toplamSahne, icon: '🎞️' }
  ];

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Ana Sayfa</h1>
          <p className="text-studio-muted text-sm mt-1">Hoş geldiniz, {user.name || user.email}</p>
        </div>
        <Link href="/projeler/yeni" className="btn-primary">
          🎵 Yeni Çocuk Şarkısı Oluştur
        </Link>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        {stats.map((s) => (
          <div key={s.label} className="card">
            <div className="text-2xl">{s.icon}</div>
            <div className="text-2xl font-semibold mt-2">{s.value}</div>
            <div className="text-xs text-studio-muted mt-1">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="card">
        <h2 className="font-medium mb-4">Son Projeler</h2>
        {sonProjeler.length === 0 ? (
          <div className="text-studio-muted text-sm py-8 text-center">
            Henüz proje oluşturmadınız. Başlamak için "Yeni Çocuk Şarkısı Oluştur" düğmesine tıklayın.
          </div>
        ) : (
          <div className="space-y-2">
            {sonProjeler.map((p: (typeof sonProjeler)[number]) => (
              <Link
                key={p.id}
                href={`/projeler/${p.id}`}
                className="flex items-center justify-between px-4 py-3 rounded-xl hover:bg-studio-panel2 transition-colors"
              >
                <span className="font-medium">{p.title}</span>
                <span className="text-xs text-studio-muted">{p.status}</span>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
