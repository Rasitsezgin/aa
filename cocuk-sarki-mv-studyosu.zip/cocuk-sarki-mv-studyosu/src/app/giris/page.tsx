'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function GirisPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [hata, setHata] = useState<string | null>(null);
  const [yukleniyor, setYukleniyor] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setYukleniyor(true);
    setHata(null);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      const data = await res.json();
      if (!res.ok) {
        setHata(data.hata || 'Giriş başarısız.');
        return;
      }
      router.push('/');
      router.refresh();
    } catch {
      setHata('Sunucuya bağlanılamadı.');
    } finally {
      setYukleniyor(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-studio-bg">
      <form onSubmit={handleSubmit} className="card w-full max-w-sm space-y-4">
        <div className="text-center mb-2">
          <div className="text-2xl">🎬</div>
          <h1 className="text-lg font-semibold mt-2">Çocuk Şarkı MV Stüdyosu</h1>
          <p className="text-xs text-studio-muted mt-1">Devam etmek için giriş yapın</p>
        </div>

        {hata && <div className="text-sm text-studio-danger bg-studio-danger/10 rounded-lg px-3 py-2">{hata}</div>}

        <div>
          <label className="text-xs text-studio-muted mb-1 block">E-posta</label>
          <input
            className="input-field"
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="ornek@stüdyo.com"
          />
        </div>
        <div>
          <label className="text-xs text-studio-muted mb-1 block">Parola</label>
          <input
            className="input-field"
            type="password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="••••••••"
          />
        </div>

        <button type="submit" disabled={yukleniyor} className="btn-primary w-full">
          {yukleniyor ? 'Giriş yapılıyor…' : 'Giriş Yap'}
        </button>

        <p className="text-xs text-studio-muted text-center">
          Hesabınız yok mu? Sunucu yöneticinize başvurun ya da .env dosyasında ADMIN_EMAIL / ADMIN_PASSWORD tanımlayarak
          ilk kurulumda otomatik hesap oluşturun.
        </p>
      </form>
    </div>
  );
}
