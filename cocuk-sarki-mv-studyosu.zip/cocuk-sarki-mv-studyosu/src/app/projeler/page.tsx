import Link from 'next/link';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';
import { redirect } from 'next/navigation';
import { StatusBadge } from '@/components/StatusBadge';

export const dynamic = 'force-dynamic';

export default async function ProjelerPage() {
  const user = await getCurrentUser();
  if (!user) redirect('/giris');

  const projects = await prisma.project.findMany({
    where: { ownerId: user.id },
    orderBy: { updatedAt: 'desc' },
    include: { song: true, storyboard: { include: { scenes: true } } }
  });

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Projeler</h1>
        <Link href="/projeler/yeni" className="btn-primary">➕ Yeni Proje</Link>
      </div>

      {projects.length === 0 ? (
        <div className="card text-center py-16 text-studio-muted">
          Henüz hiç projeniz yok. <Link href="/projeler/yeni" className="text-studio-accent2 underline">İlk projenizi oluşturun</Link>.
        </div>
      ) : (
        <div className="grid md:grid-cols-2 gap-4">
          {projects.map((p: (typeof projects)[number]) => {
            const completedScenes =
              p.storyboard?.scenes.filter((s: (typeof p.storyboard.scenes)[number]) => s.generationStatus === 'COMPLETED').length ?? 0;
            const totalScenes = p.storyboard?.scenes.length ?? 0;
            return (
              <Link key={p.id} href={`/projeler/${p.id}`} className="card hover:border-studio-accent/50 transition-colors block">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-medium">{p.title}</h3>
                    <p className="text-xs text-studio-muted mt-1">
                      {p.song ? `${Math.round(p.song.durationSeconds)} sn şarkı` : 'Şarkı yüklenmedi'}
                    </p>
                  </div>
                  <StatusBadge status={p.status} />
                </div>
                {totalScenes > 0 && (
                  <div className="mt-4">
                    <div className="h-2 bg-studio-panel2 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-studio-accent"
                        style={{ width: `${Math.round((completedScenes / totalScenes) * 100)}%` }}
                      />
                    </div>
                    <div className="text-xs text-studio-muted mt-1">{completedScenes}/{totalScenes} sahne tamamlandı</div>
                  </div>
                )}
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
