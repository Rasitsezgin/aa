'use client';

import { useEffect, useState, useCallback } from 'react';
import { useParams } from 'next/navigation';
import { StatusBadge } from '@/components/StatusBadge';

const TABS = [
  ['analiz', 'Şarkı Analizi'],
  ['hikaye', 'Hikâye'],
  ['sahneler', 'Sahne Planı'],
  ['uretim', 'Video Üretimi'],
  ['altyazi', 'Altyazılar'],
  ['thumbnail', 'Thumbnail'],
  ['yayin', 'Yayın Planlayıcı'],
  ['ciktilar', 'Çıktılar']
] as const;

type TabKey = (typeof TABS)[number][0];

export default function ProjeDetayPage() {
  const params = useParams<{ id: string }>();
  const id = params.id;
  const [proje, setProje] = useState<any>(null);
  const [tab, setTab] = useState<TabKey>('analiz');
  const [isBusy, setIsBusy] = useState(false);
  const [mesaj, setMesaj] = useState<string | null>(null);
  const [hata, setHata] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    const res = await fetch(`/api/projects/${id}`);
    const data = await res.json();
    if (res.ok) setProje(data.proje);
  }, [id]);

  useEffect(() => {
    refresh();
    const interval = setInterval(refresh, 4000); // canlı ilerleme takibi
    return () => clearInterval(interval);
  }, [refresh]);

  async function call(url: string, method: string, body?: unknown) {
    setIsBusy(true);
    setHata(null);
    setMesaj(null);
    try {
      const res = await fetch(url, {
        method,
        headers: body ? { 'Content-Type': 'application/json' } : undefined,
        body: body ? JSON.stringify(body) : undefined
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.hata || 'İşlem başarısız oldu.');
      await refresh();
      return data;
    } catch (err: any) {
      setHata(err.message);
      throw err;
    } finally {
      setIsBusy(false);
    }
  }

  if (!proje) return <div className="text-studio-muted">Yükleniyor…</div>;

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">{proje.title}</h1>
          <p className="text-xs text-studio-muted mt-1">/{proje.slug}</p>
        </div>
        <StatusBadge status={proje.status} />
      </div>

      {hata && <div className="text-sm text-studio-danger bg-studio-danger/10 rounded-lg px-3 py-2">{hata}</div>}
      {mesaj && <div className="text-sm text-studio-success bg-studio-success/10 rounded-lg px-3 py-2">{mesaj}</div>}

      <div className="flex gap-1 overflow-x-auto border-b border-studio-border">
        {TABS.map(([key, label]) => (
          <button
            key={key}
            onClick={() => setTab(key)}
            className={`px-4 py-2.5 text-sm whitespace-nowrap border-b-2 transition-colors ${
              tab === key ? 'border-studio-accent text-white' : 'border-transparent text-studio-muted hover:text-studio-text'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === 'analiz' && (
        <div className="card space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-medium">Şarkı Analizi</h2>
            <button className="btn-primary" disabled={isBusy} onClick={() => call(`/api/projects/${id}/analyze`, 'POST')}>
              {proje.lyrics?.analysis ? '🔄 Yeniden Analiz Et' : '▶️ Analizi Başlat'}
            </button>
          </div>
          {proje.lyrics?.analysis ? (
            <pre className="bg-studio-panel2 rounded-xl p-4 text-xs overflow-x-auto whitespace-pre-wrap">
              {JSON.stringify(proje.lyrics.analysis, null, 2)}
            </pre>
          ) : (
            <p className="text-sm text-studio-muted">Henüz analiz çalıştırılmadı.</p>
          )}
        </div>
      )}

      {tab === 'hikaye' && (
        <div className="card space-y-2">
          <h2 className="font-medium mb-2">Hikâye</h2>
          {proje.storyboard ? (
            <div className="space-y-2 text-sm">
              <p><span className="text-studio-muted">Başlık:</span> {proje.storyboard.title}</p>
              <p><span className="text-studio-muted">Tema:</span> {proje.storyboard.theme}</p>
              <p><span className="text-studio-muted">Hikâye Akışı:</span> {proje.storyboard.storyArc}</p>
            </div>
          ) : (
            <p className="text-sm text-studio-muted">Sahne planı henüz oluşturulmadı — önce "Sahne Planı" sekmesinden oluşturun.</p>
          )}
        </div>
      )}

      {tab === 'sahneler' && (
        <div className="space-y-4">
          <div className="card flex items-center justify-between">
            <div>
              <h2 className="font-medium">Sahne Planı</h2>
              <p className="text-xs text-studio-muted mt-1">
                {proje.storyboard?.approvedAt ? '✅ Onaylandı' : 'Henüz onaylanmadı'}
              </p>
            </div>
            <div className="flex gap-2">
              {!proje.storyboard && (
                <button className="btn-primary" disabled={isBusy || !proje.lyrics?.analysis} onClick={() => call(`/api/projects/${id}/storyboard`, 'POST')}>
                  ▶️ Storyboard Önizleme Oluştur
                </button>
              )}
              {proje.storyboard && !proje.storyboard.approvedAt && (
                <button className="btn-primary" disabled={isBusy} onClick={() => call(`/api/projects/${id}/storyboard`, 'PATCH')}>
                  ✅ Planı Onayla
                </button>
              )}
            </div>
          </div>

          {proje.storyboard?.scenes?.map((scene: any) => (
            <div key={scene.id} className="card">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Sahne {scene.order + 1} — {scene.startTime}s → {scene.endTime}s</span>
                <StatusBadge status={scene.generationStatus} />
              </div>
              <p className="text-xs text-studio-muted mb-2">{scene.lyricsSegment}</p>
              <details className="text-xs">
                <summary className="cursor-pointer text-studio-accent2">Video prompt'unu göster</summary>
                <pre className="whitespace-pre-wrap mt-2 bg-studio-panel2 rounded-lg p-3">{scene.videoPrompt}</pre>
              </details>
            </div>
          ))}
        </div>
      )}

      {tab === 'uretim' && <UretimTab proje={proje} id={id} call={call} isBusy={isBusy} />}

      {tab === 'altyazi' && (
        <div className="space-y-4">
          <div className="card flex items-center justify-between">
            <h2 className="font-medium">Altyazılar</h2>
            <span className="text-xs text-studio-muted">Nihai render tamamlandığında otomatik oluşturulur.</span>
          </div>
          {proje.subtitles?.length ? (
            <div className="grid md:grid-cols-2 gap-3">
              {proje.subtitles.map((s: any) => (
                <div key={s.id} className="card">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium text-sm">{s.language}.srt</span>
                    {s.isOriginal && <span className="badge bg-studio-accent/15 text-studio-accent">Orijinal</span>}
                  </div>
                  <pre className="text-xs text-studio-muted whitespace-pre-wrap max-h-32 overflow-y-auto">{s.content.slice(0, 300)}…</pre>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-studio-muted card">Henüz altyazı yok.</p>
          )}
        </div>
      )}

      {tab === 'thumbnail' && (
        <div className="card space-y-3">
          <h2 className="font-medium">Thumbnail</h2>
          {proje.thumbnail ? (
            <div className="space-y-2">
              <p className="text-sm text-studio-muted">Metin: "{proje.thumbnail.overlayText}"</p>
              <p className="text-xs text-studio-muted">Dosya: {proje.thumbnail.storagePath}</p>
            </div>
          ) : (
            <p className="text-sm text-studio-muted">Thumbnail, nihai render tamamlandığında otomatik oluşturulur.</p>
          )}
        </div>
      )}

      {tab === 'yayin' && (
        <div className="card space-y-3">
          <h2 className="font-medium">Yayın Planlayıcı (YouTube)</h2>
          {proje.publishPackage ? (
            <div className="space-y-3 text-sm">
              <Field label="Başlık" value={proje.publishPackage.title} />
              <Field label="Kısa Açıklama" value={proje.publishPackage.shortDescription} />
              <Field label="Uzun Açıklama" value={proje.publishPackage.longDescription} />
              <Field label="Hashtag'ler" value={proje.publishPackage.hashtags?.join(' ')} />
              <Field label="Etiketler" value={proje.publishPackage.tags?.join(', ')} />
              <Field label="Thumbnail Metni" value={proje.publishPackage.thumbnailText} />
              <Field label="Sabitlenecek Yorum" value={proje.publishPackage.pinnedComment} />
              <Field label="Oynatma Listesi Önerisi" value={proje.publishPackage.playlistSuggestion} />
            </div>
          ) : (
            <p className="text-sm text-studio-muted">Yayın paketi, nihai render tamamlandığında otomatik oluşturulur.</p>
          )}
        </div>
      )}

      {tab === 'ciktilar' && (
        <div className="card space-y-3">
          <h2 className="font-medium">Çıktılar</h2>
          {proje.assets?.filter((a: any) => a.kind === 'FINAL' || a.kind === 'PREVIEW').length ? (
            <div className="space-y-2 text-sm">
              {proje.assets
                .filter((a: any) => a.kind === 'FINAL' || a.kind === 'PREVIEW')
                .map((a: any) => (
                  <div key={a.id} className="flex items-center justify-between bg-studio-panel2 rounded-lg px-3 py-2">
                    <span>{a.kind === 'FINAL' ? '🎬 final.mp4' : '👀 preview.mp4'}</span>
                    <span className="text-xs text-studio-muted">{a.storagePath}</span>
                  </div>
                ))}
              <p className="text-xs text-studio-muted mt-2">
                Dosyalar sunucudaki proje dizininde (<code>projects/{proje.slug}/output/</code>) yer alır.
              </p>
            </div>
          ) : (
            <p className="text-sm text-studio-muted">Henüz final video oluşturulmadı.</p>
          )}
        </div>
      )}
    </div>
  );
}

function Field({ label, value }: { label: string; value?: string }) {
  return (
    <div>
      <div className="text-xs text-studio-muted mb-1">{label}</div>
      <div className="bg-studio-panel2 rounded-lg px-3 py-2 whitespace-pre-wrap">{value || '—'}</div>
    </div>
  );
}

function UretimTab({ proje, id, call, isBusy }: { proje: any; id: string; call: any; isBusy: boolean }) {
  const [estimate, setEstimate] = useState<any>(null);

  useEffect(() => {
    fetch(`/api/projects/${id}/estimate`).then((r) => r.json()).then((d) => setEstimate(d.tahmin)).catch(() => {});
  }, [id, proje.storyboard?.scenes?.length]);

  const scenes = proje.storyboard?.scenes ?? [];
  const failedScenes = scenes.filter((s: any) => s.generationStatus === 'FAILED');

  return (
    <div className="space-y-4">
      <div className="card space-y-3">
        <h2 className="font-medium">Video Üretimi</h2>
        {estimate && (
          <div className="bg-studio-panel2 rounded-xl p-4 text-sm space-y-1">
            <p>Bu üretimde yaklaşık {estimate.sceneCount} sahne oluşturulacak.</p>
            <p>Toplam tahmini süre: {estimate.estimatedTotalDurationSeconds} saniye</p>
            <p>Sağlayıcı: {estimate.provider}</p>
            {estimate.note && <p className="text-studio-warning">{estimate.note}</p>}
          </div>
        )}
        <div className="flex gap-2 flex-wrap">
          <button
            className="btn-primary"
            disabled={isBusy || !proje.storyboard?.approvedAt}
            onClick={() => call(`/api/projects/${id}/generate`, 'POST', {})}
          >
            🎬 Tüm Sahneleri Üret
          </button>
          {failedScenes.length > 0 && (
            <button
              className="btn-secondary"
              disabled={isBusy}
              onClick={() => call(`/api/projects/${id}/generate`, 'POST', { sceneIds: failedScenes.map((s: any) => s.id), force: true })}
            >
              🔁 Başarısız Sahneleri Yeniden Dene ({failedScenes.length})
            </button>
          )}
          <button
            className="btn-secondary"
            disabled={isBusy || scenes.length === 0 || scenes.some((s: any) => s.generationStatus !== 'COMPLETED')}
            onClick={() => call(`/api/projects/${id}/render`, 'POST')}
          >
            🎞️ Final Videoyu Oluştur (FFmpeg)
          </button>
        </div>
        {!proje.storyboard?.approvedAt && (
          <p className="text-xs text-studio-warning">Üretime başlamadan önce "Sahne Planı" sekmesinden planı onaylayın.</p>
        )}
      </div>

      <div className="grid md:grid-cols-2 gap-3">
        {scenes.map((scene: any) => (
          <div key={scene.id} className="card flex items-center justify-between">
            <div>
              <div className="text-sm font-medium">Sahne {scene.order + 1}</div>
              <div className="text-xs text-studio-muted">{scene.duration}s</div>
            </div>
            <div className="flex items-center gap-2">
              <StatusBadge status={scene.generationStatus} />
              {scene.generationStatus === 'FAILED' && (
                <button
                  className="text-xs text-studio-accent2 underline"
                  onClick={() => call(`/api/scenes/${scene.id}/retry`, 'POST')}
                >
                  Yeniden Dene
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
