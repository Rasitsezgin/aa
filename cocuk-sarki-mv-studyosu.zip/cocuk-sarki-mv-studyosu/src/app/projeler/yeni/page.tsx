'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

type CharacterDraft = {
  name: string;
  age: string;
  gender: string;
  appearance: string;
  clothing: string;
  hair: string;
  personality: string;
  colors: string;
  accessories: string;
};

const VIDEO_STYLES = [
  '3D çizgi film',
  '2D çizgi film',
  'Pixar esintili aile animasyonu',
  'Anime esintili çocuk animasyonu',
  'Renkli okul öncesi animasyon',
  'Eğitici animasyon',
  'Gerçekçi',
  'Kullanıcı tanımlı'
];

const STEPS = ['Şarkını Yükle', 'Şarkı Sözleri', 'Video Stili', 'Karakterler', 'Video Ayarları'];

const emptyCharacter = (): CharacterDraft => ({
  name: '', age: '', gender: '', appearance: '', clothing: '', hair: '', personality: '', colors: '', accessories: ''
});

export default function YeniProjePage() {
  const router = useRouter();
  const [step, setStep] = useState(0);
  const [projectId, setProjectId] = useState<string | null>(null);
  const [title, setTitle] = useState('');
  const [hata, setHata] = useState<string | null>(null);
  const [yukleniyor, setYukleniyor] = useState(false);

  // Step 1
  const [songInfo, setSongInfo] = useState<{ originalFilename: string; format: string; durationSeconds: number; fileSizeBytes: number } | null>(null);

  // Step 2
  const [lyrics, setLyrics] = useState('');

  // Step 3
  const [videoStyle, setVideoStyle] = useState(VIDEO_STYLES[4]);
  const [styleNotes, setStyleNotes] = useState('');

  // Step 4
  const [characters, setCharacters] = useState<CharacterDraft[]>([emptyCharacter()]);

  // Step 5
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16' | '1:1'>('16:9');
  const [resolution, setResolution] = useState<'720p' | '1080p' | '4K'>('1080p');
  const [sceneDuration, setSceneDuration] = useState<'auto' | '5' | '6' | '8' | 'max'>('auto');
  const [continuity, setContinuity] = useState<'high' | 'medium' | 'low'>('high');
  const [provider, setProvider] = useState<'veo' | 'runway' | 'luma' | 'demo'>('demo');

  async function ensureProject() {
    if (projectId) return projectId;
    const res = await fetch('/api/projects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: title || 'Adsız Çocuk Şarkısı' })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.hata || 'Proje oluşturulamadı.');
    setProjectId(data.proje.id);
    return data.proje.id as string;
  }

  async function handleSongUpload(file: File) {
    setHata(null);
    setYukleniyor(true);
    try {
      const id = await ensureProject();
      const form = new FormData();
      form.append('song', file);
      const res = await fetch(`/api/projects/${id}/song`, { method: 'POST', body: form });
      const data = await res.json();
      if (!res.ok) throw new Error(data.hata || 'Şarkı yüklenemedi.');
      setSongInfo(data.sarki);
    } catch (err: any) {
      setHata(err.message);
    } finally {
      setYukleniyor(false);
    }
  }

  async function saveLyricsAndContinue() {
    setHata(null);
    if (!lyrics.trim()) {
      setHata('Lütfen şarkı sözlerini girin.');
      return;
    }
    setYukleniyor(true);
    try {
      const id = await ensureProject();
      const res = await fetch(`/api/projects/${id}/lyrics`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: lyrics })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.hata || 'Şarkı sözleri kaydedilemedi.');
      setStep(2);
    } catch (err: any) {
      setHata(err.message);
    } finally {
      setYukleniyor(false);
    }
  }

  function updateCharacter(idx: number, field: keyof CharacterDraft, value: string) {
    setCharacters((prev) => prev.map((c, i) => (i === idx ? { ...c, [field]: value } : c)));
  }

  async function finishWizard() {
    setHata(null);
    setYukleniyor(true);
    try {
      const id = await ensureProject();

      const validCharacters = characters.filter((c) => c.name.trim());
      if (validCharacters.length === 0) {
        throw new Error('En az bir karakter tanımlamalısınız.');
      }
      const charRes = await fetch(`/api/projects/${id}/characters`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ characters: validCharacters })
      });
      const charData = await charRes.json();
      if (!charRes.ok) throw new Error(charData.hata || 'Karakterler kaydedilemedi.');

      const settingsRes = await fetch(`/api/projects/${id}/settings`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ videoStyle, styleNotes, aspectRatio, resolution, sceneDuration, continuity, videoProviderKey: provider })
      });
      const settingsData = await settingsRes.json();
      if (!settingsRes.ok) throw new Error(settingsData.hata || 'Video ayarları kaydedilemedi.');

      router.push(`/projeler/${id}`);
    } catch (err: any) {
      setHata(err.message);
    } finally {
      setYukleniyor(false);
    }
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <h1 className="text-2xl font-semibold">Yeni Proje</h1>

      {/* Adım göstergesi */}
      <div className="flex items-center gap-2">
        {STEPS.map((s, i) => (
          <div key={s} className="flex-1 flex items-center gap-2">
            <div
              className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-medium shrink-0 ${
                i === step ? 'bg-studio-accent text-white' : i < step ? 'bg-studio-success/20 text-studio-success' : 'bg-studio-panel2 text-studio-muted'
              }`}
            >
              {i < step ? '✓' : i + 1}
            </div>
            {i < STEPS.length - 1 && <div className="h-px flex-1 bg-studio-border" />}
          </div>
        ))}
      </div>
      <p className="text-sm text-studio-muted -mt-2">{STEPS[step]}</p>

      {hata && <div className="text-sm text-studio-danger bg-studio-danger/10 rounded-lg px-3 py-2">{hata}</div>}

      {/* Proje adı — her zaman görünür, ilk adımda gerekli */}
      {step === 0 && (
        <div className="card space-y-4">
          <div>
            <label className="text-xs text-studio-muted mb-1 block">Proje Adı</label>
            <input className="input-field" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="örn. Renkli Orman Şarkısı" />
          </div>

          <div>
            <label className="text-xs text-studio-muted mb-1 block">Şarkı Dosyası (MP3, WAV veya FLAC)</label>
            <input
              type="file"
              accept="audio/mpeg,audio/wav,audio/x-wav,audio/flac,audio/x-flac"
              onChange={(e) => e.target.files?.[0] && handleSongUpload(e.target.files[0])}
              className="block w-full text-sm text-studio-muted file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:bg-studio-accent file:text-white file:cursor-pointer"
            />
          </div>

          {songInfo && (
            <div className="bg-studio-panel2 rounded-xl p-4 text-sm space-y-1">
              <div>📄 Dosya adı: {songInfo.originalFilename}</div>
              <div>⏱️ Süre: {Math.round(songInfo.durationSeconds)} saniye</div>
              <div>💾 Boyut: {(songInfo.fileSizeBytes / 1024 / 1024).toFixed(1)} MB</div>
              <div>🎚️ Format: {songInfo.format.toUpperCase()}</div>
            </div>
          )}

          <button className="btn-primary" disabled={!songInfo || yukleniyor} onClick={() => setStep(1)}>
            Devam Et →
          </button>
        </div>
      )}

      {step === 1 && (
        <div className="card space-y-4">
          <label className="text-xs text-studio-muted block">Şarkı Sözleri</label>
          <textarea
            className="input-field min-h-[280px] font-mono text-sm"
            value={lyrics}
            onChange={(e) => setLyrics(e.target.value)}
            placeholder={'Şarkı sözlerini buraya yapıştırın veya yazın...'}
          />
          <div className="flex gap-3">
            <button className="btn-secondary" onClick={() => setStep(0)}>← Geri</button>
            <button className="btn-primary" disabled={yukleniyor} onClick={saveLyricsAndContinue}>
              {yukleniyor ? 'Kaydediliyor…' : 'Devam Et →'}
            </button>
          </div>
        </div>
      )}

      {step === 2 && (
        <div className="card space-y-4">
          <label className="text-xs text-studio-muted block">Video Stili Seçin</label>
          <div className="grid grid-cols-2 gap-2">
            {VIDEO_STYLES.map((s) => (
              <button
                key={s}
                onClick={() => setVideoStyle(s)}
                className={`text-left px-3 py-2.5 rounded-xl border text-sm transition-colors ${
                  videoStyle === s ? 'border-studio-accent bg-studio-accent/10 text-white' : 'border-studio-border bg-studio-panel2 text-studio-muted hover:text-studio-text'
                }`}
              >
                {s}
              </button>
            ))}
          </div>
          <div>
            <label className="text-xs text-studio-muted mb-1 block">Ek Stil Notları (opsiyonel)</label>
            <textarea className="input-field" value={styleNotes} onChange={(e) => setStyleNotes(e.target.value)} placeholder="örn. pastel tonlar, yumuşak ışık..." />
          </div>
          <div className="flex gap-3">
            <button className="btn-secondary" onClick={() => setStep(1)}>← Geri</button>
            <button className="btn-primary" onClick={() => setStep(3)}>Devam Et →</button>
          </div>
        </div>
      )}

      {step === 3 && (
        <div className="card space-y-4">
          <div className="flex items-center justify-between">
            <label className="text-xs text-studio-muted block">Karakterler</label>
            <button className="text-xs text-studio-accent2" onClick={() => setCharacters((p) => [...p, emptyCharacter()])}>
              + Karakter Ekle
            </button>
          </div>
          {characters.map((c, idx) => (
            <div key={idx} className="bg-studio-panel2 rounded-xl p-4 space-y-2 relative">
              {characters.length > 1 && (
                <button
                  className="absolute top-3 right-3 text-studio-danger text-xs"
                  onClick={() => setCharacters((p) => p.filter((_, i) => i !== idx))}
                >
                  Sil ✕
                </button>
              )}
              <div className="grid grid-cols-2 gap-2">
                <Field label="Ad" value={c.name} onChange={(v) => updateCharacter(idx, 'name', v)} />
                <Field label="Yaş" value={c.age} onChange={(v) => updateCharacter(idx, 'age', v)} />
                <Field label="Cinsiyet" value={c.gender} onChange={(v) => updateCharacter(idx, 'gender', v)} />
                <Field label="Saç" value={c.hair} onChange={(v) => updateCharacter(idx, 'hair', v)} />
                <Field label="Kıyafet" value={c.clothing} onChange={(v) => updateCharacter(idx, 'clothing', v)} />
                <Field label="Renkler" value={c.colors} onChange={(v) => updateCharacter(idx, 'colors', v)} />
                <Field label="Aksesuarlar" value={c.accessories} onChange={(v) => updateCharacter(idx, 'accessories', v)} />
                <Field label="Kişilik" value={c.personality} onChange={(v) => updateCharacter(idx, 'personality', v)} />
              </div>
              <Field label="Görünüm (detaylı açıklama)" value={c.appearance} onChange={(v) => updateCharacter(idx, 'appearance', v)} full />
            </div>
          ))}
          <div className="flex gap-3">
            <button className="btn-secondary" onClick={() => setStep(2)}>← Geri</button>
            <button className="btn-primary" onClick={() => setStep(4)}>Devam Et →</button>
          </div>
        </div>
      )}

      {step === 4 && (
        <div className="card space-y-5">
          <SelectField label="En-Boy Oranı" value={aspectRatio} onChange={(v) => setAspectRatio(v as any)} options={[
            ['16:9', '16:9 — YouTube'], ['9:16', '9:16 — Shorts'], ['1:1', '1:1 — Kare']
          ]} />
          <SelectField label="Çözünürlük" value={resolution} onChange={(v) => setResolution(v as any)} options={[
            ['720p', '720p'], ['1080p', '1080p'], ['4K', '4K (sağlayıcı destekliyorsa)']
          ]} />
          <SelectField label="Sahne Süresi" value={sceneDuration} onChange={(v) => setSceneDuration(v as any)} options={[
            ['auto', 'Otomatik'], ['5', '5 saniye'], ['6', '6 saniye'], ['8', '8 saniye'], ['max', 'Sağlayıcı maksimumu']
          ]} />
          <SelectField label="Görsel Süreklilik" value={continuity} onChange={(v) => setContinuity(v as any)} options={[
            ['high', 'Yüksek'], ['medium', 'Orta'], ['low', 'Düşük']
          ]} />
          <SelectField label="Video Sağlayıcısı" value={provider} onChange={(v) => setProvider(v as any)} options={[
            ['demo', 'Demo Modu (ücretsiz, yerel test)'], ['veo', 'Google Veo'], ['runway', 'Runway'], ['luma', 'Luma']
          ]} />

          <div className="flex gap-3">
            <button className="btn-secondary" onClick={() => setStep(3)}>← Geri</button>
            <button className="btn-primary" disabled={yukleniyor} onClick={finishWizard}>
              {yukleniyor ? 'Kaydediliyor…' : 'Projeyi Oluştur ve Devam Et ✓'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function Field({ label, value, onChange, full }: { label: string; value: string; onChange: (v: string) => void; full?: boolean }) {
  return (
    <div className={full ? 'col-span-2' : ''}>
      <label className="text-[11px] text-studio-muted mb-1 block">{label}</label>
      <input className="input-field text-sm py-1.5" value={value} onChange={(e) => onChange(e.target.value)} />
    </div>
  );
}

function SelectField({
  label,
  value,
  onChange,
  options
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: [string, string][];
}) {
  return (
    <div>
      <label className="text-xs text-studio-muted mb-1 block">{label}</label>
      <select className="input-field" value={value} onChange={(e) => onChange(e.target.value)}>
        {options.map(([v, l]) => (
          <option key={v} value={v}>{l}</option>
        ))}
      </select>
    </div>
  );
}
