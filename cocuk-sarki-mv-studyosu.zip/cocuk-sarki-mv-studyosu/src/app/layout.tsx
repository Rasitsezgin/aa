import type { Metadata } from 'next';
import './globals.css';
import { Sidebar } from '@/components/Sidebar';

export const metadata: Metadata = {
  title: 'Çocuk Şarkı MV Stüdyosu',
  description: 'AI destekli çocuk şarkısı müzik videosu üretim stüdyosu'
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="tr" className="dark">
      <body className="min-h-screen bg-studio-bg text-studio-text font-sans antialiased">
        <div className="flex">
          <Sidebar />
          <main className="flex-1 min-w-0 p-8">{children}</main>
        </div>
      </body>
    </html>
  );
}
