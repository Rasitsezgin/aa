import { NextResponse } from 'next/server';
import { isProviderConfigured, providerLabel, isDemoMode } from '@/lib/env';

const ALL_PROVIDERS = ['openai', 'veo', 'runway', 'luma', 'suno', 'demo'];

/** Ayarlar sayfasının "Bağlı / Eksik" göstergesini beslediği uç nokta. */
export async function GET() {
  const demoMode = isDemoMode();
  const providers = ALL_PROVIDERS.map((key) => ({
    key,
    label: providerLabel(key),
    connected: key === 'demo' ? true : isProviderConfigured(key),
    // Gerçek API anahtarı hiçbir zaman istemciye gönderilmez.
  }));

  return NextResponse.json({ demoMode, providers });
}
