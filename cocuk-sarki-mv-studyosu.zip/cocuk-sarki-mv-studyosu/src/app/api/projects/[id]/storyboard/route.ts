import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { withApiHandler } from '@/lib/api-helpers';
import { createStoryboardForProject, approveStoryboard } from '@/services/storyboard.service';

export const GET = withApiHandler(async (_req, _ctx, params: { id: string }) => {
  const storyboard = await prisma.storyboard.findUnique({
    where: { projectId: params.id },
    include: { scenes: { orderBy: { order: 'asc' }, include: { asset: true } } }
  });
  return NextResponse.json({ sahnePlani: storyboard });
});

export const POST = withApiHandler(async (_req, _ctx, params: { id: string }) => {
  const storyboard = await createStoryboardForProject(params.id);
  return NextResponse.json({ sahnePlani: storyboard });
});

export const PATCH = withApiHandler(async (_req, _ctx, params: { id: string }) => {
  const storyboard = await approveStoryboard(params.id);
  return NextResponse.json({ sahnePlani: storyboard });
});
