import { NextRequest, NextResponse } from 'next/server';
import fs from 'node:fs/promises';
import ffmpeg from 'fluent-ffmpeg';
import { prisma } from '@/lib/prisma';
import { withApiHandler } from '@/lib/api-helpers';
import { projectSubPath, ensureProjectDirs } from '@/lib/paths';
import { KullaniciDostuHata } from '@/types';

if (process.env.FFMPEG_PATH) ffmpeg.setFfmpegPath(process.env.FFMPEG_PATH);
if (process.env.FFPROBE_PATH) ffmpeg.setFfprobePath(process.env.FFPROBE_PATH);

const ALLOWED_FORMATS: Record<string, string> = {
  'audio/mpeg': 'mp3',
  'audio/mp3': 'mp3',
  'audio/wav': 'wav',
  'audio/x-wav': 'wav',
  'audio/flac': 'flac',
  'audio/x-flac': 'flac'
};

const MAX_SIZE_BYTES = Number(process.env.MAX_UPLOAD_SIZE_MB || 200) * 1024 * 1024;

function probe(filePath: string): Promise<ffmpeg.FfprobeData> {
  return new Promise((resolve, reject) => {
    ffmpeg.ffprobe(filePath, (err, data) => (err ? reject(err) : resolve(data)));
  });
}

export const POST = withApiHandler(async (req: NextRequest, _ctx, params: { id: string }) => {
  const project = await prisma.project.findUnique({ where: { id: params.id } });
  if (!project) throw new KullaniciDostuHata('Proje bulunamadı.');

  const formData = await req.formData();
  const file = formData.get('song') as File | null;
  if (!file) {
    throw new KullaniciDostuHata('Lütfen bir ses dosyası seçin.', 'form alanı "song" boş.');
  }

  const format = ALLOWED_FORMATS[file.type];
  if (!format) {
    throw new KullaniciDostuHata(
      'Desteklenmeyen ses formatı. Lütfen MP3, WAV veya FLAC yükleyin.',
      `MIME türü: ${file.type}`
    );
  }

  if (file.size > MAX_SIZE_BYTES) {
    throw new KullaniciDostuHata(
      `Dosya boyutu çok büyük. En fazla ${Math.round(MAX_SIZE_BYTES / 1024 / 1024)} MB yükleyebilirsiniz.`
    );
  }
  if (file.size === 0) {
    throw new KullaniciDostuHata('Yüklenen dosya boş görünüyor.');
  }

  await ensureProjectDirs(project.slug);

  // Güvenli dosya adı: kullanıcı dosya adı shell/path olarak asla kullanılmaz.
  const safeName = `song.${format}`;
  const destPath = projectSubPath(project.slug, 'input', safeName);

  const buffer = Buffer.from(await file.arrayBuffer());
  await fs.writeFile(destPath, buffer);

  let durationSeconds = 0;
  let sampleRate: number | undefined;
  try {
    const info = await probe(destPath);
    durationSeconds = info.format.duration ?? 0;
    sampleRate = info.streams.find((s) => s.codec_type === 'audio')?.sample_rate
      ? Number(info.streams.find((s) => s.codec_type === 'audio')?.sample_rate)
      : undefined;
  } catch (err) {
    await fs.unlink(destPath).catch(() => {});
    throw new KullaniciDostuHata(
      'Ses dosyası okunamadı, dosya bozuk olabilir. Lütfen farklı bir dosya deneyin.',
      String(err)
    );
  }

  if (durationSeconds <= 0) {
    await fs.unlink(destPath).catch(() => {});
    throw new KullaniciDostuHata('Ses dosyasının süresi tespit edilemedi. Dosya bozuk olabilir.');
  }

  const song = await prisma.song.upsert({
    where: { projectId: project.id },
    update: {
      originalFilename: file.name,
      storagePath: destPath,
      format,
      durationSeconds,
      fileSizeBytes: file.size,
      sampleRate
    },
    create: {
      projectId: project.id,
      originalFilename: file.name,
      storagePath: destPath,
      format,
      durationSeconds,
      fileSizeBytes: file.size,
      sampleRate
    }
  });

  return NextResponse.json({ sarki: song });
});
