import { NextResponse } from 'next/server';
import { renderQueue } from '@/lib/queue';
import { withApiHandler } from '@/lib/api-helpers';

export const POST = withApiHandler(async (_req, _ctx, params: { id: string }) => {
  const job = await renderQueue.add('render-video', { projectId: params.id }, { attempts: 1 });
  return NextResponse.json({ isId: job.id, mesaj: 'Final video oluşturma işlemi kuyruğa alındı.' });
});
