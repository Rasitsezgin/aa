import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { withApiHandler } from '@/lib/api-helpers';

export const GET = withApiHandler(async (_req, _ctx, params: { id: string }) => {
  const project = await prisma.project.findUnique({
    where: { id: params.id },
    include: {
      song: true,
      lyrics: true,
      characters: true,
      storyboard: { include: { scenes: { orderBy: { order: 'asc' }, include: { asset: true } } } },
      subtitles: true,
      thumbnail: true,
      publishPackage: true,
      assets: true,
      jobs: { orderBy: { createdAt: 'desc' }, take: 50 }
    }
  });
  if (!project) return NextResponse.json({ hata: 'Proje bulunamadı.' }, { status: 404 });
  return NextResponse.json({ proje: project });
});

export const DELETE = withApiHandler(async (_req, _ctx, params: { id: string }) => {
  await prisma.project.delete({ where: { id: params.id } });
  return NextResponse.json({ basarili: true });
});
