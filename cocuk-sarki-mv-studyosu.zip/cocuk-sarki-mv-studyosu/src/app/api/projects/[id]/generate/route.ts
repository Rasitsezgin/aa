import { NextResponse } from 'next/server';
import { z } from 'zod';
import { withApiHandler } from '@/lib/api-helpers';
import { enqueueAllScenes, enqueueSceneGeneration } from '@/services/video-generation.service';

const schema = z.object({ sceneIds: z.array(z.string()).optional(), force: z.boolean().optional() });

export const POST = withApiHandler(async (req, _ctx, params: { id: string }) => {
  const body = await req.json().catch(() => ({}));
  const parsed = schema.safeParse(body);
  const sceneIds = parsed.success ? parsed.data.sceneIds : undefined;

  if (sceneIds && sceneIds.length > 0) {
    for (const id of sceneIds) {
      await enqueueSceneGeneration(id, { force: parsed.data?.force });
    }
    return NextResponse.json({ kuyruguGirenSahne: sceneIds.length });
  }

  const count = await enqueueAllScenes(params.id);
  return NextResponse.json({ kuyruguGirenSahne: count });
});
