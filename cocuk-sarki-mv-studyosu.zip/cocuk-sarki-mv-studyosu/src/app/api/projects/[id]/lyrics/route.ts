import { NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { withApiHandler } from '@/lib/api-helpers';

const schema = z.object({ content: z.string().min(1, 'Şarkı sözleri boş olamaz.') });

export const PUT = withApiHandler(async (req, _ctx, params: { id: string }) => {
  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ hata: 'Şarkı sözleri geçersiz.' }, { status: 400 });
  }

  const lyrics = await prisma.lyrics.upsert({
    where: { projectId: params.id },
    update: { content: parsed.data.content, source: 'MANUAL' },
    create: { projectId: params.id, content: parsed.data.content, source: 'MANUAL' }
  });

  return NextResponse.json({ sozler: lyrics });
});

export const DELETE = withApiHandler(async (_req, _ctx, params: { id: string }) => {
  await prisma.lyrics.deleteMany({ where: { projectId: params.id } });
  return NextResponse.json({ basarili: true });
});
