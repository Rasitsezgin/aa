import { NextResponse } from 'next/server';
import { withApiHandler } from '@/lib/api-helpers';
import { estimateGenerationCost } from '@/services/video-generation.service';

export const GET = withApiHandler(async (_req, _ctx, params: { id: string }) => {
  const estimate = await estimateGenerationCost(params.id);
  return NextResponse.json({ tahmin: estimate });
});
