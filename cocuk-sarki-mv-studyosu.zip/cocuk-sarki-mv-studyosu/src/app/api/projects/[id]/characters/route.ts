import { NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { withApiHandler } from '@/lib/api-helpers';

const characterSchema = z.object({
  name: z.string().min(1, 'Karakter adı zorunludur.'),
  age: z.string().optional(),
  gender: z.string().optional(),
  appearance: z.string().optional(),
  clothing: z.string().optional(),
  hair: z.string().optional(),
  personality: z.string().optional(),
  colors: z.string().optional(),
  accessories: z.string().optional()
});

const bodySchema = z.object({ characters: z.array(characterSchema).min(1, 'En az bir karakter tanımlamalısınız.') });

function buildBibleText(c: z.infer<typeof characterSchema>): string {
  const parts = [
    `${c.name}`,
    c.age ? `${c.age} yaşında` : null,
    c.gender ? c.gender : null,
    c.appearance ? `görünüm: ${c.appearance}` : null,
    c.clothing ? `kıyafet: ${c.clothing}` : null,
    c.hair ? `saç: ${c.hair}` : null,
    c.colors ? `renkler: ${c.colors}` : null,
    c.accessories ? `aksesuarlar: ${c.accessories}` : null,
    c.personality ? `kişilik: ${c.personality}` : null
  ].filter(Boolean);
  return parts.join(', ');
}

export const PUT = withApiHandler(async (req, _ctx, params: { id: string }) => {
  const body = await req.json().catch(() => null);
  const parsed = bodySchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ hata: parsed.error.issues[0]?.message ?? 'Karakter verisi geçersiz.' }, { status: 400 });
  }

  await prisma.character.deleteMany({ where: { projectId: params.id } });
  const created = await prisma.$transaction(
    parsed.data.characters.map((c) =>
      prisma.character.create({
        data: { ...c, projectId: params.id, bibleText: buildBibleText(c) }
      })
    )
  );

  return NextResponse.json({ karakterler: created });
});
