import { NextResponse } from 'next/server';
import { withApiHandler } from '@/lib/api-helpers';
import { analyzeSongForProject } from '@/services/song-analysis.service';

export const POST = withApiHandler(async (_req, _ctx, params: { id: string }) => {
  const analysis = await analyzeSongForProject(params.id);
  return NextResponse.json({ analiz: analysis });
});
