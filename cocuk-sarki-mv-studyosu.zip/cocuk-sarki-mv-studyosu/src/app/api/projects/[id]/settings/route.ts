import { NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { withApiHandler } from '@/lib/api-helpers';

const schema = z.object({
  videoStyle: z.string().optional(),
  styleNotes: z.string().optional(),
  aspectRatio: z.enum(['16:9', '9:16', '1:1']).optional(),
  resolution: z.enum(['720p', '1080p', '4K']).optional(),
  sceneDuration: z.enum(['auto', '5', '6', '8', 'max']).optional(),
  continuity: z.enum(['high', 'medium', 'low']).optional(),
  videoProviderKey: z.enum(['veo', 'runway', 'luma', 'demo']).optional()
});

export const PUT = withApiHandler(async (req, _ctx, params: { id: string }) => {
  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ hata: 'Ayarlar geçersiz.' }, { status: 400 });

  const project = await prisma.project.update({ where: { id: params.id }, data: parsed.data });
  return NextResponse.json({ proje: project });
});
