import { NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { slugify } from '@/lib/slug';
import { ensureProjectDirs } from '@/lib/paths';
import { withApiHandler } from '@/lib/api-helpers';

export const GET = withApiHandler(async (_req, { userId }) => {
  const projects = await prisma.project.findMany({
    where: { ownerId: userId },
    orderBy: { updatedAt: 'desc' },
    include: {
      song: true,
      storyboard: { include: { scenes: true } }
    }
  });
  return NextResponse.json({ projeler: projects });
});

const createSchema = z.object({
  title: z.string().min(2, 'Proje adı en az 2 karakter olmalı.')
});

export const POST = withApiHandler(async (req, { userId }) => {
  const body = await req.json().catch(() => null);
  const parsed = createSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ hata: 'Proje adı geçersiz.' }, { status: 400 });
  }

  const slug = slugify(parsed.data.title);
  await ensureProjectDirs(slug);

  const project = await prisma.project.create({
    data: { title: parsed.data.title, slug, ownerId: userId }
  });

  return NextResponse.json({ proje: project }, { status: 201 });
});
