import { NextRequest, NextResponse } from 'next/server';
import fs from 'node:fs/promises';
import path from 'node:path';
import { projectDir } from '@/lib/paths';

/**
 * Güvenli, kısıtlı statik dosya sunucusu. YALNIZCA video sağlayıcılarının
 * (Veo/Runway/Luma) sahne referans görsellerini (image-to-video sürekliliği
 * için) internetten çekebilmesi amacıyla vardır — bkz.
 * src/services/video-generation.service.ts.
 *
 * URL şeması: /api/assets/<proje-slug>/scenes/<dosya-adi>.jpg
 * Güvenlik: yalnızca "scenes" alt dizini ve yalnızca .jpg/.jpeg/.png
 * uzantılı dosyalar servis edilir; path traversal tamamen engellenir.
 */

const ALLOWED_EXT: Record<string, string> = {
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.png': 'image/png'
};

export async function GET(_req: NextRequest, { params }: { params: { path: string[] } }) {
  const segments = params.path ?? [];
  if (segments.length < 3 || segments[1] !== 'scenes') {
    return NextResponse.json({ hata: 'Geçersiz dosya yolu.' }, { status: 400 });
  }

  const [slug, sub, filename] = segments;
  const ext = path.extname(filename).toLowerCase();
  const contentType = ALLOWED_EXT[ext];
  if (!contentType) {
    return NextResponse.json({ hata: 'Bu dosya türü servis edilemez.' }, { status: 400 });
  }

  try {
    const base = projectDir(slug); // güvenli slug doğrulaması burada yapılır
    const safeFilename = path.basename(filename); // path traversal koruması
    const filePath = path.join(base, sub, safeFilename);
    const resolved = path.resolve(filePath);
    if (!resolved.startsWith(path.join(base, sub))) {
      return NextResponse.json({ hata: 'Geçersiz dosya yolu.' }, { status: 400 });
    }

    const data = await fs.readFile(resolved);
    return new NextResponse(data, {
      headers: { 'Content-Type': contentType, 'Cache-Control': 'no-store' }
    });
  } catch {
    return NextResponse.json({ hata: 'Dosya bulunamadı.' }, { status: 404 });
  }
}
