import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { redisConnection } from '@/lib/redis';

/** Sağlık kontrolü uç noktası — deployment/monitoring için (bkz. §31). */
export async function GET() {
  const checks: Record<string, 'ok' | 'hata'> = { database: 'hata', redis: 'hata' };

  try {
    await prisma.$queryRaw`SELECT 1`;
    checks.database = 'ok';
  } catch {
    checks.database = 'hata';
  }

  try {
    await redisConnection.ping();
    checks.redis = 'ok';
  } catch {
    checks.redis = 'hata';
  }

  const healthy = Object.values(checks).every((v) => v === 'ok');
  return NextResponse.json({ durum: healthy ? 'sağlıklı' : 'sorunlu', kontroller: checks }, { status: healthy ? 200 : 503 });
}
