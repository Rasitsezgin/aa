import { NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { withApiHandler } from '@/lib/api-helpers';
import { enqueueSceneGeneration } from '@/services/video-generation.service';

const editSchema = z.object({
  videoPrompt: z.string().optional(),
  negativePrompt: z.string().optional(),
  duration: z.number().positive().optional(),
  visualStyle: z.string().optional(),
  camera: z.string().optional(),
  lighting: z.string().optional()
});

/** Sahne düzenleme (bkz. §7: edit / change duration / change visual style). */
export const PATCH = withApiHandler(async (req, _ctx, params: { sceneId: string }) => {
  const body = await req.json().catch(() => null);
  const parsed = editSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ hata: 'Sahne verisi geçersiz.' }, { status: 400 });

  const data: Record<string, unknown> = { ...parsed.data };
  if (parsed.data.duration != null) {
    const scene = await prisma.scene.findUnique({ where: { id: params.sceneId } });
    if (scene) data.endTime = scene.startTime + parsed.data.duration;
  }

  const scene = await prisma.scene.update({ where: { id: params.sceneId }, data });
  return NextResponse.json({ sahne: scene });
});

/** Sahneyi siler; kullanıcı planı elle küçültmek isterse kullanılır. */
export const DELETE = withApiHandler(async (_req, _ctx, params: { sceneId: string }) => {
  await prisma.scene.delete({ where: { id: params.sceneId } });
  return NextResponse.json({ basarili: true });
});
