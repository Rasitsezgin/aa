import { NextResponse } from 'next/server';
import { withApiHandler } from '@/lib/api-helpers';
import { enqueueSceneGeneration } from '@/services/video-generation.service';

/** Başarısız bir sahneyi yeniden dener (bkz. §17: her başarısız üretimde retry). */
export const POST = withApiHandler(async (_req, _ctx, params: { sceneId: string }) => {
  const scene = await enqueueSceneGeneration(params.sceneId, { force: true });
  return NextResponse.json({ sahne: scene });
});
