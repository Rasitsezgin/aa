'use client';

import { useEffect, useState } from 'react';

interface ProviderStatus {
  key: string;
  label: string;
  connected: boolean;
}

export default function AyarlarPage() {
  const [providers, setProviders] = useState<ProviderStatus[]>([]);
  const [demoMode, setDemoMode] = useState(false);
  const [health, setHealth] = useState<{ durum: string; kontroller: Record<string, string> } | null>(null);

  useEffect(() => {
    fetch('/api/providers/status')
      .then((r) => r.json())
      .then((d) => {
        setProviders(d.providers ?? []);
        setDemoMode(d.demoMode ?? false);
      });
    fetch('/api/health')
      .then((r) => r.json())
      .then(setHealth)
      .catch(() => setHealth(null));
  }, []);

  const llmProviders = providers.filter((p) => ['openai', 'demo'].includes(p.key));
  const videoProviders = providers.filter((p) => ['veo', 'runway', 'luma', 'demo'].includes(p.key));
  const musicProviders = providers.filter((p) => p.key === 'suno');

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <h1 className="text-2xl font-semibold">Ayarlar</h1>

      {demoMode && (
        <div className="card border-studio-warning/40 bg-studio-warning/5">
          <div className="flex items-center gap-2 text-studio-warning font-medium">🧪 Demo Modu Aktif</div>
          <p className="text-sm text-studio-muted mt-1">
            Şu anda tüm sağlayıcılar simüle edilmektedir. Gerçek video/LLM üretimi için .env dosyasında
            <code className="mx-1 px-1.5 py-0.5 bg-studio-panel2 rounded">DEMO_MODE=false</code>
            olarak ayarlayın ve ilgili API anahtarlarını girin.
          </p>
        </div>
      )}

      <section className="card">
        <h2 className="font-medium mb-3">🧠 AI Ayarları (LLM)</h2>
        <ProviderList items={llmProviders} />
      </section>

      <section className="card">
        <h2 className="font-medium mb-3">🎥 Video Ayarları</h2>
        <ProviderList items={videoProviders} />
        <p className="text-xs text-studio-muted mt-3">
          Sağlayıcı seçimi her proje için "Video Ayarları" adımında ayrı ayrı yapılır.
        </p>
      </section>

      <section className="card">
        <h2 className="font-medium mb-3">🎵 Müzik (Opsiyonel)</h2>
        <ProviderList items={musicProviders} />
        <p className="text-xs text-studio-muted mt-3">
          Suno API anahtarı olmadan da uygulama normal şekilde çalışır; kullanıcı kendi şarkısını yükler.
        </p>
      </section>

      <section className="card">
        <h2 className="font-medium mb-3">🖥️ Sistem Sağlığı</h2>
        {health ? (
          <div className="grid grid-cols-2 gap-3 text-sm">
            {Object.entries(health.kontroller).map(([k, v]) => (
              <div key={k} className="flex items-center justify-between px-3 py-2 bg-studio-panel2 rounded-lg">
                <span className="capitalize">{k === 'database' ? 'Veritabanı' : 'Kuyruk (Redis)'}</span>
                <span className={v === 'ok' ? 'text-studio-success' : 'text-studio-danger'}>
                  {v === 'ok' ? '✅ Çalışıyor' : '❌ Sorunlu'}
                </span>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-sm text-studio-muted">Sağlık bilgisi alınamadı.</p>
        )}
      </section>
    </div>
  );
}

function ProviderList({ items }: { items: ProviderStatus[] }) {
  if (items.length === 0) return <p className="text-sm text-studio-muted">Sağlayıcı bulunamadı.</p>;
  return (
    <div className="space-y-2">
      {items.map((p) => (
        <div key={p.key} className="flex items-center justify-between px-3 py-2 bg-studio-panel2 rounded-lg">
          <span className="text-sm">{p.label}</span>
          <span className={`badge ${p.connected ? 'bg-studio-success/15 text-studio-success' : 'bg-studio-danger/15 text-studio-danger'}`}>
            {p.connected ? 'Bağlı' : 'Eksik'}
          </span>
        </div>
      ))}
    </div>
  );
}
