import { z } from 'zod';

// ---------------------------------------------------------------------------
// Song Analysis (strict schema — never trust free-form LLM text directly)
// ---------------------------------------------------------------------------

export const SongSectionSchema = z.object({
  type: z.enum(['intro', 'verse', 'pre-chorus', 'chorus', 'bridge', 'outro', 'refrain']),
  index: z.number().int().nonnegative(),
  startLine: z.number().int().nonnegative(),
  endLine: z.number().int().nonnegative(),
  text: z.string(),
  emotionalTone: z.string().optional(),
  isRepeat: z.boolean().default(false)
});

export const SongAnalysisSchema = z.object({
  title: z.string(),
  theme: z.string(),
  characters: z.array(z.string()).default([]),
  locations: z.array(z.string()).default([]),
  objects: z.array(z.string()).default([]),
  sections: z.array(SongSectionSchema).default([]),
  visual_style: z.string().optional(),
  story_arc: z.string().optional(),
  tempoHint: z.string().optional(),
  visualOpportunities: z.array(z.string()).default([]),
  transitions: z.array(z.string()).default([])
});

export type SongAnalysis = z.infer<typeof SongAnalysisSchema>;
export type SongSection = z.infer<typeof SongSectionSchema>;

// ---------------------------------------------------------------------------
// Storyboard scene (mirrors Prisma Scene model, used pre-persistence)
// ---------------------------------------------------------------------------

export const StoryboardSceneSchema = z.object({
  order: z.number().int().nonnegative(),
  startTime: z.number().nonnegative(),
  endTime: z.number().positive(),
  duration: z.number().positive(),
  lyricsSegment: z.string(),
  narrativePurpose: z.string().optional(),
  location: z.string().optional(),
  characters: z.array(z.string()).default([]),
  characterActions: z.string().optional(),
  camera: z.string().optional(),
  lighting: z.string().optional(),
  environment: z.string().optional(),
  visualStyle: z.string().optional(),
  transition: z.string().optional(),
  videoPrompt: z.string(),
  negativePrompt: z.string().optional(),
  continuityNotes: z.string().optional()
});

export type StoryboardScene = z.infer<typeof StoryboardSceneSchema>;

export const VisualBibleSchema = z.object({
  globalStyle: z.string(),
  characterBible: z.string(),
  environmentBible: z.string(),
  colorPalette: z.array(z.string()).default([]),
  recurringProps: z.array(z.string()).default([]),
  cameraLanguage: z.string().optional(),
  animationStyle: z.string().optional(),
  lighting: z.string().optional(),
  visualRules: z.array(z.string()).default([])
});

export type VisualBible = z.infer<typeof VisualBibleSchema>;

// ---------------------------------------------------------------------------
// Character input from wizard step 4
// ---------------------------------------------------------------------------

export interface CharacterInput {
  name: string;
  age?: string;
  gender?: string;
  appearance?: string;
  clothing?: string;
  hair?: string;
  personality?: string;
  colors?: string;
  accessories?: string;
}

// ---------------------------------------------------------------------------
// Video settings from wizard step 5
// ---------------------------------------------------------------------------

export const VideoSettingsSchema = z.object({
  aspectRatio: z.enum(['16:9', '9:16', '1:1']).default('16:9'),
  resolution: z.enum(['720p', '1080p', '4K']).default('1080p'),
  sceneDuration: z.enum(['auto', '5', '6', '8', 'max']).default('auto'),
  continuity: z.enum(['high', 'medium', 'low']).default('high'),
  provider: z.enum(['veo', 'runway', 'luma', 'demo']).default('demo')
});

export type VideoSettings = z.infer<typeof VideoSettingsSchema>;

// ---------------------------------------------------------------------------
// YouTube publish package
// ---------------------------------------------------------------------------

export interface PublishPackageDraft {
  title: string;
  shortDescription: string;
  longDescription: string;
  hashtags: string[];
  tags: string[];
  thumbnailText: string;
  pinnedComment: string;
  playlistSuggestion: string;
}

// ---------------------------------------------------------------------------
// Turkish, user-facing error wrapper (see rule #17)
// ---------------------------------------------------------------------------

export class KullaniciDostuHata extends Error {
  public readonly turkceMesaj: string;
  public readonly teknikDetay?: string;

  constructor(turkceMesaj: string, teknikDetay?: string) {
    super(turkceMesaj);
    this.turkceMesaj = turkceMesaj;
    this.teknikDetay = teknikDetay;
  }
}
