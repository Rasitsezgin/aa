// Basit bellek-içi oran sınırlama (tek VPS instance için yeterlidir).
// Çoklu instance/ölçeklenebilir dağıtımlarda Redis tabanlı bir limiter'a
// geçirilmesi önerilir.
const buckets = new Map<string, { count: number; resetAt: number }>();

const WINDOW_MS = Number(process.env.RATE_LIMIT_WINDOW_MS || 60000);
const MAX_REQ = Number(process.env.RATE_LIMIT_MAX || 60);

export function checkRateLimit(key: string): { allowed: boolean; remaining: number } {
  const now = Date.now();
  const bucket = buckets.get(key);
  if (!bucket || now > bucket.resetAt) {
    buckets.set(key, { count: 1, resetAt: now + WINDOW_MS });
    return { allowed: true, remaining: MAX_REQ - 1 };
  }
  bucket.count += 1;
  if (bucket.count > MAX_REQ) return { allowed: false, remaining: 0 };
  return { allowed: true, remaining: MAX_REQ - bucket.count };
}
