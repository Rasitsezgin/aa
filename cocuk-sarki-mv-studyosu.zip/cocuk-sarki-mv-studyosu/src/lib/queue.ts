import { Queue } from 'bullmq';
import { redisConnection } from './redis';

/**
 * Tüm arka plan işleri (video üretimi, FFmpeg render, altyazı, thumbnail,
 * YouTube paketi) bu kuyruklar üzerinden yürütülür — hiçbir işlem web
 * isteğini bloklamaz (bkz. §20). VPS yeniden başlarsa BullMQ + Redis
 * kalıcılığı sayesinde tamamlanmamış işler kaybolmaz (bkz. §21).
 */
export const videoGenerationQueue = new Queue('generate-scene', { connection: redisConnection });
export const renderQueue = new Queue('render-video', { connection: redisConnection });
export const pipelineQueue = new Queue('pipeline-steps', { connection: redisConnection });

export const QUEUE_NAMES = {
  GENERATE_SCENE: 'generate-scene',
  RENDER_VIDEO: 'render-video',
  PIPELINE_STEPS: 'pipeline-steps'
} as const;
