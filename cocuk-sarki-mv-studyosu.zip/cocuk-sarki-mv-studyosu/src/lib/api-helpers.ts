import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from './auth';
import { checkRateLimit } from './rate-limit';
import { KullaniciDostuHata } from '@/types';

/**
 * Ortak API sarmalayıcı: kimlik doğrulama + oran sınırlama + Türkçe hata
 * mesajlarına çevirme (bkz. §17, §19).
 */
export function withApiHandler(
  handler: (req: NextRequest, ctx: { userId: string }, params: any) => Promise<NextResponse>,
  opts?: { requireAuth?: boolean }
) {
  return async (req: NextRequest, routeCtx: { params: any }) => {
    const ip = req.headers.get('x-forwarded-for') || 'local';
    const { allowed } = checkRateLimit(ip);
    if (!allowed) {
      return NextResponse.json({ hata: 'Çok fazla istek gönderildi. Lütfen biraz bekleyip tekrar deneyin.' }, { status: 429 });
    }

    const requireAuth = opts?.requireAuth !== false;
    const user = await getCurrentUser();
    if (requireAuth && !user) {
      return NextResponse.json({ hata: 'Bu işlem için giriş yapmanız gerekiyor.' }, { status: 401 });
    }

    try {
      return await handler(req, { userId: user?.id ?? 'demo' }, routeCtx.params);
    } catch (err) {
      if (err instanceof KullaniciDostuHata) {
        return NextResponse.json({ hata: err.turkceMesaj, teknikDetay: err.teknikDetay }, { status: 400 });
      }
      console.error(err);
      return NextResponse.json({ hata: 'Beklenmeyen bir sunucu hatası oluştu.' }, { status: 500 });
    }
  };
}
