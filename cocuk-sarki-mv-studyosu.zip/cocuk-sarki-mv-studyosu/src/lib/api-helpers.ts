import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from './auth';
import { checkRateLimit } from './rate-limit';
import { KullaniciDostuHata } from '@/types';

/**
 * Ortak API sarmalayıcı: oran sınırlama + Türkçe hata mesajlarına çevirme.
 * AÇIK MOD: giriş/kimlik doğrulama YOKTUR — her istek otomatik olarak tek
 * "Yerel Kullanıcı" hesabı üzerinden yürütülür (bkz. src/lib/auth.ts).
 */
export function withApiHandler(
  handler: (req: NextRequest, ctx: { userId: string }, params: any) => Promise<NextResponse>
) {
  return async (req: NextRequest, routeCtx: { params: any }) => {
    const ip = req.headers.get('x-forwarded-for') || 'local';
    const { allowed } = checkRateLimit(ip);
    if (!allowed) {
      return NextResponse.json({ hata: 'Çok fazla istek gönderildi. Lütfen biraz bekleyip tekrar deneyin.' }, { status: 429 });
    }

    try {
      const user = await getCurrentUser();
      return await handler(req, { userId: user.id }, routeCtx.params);
    } catch (err) {
      if (err instanceof KullaniciDostuHata) {
        return NextResponse.json({ hata: err.turkceMesaj, teknikDetay: err.teknikDetay }, { status: 400 });
      }
      console.error(err);
      return NextResponse.json({ hata: 'Beklenmeyen bir sunucu hatası oluştu.' }, { status: 500 });
    }
  };
}
