import path from 'node:path';
import fs from 'node:fs/promises';

const PROJECTS_ROOT = process.env.PROJECTS_DIR
  ? path.resolve(process.env.PROJECTS_DIR)
  : path.resolve(process.cwd(), 'projects');

// Path-traversal koruması: proje slug'ı sadece güvenli karakterler içerebilir.
const SAFE_SLUG = /^[a-z0-9-]{3,80}$/;

export function assertSafeSlug(slug: string) {
  if (!SAFE_SLUG.test(slug)) {
    throw new Error('Geçersiz proje adı (slug). Yalnızca küçük harf, rakam ve tire kullanılabilir.');
  }
}

export function projectDir(slug: string) {
  assertSafeSlug(slug);
  const dir = path.join(PROJECTS_ROOT, slug);
  const resolved = path.resolve(dir);
  if (!resolved.startsWith(PROJECTS_ROOT)) {
    throw new Error('Geçersiz proje dizini.');
  }
  return resolved;
}

export const subDirs = [
  'input',
  'analysis',
  'storyboard',
  'prompts',
  'characters',
  'scenes',
  'subtitles',
  'thumbnail',
  'output',
  'publish'
] as const;

export async function ensureProjectDirs(slug: string) {
  const base = projectDir(slug);
  await fs.mkdir(base, { recursive: true });
  for (const d of subDirs) {
    await fs.mkdir(path.join(base, d), { recursive: true });
  }
  return base;
}

export function projectSubPath(slug: string, sub: (typeof subDirs)[number], filename: string) {
  const safeFilename = path.basename(filename); // shell/path traversal koruması
  return path.join(projectDir(slug), sub, safeFilename);
}
