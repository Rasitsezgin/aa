import { prisma } from './prisma';

/**
 * AÇIK KAYNAK / TEK KULLANICI MODU
 * ---------------------------------
 * Bu sürümde giriş ekranı, parola veya oturum YOKTUR. Uygulama açılır
 * açılmaz doğrudan panele erişilir. Veritabanı modelleri (Project.ownerId
 * vb.) bir User kaydı beklediği için, arka planda tek bir "Yerel Kullanıcı"
 * otomatik olarak oluşturulur ve tüm işlemler bu kullanıcı üzerinden yapılır.
 *
 * Çok kullanıcılı / şifreli bir kuruluma geri dönmek isterseniz, bu dosyayı
 * eski çerez+parola tabanlı sürümle değiştirip middleware.ts'i tekrar
 * ekleyebilirsiniz (User modeli buna zaten hazırdır: passwordHash, role vb.).
 */

const LOCAL_USER_EMAIL = 'yerel@studyo.local';

let cachedUserId: string | null = null;

export async function getCurrentUser() {
  if (cachedUserId) {
    const existing = await prisma.user.findUnique({ where: { id: cachedUserId } });
    if (existing) return existing;
  }

  const user = await prisma.user.upsert({
    where: { email: LOCAL_USER_EMAIL },
    update: {},
    create: {
      email: LOCAL_USER_EMAIL,
      passwordHash: 'no-auth-open-mode', // kullanılmıyor — giriş ekranı yok
      name: 'Yerel Kullanıcı',
      role: 'ADMIN'
    }
  });

  cachedUserId = user.id;
  return user;
}

/** Başlangıçta (instrumentation.ts) çağrılır — yerel kullanıcının var olduğundan emin olur. */
export async function ensureBootstrapAdmin() {
  await getCurrentUser();
  console.log('[auth] Açık mod: giriş ekranı devre dışı, panel doğrudan erişilebilir.');
}
