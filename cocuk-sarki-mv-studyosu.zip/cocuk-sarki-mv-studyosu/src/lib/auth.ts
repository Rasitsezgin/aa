import { createHmac, scryptSync, randomBytes, timingSafeEqual } from 'node:crypto';
import { cookies } from 'next/headers';
import { prisma } from './prisma';

/**
 * Basit, bağımlılığı az bir kimlik doğrulama katmanı: tek-sunucu / kişisel
 * VPS kurulumu için imzalı çerez tabanlı oturum + scrypt parola hash'i.
 * Çok kullanıcılı / SSO gereken kurulumlar için NextAuth.js'e geçiş
 * önerilir (User modeli buna hazır şekilde tasarlanmıştır).
 */

const COOKIE_NAME = 'csms_session';
const SESSION_TTL_MS = 1000 * 60 * 60 * 24 * 7; // 7 gün

function secret() {
  const s = process.env.APP_SECRET;
  if (!s) throw new Error('APP_SECRET ortam değişkeni tanımlı değil.');
  return s;
}

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString('hex');
  const hash = scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [salt, hash] = stored.split(':');
  if (!salt || !hash) return false;
  const check = scryptSync(password, salt, 64);
  const original = Buffer.from(hash, 'hex');
  return original.length === check.length && timingSafeEqual(original, check);
}

function sign(payload: string): string {
  return createHmac('sha256', secret()).update(payload).digest('hex');
}

export function createSessionToken(userId: string): string {
  const expires = Date.now() + SESSION_TTL_MS;
  const payload = `${userId}.${expires}`;
  const sig = sign(payload);
  return Buffer.from(`${payload}.${sig}`).toString('base64url');
}

export function verifySessionToken(token: string): { userId: string } | null {
  try {
    const decoded = Buffer.from(token, 'base64url').toString('utf-8');
    const [userId, expiresStr, sig] = decoded.split('.');
    if (!userId || !expiresStr || !sig) return null;
    const expected = sign(`${userId}.${expiresStr}`);
    if (expected !== sig) return null;
    if (Date.now() > Number(expiresStr)) return null;
    return { userId };
  } catch {
    return null;
  }
}

export async function getCurrentUser() {
  const store = cookies();
  const token = store.get(COOKIE_NAME)?.value;
  if (!token) return null;
  const session = verifySessionToken(token);
  if (!session) return null;
  return prisma.user.findUnique({ where: { id: session.userId } });
}

export function sessionCookieOptions() {
  return {
    name: COOKIE_NAME,
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax' as const,
    path: '/',
    maxAge: SESSION_TTL_MS / 1000
  };
}

/**
 * İlk kurulumda .env'de ADMIN_EMAIL/ADMIN_PASSWORD tanımlıysa ve veritabanında
 * hiç kullanıcı yoksa otomatik bir admin hesabı oluşturur.
 */
export async function ensureBootstrapAdmin() {
  const email = process.env.ADMIN_EMAIL;
  const password = process.env.ADMIN_PASSWORD;
  if (!email || !password) return;

  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing) return;

  await prisma.user.create({
    data: { email, passwordHash: hashPassword(password), role: 'ADMIN', name: 'Yönetici' }
  });
  console.log(`[auth] Başlangıç admin hesabı oluşturuldu: ${email}`);
}
