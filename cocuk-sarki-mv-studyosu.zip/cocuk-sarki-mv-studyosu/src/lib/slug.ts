export function slugify(input: string): string {
  const trMap: Record<string, string> = {
    ç: 'c', Ç: 'c', ğ: 'g', Ğ: 'g', ı: 'i', I: 'i', İ: 'i',
    ö: 'o', Ö: 'o', ş: 's', Ş: 's', ü: 'u', Ü: 'u'
  };
  const replaced = input.replace(/[çÇğĞıIİöÖşŞüÜ]/g, (ch) => trMap[ch] ?? ch);
  const base = replaced
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 60);
  const suffix = Date.now().toString(36).slice(-5);
  return `${base || 'proje'}-${suffix}`;
}
