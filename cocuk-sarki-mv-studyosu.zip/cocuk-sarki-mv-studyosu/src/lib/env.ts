// Merkezi ortam değişkeni okuyucu — eksik anahtarları güvenle tespit eder.
export const isDemoMode = () => process.env.DEMO_MODE === 'true';

export function isProviderConfigured(key: string): boolean {
  switch (key) {
    case 'openai':
      return Boolean(process.env.OPENAI_API_KEY);
    case 'veo':
      return Boolean(process.env.GOOGLE_AI_API_KEY);
    case 'runway':
      return Boolean(process.env.RUNWAY_API_KEY);
    case 'luma':
      return Boolean(process.env.LUMA_API_KEY);
    case 'suno':
      return Boolean(process.env.SUNO_API_KEY);
    case 'demo':
      return true;
    default:
      return false;
  }
}

export function providerLabel(key: string): string {
  const labels: Record<string, string> = {
    openai: 'OpenAI (LLM)',
    veo: 'Google Veo',
    runway: 'Runway',
    luma: 'Luma',
    suno: 'Suno (Müzik)',
    demo: 'Demo Modu'
  };
  return labels[key] ?? key;
}
