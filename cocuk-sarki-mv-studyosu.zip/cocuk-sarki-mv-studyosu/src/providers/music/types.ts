export interface GenerateSongInput {
  lyrics: string;
  styleDescription: string;
  durationSeconds?: number;
}

export type MusicJobStatus = 'queued' | 'generating' | 'completed' | 'failed';

export interface MusicJobHandle {
  externalJobId: string;
  status: MusicJobStatus;
}

/**
 * MusicProvider — opsiyoneldir. Uygulama normalde kullanıcının yüklediği
 * MP3/WAV/FLAC dosyasıyla çalışır. Bu arayüz yalnızca gelecekte Suno gibi
 * bir müzik üretim sağlayıcısı eklenmek istenirse kullanılır. SUNO_API_KEY
 * tanımlı değilse uygulama normal şekilde çalışmaya devam eder.
 */
export interface MusicProvider {
  readonly key: string;
  generateSong(input: GenerateSongInput): Promise<MusicJobHandle>;
  getGenerationStatus(externalJobId: string): Promise<MusicJobStatus>;
  downloadSong(externalJobId: string, destinationPath: string): Promise<void>;
}
