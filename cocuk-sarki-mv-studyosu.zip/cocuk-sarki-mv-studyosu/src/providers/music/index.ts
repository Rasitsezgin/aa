import { MusicProvider } from './types';
import { isProviderConfigured } from '@/lib/env';

/**
 * Suno sadece API anahtarı varsa kullanılabilir. Anahtar yoksa null döner;
 * çağıran kodlar bunu kontrol edip "Bu sağlayıcı için API anahtarı eksik"
 * mesajını göstermeli — uygulama asla bu yüzden çökmemelidir (bkz. §3).
 */
export function getMusicProvider(): MusicProvider | null {
  if (!isProviderConfigured('suno')) return null;
  // eslint-disable-next-line @typescript-eslint/no-var-requires
  const { SunoMusicProvider } = require('./suno-provider');
  return new SunoMusicProvider();
}

export type { MusicProvider } from './types';
