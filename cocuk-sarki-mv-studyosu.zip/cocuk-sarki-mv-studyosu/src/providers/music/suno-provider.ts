import fs from 'node:fs/promises';
import path from 'node:path';
import { MusicProvider, GenerateSongInput, MusicJobHandle, MusicJobStatus } from './types';
import { requireApiKey } from '../video/base-http-provider';

const BASE_URL = process.env.SUNO_API_BASE || 'https://api.suno.ai/v1';

/** SunoMusicProvider — opsiyonel. Yalnızca SUNO_API_KEY tanımlıysa kullanılabilir. */
export class SunoMusicProvider implements MusicProvider {
  readonly key = 'suno';

  private headers() {
    const key = requireApiKey('SUNO_API_KEY', 'Suno');
    return { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' };
  }

  async generateSong(input: GenerateSongInput): Promise<MusicJobHandle> {
    const res = await fetch(`${BASE_URL}/generate`, {
      method: 'POST',
      headers: this.headers(),
      body: JSON.stringify({ lyrics: input.lyrics, style: input.styleDescription, duration: input.durationSeconds })
    });
    if (!res.ok) throw new Error(`Suno isteği başarısız: HTTP ${res.status}`);
    const data = await res.json();
    return { externalJobId: data.id, status: 'queued' };
  }

  async getGenerationStatus(externalJobId: string): Promise<MusicJobStatus> {
    const res = await fetch(`${BASE_URL}/generate/${externalJobId}`, { headers: this.headers() });
    if (!res.ok) throw new Error(`Suno durum sorgusu başarısız: HTTP ${res.status}`);
    const data = await res.json();
    return (data.status as MusicJobStatus) ?? 'generating';
  }

  async downloadSong(externalJobId: string, destinationPath: string): Promise<void> {
    const res = await fetch(`${BASE_URL}/generate/${externalJobId}/download`, { headers: this.headers() });
    if (!res.ok) throw new Error(`Suno indirme başarısız: HTTP ${res.status}`);
    const buffer = Buffer.from(await res.arrayBuffer());
    await fs.mkdir(path.dirname(destinationPath), { recursive: true });
    await fs.writeFile(destinationPath, buffer);
  }
}
