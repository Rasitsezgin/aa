import { SongAnalysis, StoryboardScene, VisualBible, PublishPackageDraft } from '@/types';

export interface AnalyzeSongInput {
  lyrics: string;
  songTitleHint?: string;
  durationSeconds: number;
}

export interface CreateStoryboardInput {
  analysis: SongAnalysis;
  lyrics: string;
  durationSeconds: number;
  videoStyle: string;
  styleNotes?: string;
  characterNames: string[];
  sceneDurationPreference: string; // 'auto' | '5' | '6' | '8' | 'max'
}

export interface TranslateSubtitleInput {
  lines: { index: number; startMs: number; endMs: number; text: string }[];
  targetLanguage: 'EN' | 'DE' | 'ES' | 'AR';
  protectedNames: string[]; // character / proper names that must not be mistranslated
}

export interface GenerateYoutubePackageInput {
  analysis: SongAnalysis;
  title: string;
}

/**
 * LLMProvider — soyutlama katmanı. Şarkı analizi, hikâye/storyboard üretimi,
 * altyazı çevirisi ve YouTube metinleri bu arayüz üzerinden üretilir.
 * Böylece OpenAI dışında başka bir LLM sağlayıcısı da eklenebilir.
 */
export interface LLMProvider {
  readonly key: string;
  analyzeSong(input: AnalyzeSongInput): Promise<SongAnalysis>;
  createStoryboard(input: CreateStoryboardInput): Promise<StoryboardScene[]>;
  buildVisualBible(input: CreateStoryboardInput): Promise<VisualBible>;
  translateSubtitles(input: TranslateSubtitleInput): Promise<{ index: number; startMs: number; endMs: number; text: string }[]>;
  generateYoutubePackage(input: GenerateYoutubePackageInput): Promise<PublishPackageDraft>;
}
