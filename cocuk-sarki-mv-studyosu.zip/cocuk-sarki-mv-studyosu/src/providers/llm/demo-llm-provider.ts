import {
  LLMProvider,
  AnalyzeSongInput,
  CreateStoryboardInput,
  TranslateSubtitleInput,
  GenerateYoutubePackageInput
} from './types';
import { SongAnalysis, StoryboardScene, VisualBible, PublishPackageDraft } from '@/types';

/**
 * DemoLLMProvider — gerçek API anahtarı gerektirmez.
 * Şarkı sözlerini basit sezgisel kurallarla bölerek yine de anlamlı ve
 * tutarlı bir analiz + storyboard üretir. "Demo Modu" ve testler için kullanılır.
 */
export class DemoLLMProvider implements LLMProvider {
  readonly key = 'demo';

  async analyzeSong(input: AnalyzeSongInput): Promise<SongAnalysis> {
    const rawLines = input.lyrics
      .split('\n')
      .map((l) => l.trim())
      .filter(Boolean);

    const lines = rawLines.length > 0 ? rawLines : ['(Söz girilmedi)'];

    // Basit tekrar tespiti: aynı satır birden fazla kez geçiyorsa nakarat say.
    const counts = new Map<string, number>();
    lines.forEach((l) => counts.set(l, (counts.get(l) ?? 0) + 1));

    const sections: SongAnalysis['sections'] = [];
    const chunkSize = Math.max(2, Math.ceil(lines.length / 4));
    let idx = 0;
    for (let i = 0; i < lines.length; i += chunkSize) {
      const chunk = lines.slice(i, i + chunkSize);
      const isRepeat = chunk.some((l) => (counts.get(l) ?? 0) > 1);
      sections.push({
        type: idx === 0 ? 'intro' : isRepeat ? 'chorus' : 'verse',
        index: idx,
        startLine: i,
        endLine: Math.min(i + chunkSize, lines.length) - 1,
        text: chunk.join(' / '),
        emotionalTone: idx % 2 === 0 ? 'neşeli, meraklı' : 'sıcak, sevecen',
        isRepeat
      });
      idx += 1;
    }

    return {
      title: input.songTitleHint || 'Adsız Çocuk Şarkısı',
      theme: 'Dostluk, keşif ve birlikte öğrenme',
      characters: ['Ana Karakter'],
      locations: ['Renkli bir orman', 'Küçük bir köy meydanı'],
      objects: ['Büyülü bir kitap', 'Rengarenk balonlar'],
      sections,
      visual_style: 'sıcak, parlak, çocuklara uygun animasyon',
      story_arc: 'Meraklı bir keşifle başlar, küçük bir engelle karşılaşılır, dostlukla ve neşeyle çözülür.',
      tempoHint: 'orta tempo, neşeli',
      visualOpportunities: ['renkli geçişler', 'karakter dansı', 'doğa manzaraları'],
      transitions: ['yumuşak geçiş', 'kesme']
    };
  }

  async buildVisualBible(input: CreateStoryboardInput): Promise<VisualBible> {
    const characterBible = input.characterNames.length
      ? `Karakterler: ${input.characterNames.join(', ')}. Her sahnede aynı fiziksel görünüm, kıyafet ve renk paleti korunmalı.`
      : 'Sabit, tutarlı bir ana karakter tasarımı kullanılmalı.';

    return {
      globalStyle: `${input.videoStyle}${input.styleNotes ? ' — ' + input.styleNotes : ''}. Çocuklara uygun, güvenli, pozitif görsel dil.`,
      characterBible,
      environmentBible: 'Sıcak renkler, yumuşak ışık, güvenli ve davetkâr ortamlar (orman, köy meydanı, oyun alanı).',
      colorPalette: ['#FFB703', '#219EBC', '#8ECAE6', '#FB8500', '#FFFFFF'],
      recurringProps: ['büyülü kitap', 'rengarenk balonlar'],
      cameraLanguage: 'Yumuşak kamera hareketleri, orta ve geniş plan ağırlıklı, hızlı kesme yok.',
      animationStyle: input.videoStyle,
      lighting: 'Yumuşak, sıcak, gündüz ışığı ağırlıklı',
      visualRules: [
        'Karakter görünümü sahneler arasında değişmemeli.',
        'Şiddet, korkutucu unsur veya karanlık temalar kullanılmamalı.',
        'Telif hakkı olan karakter/marka görselleri kullanılmamalı.'
      ]
    };
  }

  async createStoryboard(input: CreateStoryboardInput): Promise<StoryboardScene[]> {
    const perScene =
      input.sceneDurationPreference === 'auto'
        ? 6
        : input.sceneDurationPreference === 'max'
          ? 8
          : Number(input.sceneDurationPreference);

    const sceneCount = Math.max(3, Math.round(input.durationSeconds / perScene));
    const actualPerScene = input.durationSeconds / sceneCount;

    const analysisSections = input.analysis.sections.length ? input.analysis.sections : [
      { type: 'verse' as const, index: 0, startLine: 0, endLine: 0, text: input.lyrics.slice(0, 60), emotionalTone: 'neşeli', isRepeat: false }
    ];

    const scenes: StoryboardScene[] = [];
    for (let i = 0; i < sceneCount; i++) {
      const start = Number((i * actualPerScene).toFixed(2));
      const end = Number(((i + 1) * actualPerScene).toFixed(2));
      const section = analysisSections[i % analysisSections.length];
      const location = input.analysis.locations[i % Math.max(1, input.analysis.locations.length)] || 'renkli bir dünya';

      scenes.push({
        order: i,
        startTime: start,
        endTime: end,
        duration: Number((end - start).toFixed(2)),
        lyricsSegment: section.text,
        narrativePurpose: i === 0 ? 'Girişi tanıt' : i === sceneCount - 1 ? 'Hikâyeyi mutlu şekilde bitir' : 'Hikâyeyi ilerlet',
        location,
        characters: input.characterNames,
        characterActions: 'karakterler müzikle uyumlu şekilde hareket eder, gülümser, keşfeder',
        camera: i % 2 === 0 ? 'geniş plan, yavaş yatay kaydırma' : 'orta plan, sabit kamera',
        lighting: 'sıcak, yumuşak gündüz ışığı',
        environment: location,
        visualStyle: input.videoStyle,
        transition: i === sceneCount - 1 ? 'yumuşak kararma' : 'yumuşak geçiş',
        videoPrompt: '', // assembled later by visual-bible.service from the Visual Bible
        negativePrompt: 'şiddet, karanlık temalar, korkutucu unsurlar, bulanık görüntü, deforme eller',
        continuityNotes: 'Önceki sahnedeki karakter görünümü ve kıyafetler birebir korunmalı.'
      });
    }
    return scenes;
  }

  async translateSubtitles(input: TranslateSubtitleInput) {
    // Basit demo çevirisi: gerçek çeviri değildir, yalnızca dil etiketiyle işaretler.
    const prefixByLang: Record<string, string> = {
      EN: '[EN] ',
      DE: '[DE] ',
      ES: '[ES] ',
      AR: '[AR] '
    };
    return input.lines.map((l) => ({
      ...l,
      text: `${prefixByLang[input.targetLanguage] ?? ''}${l.text}`
    }));
  }

  async generateYoutubePackage(input: GenerateYoutubePackageInput): Promise<PublishPackageDraft> {
    const title = `${input.title} 🎵 Çocuklar İçin Eğlenceli Şarkı`;
    return {
      title,
      shortDescription: `${input.title} ile eğlenceli bir maceraya çıkıyoruz! 🎶`,
      longDescription:
        `${input.title}, çocuklar için özel olarak hazırlanmış, renkli ve eğitici bir müzik videosudur.\n\n` +
        `Bu videoda ${input.analysis.theme.toLowerCase()} temasını işliyoruz. Şarkıyı dinlerken birlikte söyleyin, dans edin! 💃🕺\n\n` +
        `#çocukşarkıları #animasyon #yenişarkı`,
      hashtags: ['#çocukşarkıları', '#animasyon', '#yenişarkı', '#çizgifilm'],
      tags: ['çocuk şarkıları', 'animasyon', 'eğitici video', input.title],
      thumbnailText: 'Neler Oldu?',
      pinnedComment: `${input.title} şarkısını beğendiniz mi? Yorumlarda bize anlatın! ❤️`,
      playlistSuggestion: 'Çocuk Şarkıları Koleksiyonu'
    };
  }
}
