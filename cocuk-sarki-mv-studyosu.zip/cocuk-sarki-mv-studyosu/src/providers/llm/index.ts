import { LLMProvider } from './types';
import { DemoLLMProvider } from './demo-llm-provider';
import { isDemoMode, isProviderConfigured } from '@/lib/env';

let cached: LLMProvider | null = null;

/**
 * Fabrika fonksiyonu: DEMO_MODE açıksa veya OpenAI anahtarı yoksa Demo
 * sağlayıcıya otomatik olarak düşer. Uygulama asla bu yüzden çökmez.
 */
export function getLLMProvider(): LLMProvider {
  if (cached) return cached;

  if (isDemoMode() || !isProviderConfigured('openai')) {
    cached = new DemoLLMProvider();
    return cached;
  }

  // Lazy import: OpenAI SDK sadece gerçekten gerektiğinde yüklenir.
  // eslint-disable-next-line @typescript-eslint/no-var-requires
  const { OpenAILLMProvider } = require('./openai-provider');
  cached = new OpenAILLMProvider();
  return cached as LLMProvider;
}

export type { LLMProvider } from './types';
