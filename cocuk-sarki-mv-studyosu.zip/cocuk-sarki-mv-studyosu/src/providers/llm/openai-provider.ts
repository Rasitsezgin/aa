import OpenAI from 'openai';
import {
  LLMProvider,
  AnalyzeSongInput,
  CreateStoryboardInput,
  TranslateSubtitleInput,
  GenerateYoutubePackageInput
} from './types';
import {
  SongAnalysis,
  SongAnalysisSchema,
  StoryboardScene,
  StoryboardSceneSchema,
  VisualBible,
  VisualBibleSchema,
  PublishPackageDraft
} from '@/types';
import { KullaniciDostuHata } from '@/types';
import { z } from 'zod';

/**
 * OpenAILLMProvider — gerçek API çağrıları yapar.
 * Tüm çıktılar zorunlu JSON şemasıyla doğrulanır (bkz. §6: "Never rely only
 * on free-form AI text. Use strict schemas and validation.").
 */
export class OpenAILLMProvider implements LLMProvider {
  readonly key = 'openai';
  private client: OpenAI;
  private model: string;

  constructor() {
    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey) {
      throw new KullaniciDostuHata(
        'Bu sağlayıcı için API anahtarı eksik: OpenAI (LLM).',
        'OPENAI_API_KEY ortam değişkeni tanımlı değil.'
      );
    }
    this.client = new OpenAI({ apiKey });
    this.model = process.env.OPENAI_MODEL || 'gpt-4o-mini';
  }

  private async completeJson<T>(systemPrompt: string, userPrompt: string, schema: z.ZodType<T>): Promise<T> {
    const response = await this.client.chat.completions.create({
      model: this.model,
      response_format: { type: 'json_object' },
      messages: [
        { role: 'system', content: systemPrompt + '\nSADECE geçerli JSON döndür. Başka açıklama, yorum veya markdown ekleme.' },
        { role: 'user', content: userPrompt }
      ]
    });

    const raw = response.choices[0]?.message?.content ?? '{}';
    let parsed: unknown;
    try {
      parsed = JSON.parse(raw);
    } catch {
      throw new KullaniciDostuHata(
        'Yapay zekâ sağlayıcısından geçersiz bir yanıt alındı.',
        `JSON parse hatası. Ham yanıt: ${raw.slice(0, 500)}`
      );
    }
    const result = schema.safeParse(parsed);
    if (!result.success) {
      throw new KullaniciDostuHata(
        'Yapay zekâ analizi beklenen formatta değil, lütfen tekrar deneyin.',
        result.error.message
      );
    }
    return result.data;
  }

  async analyzeSong(input: AnalyzeSongInput): Promise<SongAnalysis> {
    return this.completeJson(
      'Sen çocuk şarkıları için hikâye analisti bir yapay zekâsın. Şarkı sözlerini analiz edip ' +
        'yapılandırılmış bir JSON çıktısı üretiyorsun: title, theme, characters, locations, objects, ' +
        'sections (type, index, startLine, endLine, text, emotionalTone, isRepeat), visual_style, ' +
        'story_arc, tempoHint, visualOpportunities, transitions.',
      `Şarkı sözleri:\n${input.lyrics}\n\nŞarkı süresi: ${input.durationSeconds} saniye.`,
      SongAnalysisSchema
    ) as Promise<SongAnalysis>;
  }

  async buildVisualBible(input: CreateStoryboardInput): Promise<VisualBible> {
    return this.completeJson(
      'Sen bir görsel yönetmensin. Bir "Görsel İncil" (Visual Bible) hazırlıyorsun: globalStyle, ' +
        'characterBible, environmentBible, colorPalette (dizi), recurringProps (dizi), cameraLanguage, ' +
        'animationStyle, lighting, visualRules (dizi). Bu bilgiler her sahne için tutarlılığı garanti eder.',
      `Video stili: ${input.videoStyle}\nStil notları: ${input.styleNotes ?? '-'}\n` +
        `Karakterler: ${input.characterNames.join(', ') || 'belirtilmedi'}\nTema: ${input.analysis.theme}`,
      VisualBibleSchema
    ) as Promise<VisualBible>;
  }

  async createStoryboard(input: CreateStoryboardInput): Promise<StoryboardScene[]> {
    const arraySchema = z.object({ scenes: z.array(StoryboardSceneSchema) });
    const result = (await this.completeJson(
      'Sen bir storyboard yönetmenisin. Verilen şarkı analizine göre sahnelere bölünmüş bir storyboard ' +
        'üretiyorsun. Çıktı {"scenes": [...]} formatında olmalı. Her sahne StoryboardScene şemasına uymalı: ' +
        'order, startTime, endTime, duration, lyricsSegment, narrativePurpose, location, characters (dizi), ' +
        'characterActions, camera, lighting, environment, visualStyle, transition, videoPrompt, negativePrompt, ' +
        'continuityNotes. videoPrompt alanını boş bırak; bu değer sonradan Görsel İncil ile birleştirilecek.',
      `Analiz: ${JSON.stringify(input.analysis)}\nToplam süre: ${input.durationSeconds}s\n` +
        `Video stili: ${input.videoStyle}\nSahne süresi tercihi: ${input.sceneDurationPreference}\n` +
        `Karakterler: ${input.characterNames.join(', ')}`,
      arraySchema
    )) as { scenes: StoryboardScene[] };
    return result.scenes;
  }

  async translateSubtitles(input: TranslateSubtitleInput) {
    const schema = z.object({
      lines: z.array(z.object({ index: z.number(), startMs: z.number(), endMs: z.number(), text: z.string() }))
    });
    const result = await this.completeJson(
      `Sen profesyonel bir çevirmensin. Türkçe altyazı satırlarını ${input.targetLanguage} diline çeviriyorsun. ` +
        `Şu özel adları ASLA yanlış çevirme veya değiştirme: ${input.protectedNames.join(', ') || 'yok'}. ` +
        'Zaman kodlarını (startMs, endMs) ve index değerlerini AYNEN koru, sadece text alanını çevir.',
      JSON.stringify(input.lines),
      schema
    );
    return result.lines;
  }

  async generateYoutubePackage(input: GenerateYoutubePackageInput): Promise<PublishPackageDraft> {
    const schema = z.object({
      title: z.string(),
      shortDescription: z.string(),
      longDescription: z.string(),
      hashtags: z.array(z.string()),
      tags: z.array(z.string()),
      thumbnailText: z.string(),
      pinnedComment: z.string(),
      playlistSuggestion: z.string()
    });
    return this.completeJson(
      'Sen bir YouTube büyüme uzmanısın. Çocuk şarkısı videosu için doğal, merak uyandıran ama ' +
        'hikâyeyi baştan sona anlatmayan kısa bir YouTube yayın paketi hazırlıyorsun. Thumbnail metni en ' +
        'fazla 3 kelime olmalı ve Türkçe olmalı.',
      `Şarkı: ${input.title}\nTema: ${input.analysis.theme}\nHikâye: ${input.analysis.story_arc}`,
      schema
    );
  }
}
