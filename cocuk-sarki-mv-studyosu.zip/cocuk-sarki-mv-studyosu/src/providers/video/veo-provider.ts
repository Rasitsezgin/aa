import fs from 'node:fs/promises';
import {
  VideoProvider,
  TextToVideoInput,
  ImageToVideoInput,
  GenerationJobHandle,
  GenerationStatusResult
} from './types';
import { httpJson, requireApiKey } from './base-http-provider';

const BASE_URL = process.env.GOOGLE_AI_API_BASE || 'https://generativelanguage.googleapis.com/v1beta';

/**
 * VeoVideoProvider — Google Veo API adaptörü.
 * İstek/yanıt gövdesi, sağlayıcının güncel API sürümüne göre doğrulanmalı ve
 * gerekirse güncellenmelidir; burada VideoProvider arayüzüne uyan sabit bir
 * iskelet sağlanmıştır.
 */
export class VeoVideoProvider implements VideoProvider {
  readonly key = 'veo' as const;
  readonly label = 'Google Veo';
  readonly maxSceneDurationSeconds = 8;

  private apiKey() {
    return requireApiKey('GOOGLE_AI_API_KEY', 'Google Veo');
  }

  async generateTextToVideo(input: TextToVideoInput): Promise<GenerationJobHandle> {
    const key = this.apiKey();
    const result = await httpJson<{ name: string }>(
      `${BASE_URL}/models/veo:generateVideo?key=${key}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: input.prompt,
          negativePrompt: input.negativePrompt,
          aspectRatio: input.aspectRatio,
          resolution: input.resolution,
          durationSeconds: Math.min(input.durationSeconds, this.maxSceneDurationSeconds),
          seed: input.seed
        })
      },
      this.label
    );
    return { externalJobId: result.name, status: 'submitting' };
  }

  async generateImageToVideo(input: ImageToVideoInput): Promise<GenerationJobHandle> {
    const key = this.apiKey();
    const result = await httpJson<{ name: string }>(
      `${BASE_URL}/models/veo:generateVideo?key=${key}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: input.prompt,
          image: { url: input.imageUrl },
          negativePrompt: input.negativePrompt,
          aspectRatio: input.aspectRatio,
          resolution: input.resolution,
          durationSeconds: Math.min(input.durationSeconds, this.maxSceneDurationSeconds)
        })
      },
      this.label
    );
    return { externalJobId: result.name, status: 'submitting' };
  }

  async getGenerationStatus(externalJobId: string): Promise<GenerationStatusResult> {
    const key = this.apiKey();
    const result = await httpJson<{
      done?: boolean;
      error?: { message: string };
      response?: { videoUri?: string };
      metadata?: { progressPercent?: number };
    }>(`${BASE_URL}/${externalJobId}?key=${key}`, { method: 'GET' }, this.label);

    if (result.error) {
      return { status: 'failed', errorMessage: result.error.message };
    }
    if (result.done) {
      return { status: 'completed', progressPercent: 100, videoUrl: result.response?.videoUri };
    }
    return { status: 'generating', progressPercent: result.metadata?.progressPercent ?? 30 };
  }

  async downloadVideo(externalJobId: string, destinationPath: string): Promise<void> {
    const status = await this.getGenerationStatus(externalJobId);
    if (status.status !== 'completed' || !status.videoUrl) {
      throw new Error('Video henüz indirilmeye hazır değil.');
    }
    const res = await fetch(status.videoUrl);
    if (!res.ok) throw new Error(`Video indirilemedi: HTTP ${res.status}`);
    const buffer = Buffer.from(await res.arrayBuffer());
    await fs.mkdir(destinationPath.substring(0, destinationPath.lastIndexOf('/')), { recursive: true });
    await fs.writeFile(destinationPath, buffer);
  }

  async cancelGeneration(externalJobId: string): Promise<void> {
    const key = this.apiKey();
    await httpJson(`${BASE_URL}/${externalJobId}:cancel?key=${key}`, { method: 'POST' }, this.label);
  }
}
