import { randomUUID } from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import ffmpeg from 'fluent-ffmpeg';
import {
  VideoProvider,
  TextToVideoInput,
  ImageToVideoInput,
  GenerationJobHandle,
  GenerationStatusResult
} from './types';

interface DemoJob {
  status: 'queued' | 'generating' | 'completed' | 'failed';
  filePath?: string;
  createdAt: number;
  input: TextToVideoInput;
}

const jobs = new Map<string, DemoJob>();

const RESOLUTION_MAP: Record<string, string> = {
  '720p': '1280x720',
  '1080p': '1920x1080',
  '4K': '3840x2160'
};

const ASPECT_SIZE: Record<string, Record<string, string>> = {
  '16:9': { '720p': '1280x720', '1080p': '1920x1080', '4K': '3840x2160' },
  '9:16': { '720p': '720x1280', '1080p': '1080x1920', '4K': '2160x3840' },
  '1:1': { '720p': '720x720', '1080p': '1080x1080', '4K': '2160x2160' }
};

const DEMO_COLORS = ['#8b5cf6', '#22d3ee', '#f59e0b', '#34d399', '#f472b6', '#60a5fa'];

function escapeForDrawtext(text: string) {
  return text.replace(/\\/g, '\\\\').replace(/:/g, '\\:').replace(/'/g, "\\'").slice(0, 90);
}

/**
 * DemoVideoProvider — gerçek bir video-üretim API'si çağırmaz.
 * Bunun yerine FFmpeg ile, sahne bilgisini (kısaltılmış prompt) ekranda
 * gösteren renkli, gerçek bir MP4 klip üretir. Böylece tüm pipeline
 * (indirme, birleştirme, altyazı, önizleme) API anahtarı olmadan uçtan
 * uca test edilebilir. §33/§34 kuralı: sahte "başarılı" simülasyon yok —
 * gerçekten oynatılabilir bir dosya üretiliyor, sadece görüntü AI değil.
 */
export class DemoVideoProvider implements VideoProvider {
  readonly key = 'demo' as const;
  readonly label = 'Demo Modu (yerel, ücretsiz)';
  readonly maxSceneDurationSeconds = 8;

  private tmpDir = path.join(process.cwd(), 'projects', '.demo-tmp');

  private async ensureTmpDir() {
    await fs.mkdir(this.tmpDir, { recursive: true });
  }

  async generateTextToVideo(input: TextToVideoInput): Promise<GenerationJobHandle> {
    await this.ensureTmpDir();
    const jobId = randomUUID();
    jobs.set(jobId, { status: 'queued', createdAt: Date.now(), input });

    // Arka planda "üretimi" simüle et (gerçekte FFmpeg ile klip render eder).
    this.render(jobId).catch((err) => {
      const job = jobs.get(jobId);
      if (job) job.status = 'failed';
      console.error('[DemoVideoProvider] render hatası:', err);
    });

    return { externalJobId: jobId, status: 'queued' };
  }

  async generateImageToVideo(input: ImageToVideoInput): Promise<GenerationJobHandle> {
    // Demo modunda image-to-video, text-to-video ile aynı şekilde ele alınır.
    return this.generateTextToVideo(input);
  }

  private async render(jobId: string) {
    const job = jobs.get(jobId);
    if (!job) return;
    job.status = 'generating';

    const size = ASPECT_SIZE[job.input.aspectRatio]?.[job.input.resolution] || RESOLUTION_MAP[job.input.resolution] || '1280x720';
    const color = DEMO_COLORS[Math.abs(hashCode(job.input.prompt)) % DEMO_COLORS.length];
    const label = escapeForDrawtext(job.input.prompt || 'Sahne');
    const outPath = path.join(this.tmpDir, `${jobId}.mp4`);
    const duration = Math.max(1, job.input.durationSeconds);

    await new Promise<void>((resolve, reject) => {
      ffmpeg()
        .input(`color=c=${color.replace('#', '0x')}:s=${size}:d=${duration}`)
        .inputFormat('lavfi')
        .videoFilters([
          {
            filter: 'drawtext',
            options: {
              text: label,
              fontcolor: 'white',
              fontsize: 42,
              x: '(w-text_w)/2',
              y: '(h-text_h)/2',
              box: 1,
              boxcolor: 'black@0.4',
              boxborderw: 20
            }
          }
        ])
        .outputOptions(['-pix_fmt yuv420p', '-r 30', '-an'])
        .save(outPath)
        .on('end', () => resolve())
        .on('error', (err) => reject(err));
    });

    job.filePath = outPath;
    job.status = 'completed';
  }

  async getGenerationStatus(externalJobId: string): Promise<GenerationStatusResult> {
    const job = jobs.get(externalJobId);
    if (!job) {
      return { status: 'failed', errorMessage: 'İş bulunamadı (muhtemelen sunucu yeniden başlatıldı).' };
    }
    return {
      status: job.status === 'queued' ? 'queued' : job.status === 'generating' ? 'generating' : job.status,
      progressPercent: job.status === 'completed' ? 100 : job.status === 'generating' ? 60 : 10,
      videoUrl: job.filePath
    };
  }

  async downloadVideo(externalJobId: string, destinationPath: string): Promise<void> {
    const job = jobs.get(externalJobId);
    if (!job || !job.filePath) {
      throw new Error('Video henüz hazır değil veya iş bulunamadı.');
    }
    await fs.mkdir(path.dirname(destinationPath), { recursive: true });
    await fs.copyFile(job.filePath, destinationPath);
  }

  async cancelGeneration(externalJobId: string): Promise<void> {
    const job = jobs.get(externalJobId);
    if (job) job.status = 'failed';
  }
}

function hashCode(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) - hash + str.charCodeAt(i);
    hash |= 0;
  }
  return hash;
}
