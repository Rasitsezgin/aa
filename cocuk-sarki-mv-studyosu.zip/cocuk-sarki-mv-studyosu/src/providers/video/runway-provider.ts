import fs from 'node:fs/promises';
import path from 'node:path';
import {
  VideoProvider,
  TextToVideoInput,
  ImageToVideoInput,
  GenerationJobHandle,
  GenerationStatusResult
} from './types';
import { httpJson, requireApiKey } from './base-http-provider';

const BASE_URL = process.env.RUNWAY_API_BASE || 'https://api.runwayml.com/v1';

/** RunwayVideoProvider — Runway API adaptörü. Uç noktalar güncel dokümantasyona göre doğrulanmalıdır. */
export class RunwayVideoProvider implements VideoProvider {
  readonly key = 'runway' as const;
  readonly label = 'Runway';
  readonly maxSceneDurationSeconds = 10;

  private headers() {
    const key = requireApiKey('RUNWAY_API_KEY', this.label);
    return { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' };
  }

  async generateTextToVideo(input: TextToVideoInput): Promise<GenerationJobHandle> {
    const result = await httpJson<{ id: string; status: string }>(
      `${BASE_URL}/generations`,
      {
        method: 'POST',
        headers: this.headers(),
        body: JSON.stringify({
          prompt_text: input.prompt,
          negative_prompt: input.negativePrompt,
          aspect_ratio: input.aspectRatio,
          resolution: input.resolution,
          duration: Math.min(input.durationSeconds, this.maxSceneDurationSeconds),
          seed: input.seed
        })
      },
      this.label
    );
    return { externalJobId: result.id, status: 'submitting' };
  }

  async generateImageToVideo(input: ImageToVideoInput): Promise<GenerationJobHandle> {
    const result = await httpJson<{ id: string }>(
      `${BASE_URL}/generations`,
      {
        method: 'POST',
        headers: this.headers(),
        body: JSON.stringify({
          prompt_text: input.prompt,
          init_image: input.imageUrl,
          negative_prompt: input.negativePrompt,
          aspect_ratio: input.aspectRatio,
          resolution: input.resolution,
          duration: Math.min(input.durationSeconds, this.maxSceneDurationSeconds)
        })
      },
      this.label
    );
    return { externalJobId: result.id, status: 'submitting' };
  }

  async getGenerationStatus(externalJobId: string): Promise<GenerationStatusResult> {
    const result = await httpJson<{ status: string; progress?: number; output?: string[]; failure_reason?: string }>(
      `${BASE_URL}/generations/${externalJobId}`,
      { method: 'GET', headers: this.headers() },
      this.label
    );
    const statusMap: Record<string, GenerationStatusResult['status']> = {
      PENDING: 'queued',
      RUNNING: 'generating',
      SUCCEEDED: 'completed',
      FAILED: 'failed',
      CANCELLED: 'cancelled'
    };
    return {
      status: statusMap[result.status] ?? 'generating',
      progressPercent: result.progress ? Math.round(result.progress * 100) : undefined,
      errorMessage: result.failure_reason,
      videoUrl: result.output?.[0]
    };
  }

  async downloadVideo(externalJobId: string, destinationPath: string): Promise<void> {
    const status = await this.getGenerationStatus(externalJobId);
    if (status.status !== 'completed' || !status.videoUrl) throw new Error('Video henüz hazır değil.');
    const res = await fetch(status.videoUrl);
    if (!res.ok) throw new Error(`Video indirilemedi: HTTP ${res.status}`);
    const buffer = Buffer.from(await res.arrayBuffer());
    await fs.mkdir(path.dirname(destinationPath), { recursive: true });
    await fs.writeFile(destinationPath, buffer);
  }

  async cancelGeneration(externalJobId: string): Promise<void> {
    await httpJson(`${BASE_URL}/generations/${externalJobId}/cancel`, { method: 'POST', headers: this.headers() }, this.label);
  }
}
