import { KullaniciDostuHata } from '@/types';

/**
 * Gerçek sağlayıcı adaptörleri (Veo / Runway / Luma) için ortak yardımcılar.
 * NOT: Her sağlayıcının API uç noktaları ve istek/yanıt şemaları zamanla
 * değişebilir. Prodüksiyona almadan önce ilgili sağlayıcının güncel API
 * dokümantasyonunu kontrol edip `submitPath` / `statusPath` / `request
 * body` alanlarını buna göre güncelleyin. Mimari (VideoProvider arayüzü)
 * değişmeden yalnızca bu adaptörlerin iç detayları güncellenir.
 */
export async function httpJson<T>(
  url: string,
  options: RequestInit,
  providerLabel: string
): Promise<T> {
  const res = await fetch(url, options);
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    throw new KullaniciDostuHata(
      `${providerLabel} video sağlayıcısına ulaşılamadı. Lütfen daha sonra tekrar deneyin.`,
      `HTTP ${res.status} ${res.statusText} — ${body.slice(0, 500)}`
    );
  }
  return (await res.json()) as T;
}

export function requireApiKey(envVar: string, providerLabel: string): string {
  const key = process.env[envVar];
  if (!key) {
    throw new KullaniciDostuHata(
      `Bu sağlayıcı için API anahtarı eksik: ${providerLabel}.`,
      `${envVar} ortam değişkeni tanımlı değil.`
    );
  }
  return key;
}
