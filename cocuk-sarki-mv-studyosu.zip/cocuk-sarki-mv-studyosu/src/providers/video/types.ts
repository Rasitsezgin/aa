export interface TextToVideoInput {
  prompt: string;
  negativePrompt?: string;
  aspectRatio: '16:9' | '9:16' | '1:1';
  resolution: '720p' | '1080p' | '4K';
  durationSeconds: number;
  seed?: number;
  referenceImageUrl?: string; // for continuity between scenes
}

export interface ImageToVideoInput extends TextToVideoInput {
  imageUrl: string;
}

export type ExternalGenerationStatus =
  | 'queued'
  | 'submitting'
  | 'generating'
  | 'processing'
  | 'completed'
  | 'failed'
  | 'cancelled';

export interface GenerationJobHandle {
  externalJobId: string;
  status: ExternalGenerationStatus;
}

export interface GenerationStatusResult {
  status: ExternalGenerationStatus;
  progressPercent?: number;
  errorMessage?: string;
  videoUrl?: string; // present once completed
}

/**
 * VideoProvider — tüm video üretim sağlayıcılarının uyması gereken arayüz.
 * Yeni bir sağlayıcı eklemek için sadece bu arayüzü uygulayan bir sınıf
 * yazmak ve providers/video/index.ts içine kaydetmek yeterlidir.
 */
export interface VideoProvider {
  readonly key: 'veo' | 'runway' | 'luma' | 'demo';
  readonly label: string;
  readonly maxSceneDurationSeconds: number;

  generateTextToVideo(input: TextToVideoInput): Promise<GenerationJobHandle>;
  generateImageToVideo(input: ImageToVideoInput): Promise<GenerationJobHandle>;
  getGenerationStatus(externalJobId: string): Promise<GenerationStatusResult>;
  downloadVideo(externalJobId: string, destinationPath: string): Promise<void>;
  cancelGeneration(externalJobId: string): Promise<void>;
}
