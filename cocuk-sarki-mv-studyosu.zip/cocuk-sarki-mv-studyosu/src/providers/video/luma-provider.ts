import fs from 'node:fs/promises';
import path from 'node:path';
import {
  VideoProvider,
  TextToVideoInput,
  ImageToVideoInput,
  GenerationJobHandle,
  GenerationStatusResult
} from './types';
import { httpJson, requireApiKey } from './base-http-provider';

const BASE_URL = process.env.LUMA_API_BASE || 'https://api.lumalabs.ai/dream-machine/v1';

/** LumaVideoProvider — Luma Dream Machine API adaptörü. Uç noktalar güncel dokümantasyona göre doğrulanmalıdır. */
export class LumaVideoProvider implements VideoProvider {
  readonly key = 'luma' as const;
  readonly label = 'Luma';
  readonly maxSceneDurationSeconds = 5;

  private headers() {
    const key = requireApiKey('LUMA_API_KEY', this.label);
    return { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' };
  }

  async generateTextToVideo(input: TextToVideoInput): Promise<GenerationJobHandle> {
    const result = await httpJson<{ id: string; state: string }>(
      `${BASE_URL}/generations`,
      {
        method: 'POST',
        headers: this.headers(),
        body: JSON.stringify({
          prompt: input.prompt,
          aspect_ratio: input.aspectRatio,
          loop: false
        })
      },
      this.label
    );
    return { externalJobId: result.id, status: 'submitting' };
  }

  async generateImageToVideo(input: ImageToVideoInput): Promise<GenerationJobHandle> {
    const result = await httpJson<{ id: string }>(
      `${BASE_URL}/generations`,
      {
        method: 'POST',
        headers: this.headers(),
        body: JSON.stringify({
          prompt: input.prompt,
          keyframes: { frame0: { type: 'image', url: input.imageUrl } },
          aspect_ratio: input.aspectRatio
        })
      },
      this.label
    );
    return { externalJobId: result.id, status: 'submitting' };
  }

  async getGenerationStatus(externalJobId: string): Promise<GenerationStatusResult> {
    const result = await httpJson<{ state: string; failure_reason?: string; assets?: { video?: string } }>(
      `${BASE_URL}/generations/${externalJobId}`,
      { method: 'GET', headers: this.headers() },
      this.label
    );
    const statusMap: Record<string, GenerationStatusResult['status']> = {
      queued: 'queued',
      dreaming: 'generating',
      completed: 'completed',
      failed: 'failed'
    };
    return {
      status: statusMap[result.state] ?? 'generating',
      errorMessage: result.failure_reason,
      videoUrl: result.assets?.video
    };
  }

  async downloadVideo(externalJobId: string, destinationPath: string): Promise<void> {
    const status = await this.getGenerationStatus(externalJobId);
    if (status.status !== 'completed' || !status.videoUrl) throw new Error('Video henüz hazır değil.');
    const res = await fetch(status.videoUrl);
    if (!res.ok) throw new Error(`Video indirilemedi: HTTP ${res.status}`);
    const buffer = Buffer.from(await res.arrayBuffer());
    await fs.mkdir(path.dirname(destinationPath), { recursive: true });
    await fs.writeFile(destinationPath, buffer);
  }

  async cancelGeneration(externalJobId: string): Promise<void> {
    await httpJson(`${BASE_URL}/generations/${externalJobId}`, { method: 'DELETE', headers: this.headers() }, this.label);
  }
}
