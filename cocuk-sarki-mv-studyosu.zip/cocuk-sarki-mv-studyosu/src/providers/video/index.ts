import { VideoProvider } from './types';
import { DemoVideoProvider } from './demo-video-provider';
import { isDemoMode, isProviderConfigured } from '@/lib/env';
import { KullaniciDostuHata } from '@/types';

const registry: Record<string, () => VideoProvider> = {
  demo: () => new DemoVideoProvider(),
  veo: () => {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const { VeoVideoProvider } = require('./veo-provider');
    return new VeoVideoProvider();
  },
  runway: () => {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const { RunwayVideoProvider } = require('./runway-provider');
    return new RunwayVideoProvider();
  },
  luma: () => {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const { LumaVideoProvider } = require('./luma-provider');
    return new LumaVideoProvider();
  }
};

/**
 * Uygulama tek bir sağlayıcıya bağlı DEĞİLDİR. Proje ayarındaki
 * `videoProviderKey` değerine göre çalışma zamanında doğru adaptör seçilir.
 * DEMO_MODE=true ise veya seçili sağlayıcının API anahtarı eksikse,
 * kullanıcıya Türkçe net bir uyarı gösterip Demo Moduna düşülür.
 */
export function getVideoProvider(key: string): VideoProvider {
  const resolvedKey = isDemoMode() ? 'demo' : key;

  if (resolvedKey !== 'demo' && !isProviderConfigured(resolvedKey)) {
    throw new KullaniciDostuHata(
      `Bu sağlayıcı için API anahtarı eksik: ${resolvedKey}. Ayarlar sayfasından kontrol edin ya da Demo Modunu kullanın.`,
      `${resolvedKey} sağlayıcısı için gerekli ortam değişkeni tanımlı değil.`
    );
  }

  const factory = registry[resolvedKey];
  if (!factory) {
    throw new KullaniciDostuHata(`Bilinmeyen video sağlayıcısı: ${resolvedKey}`);
  }
  return factory();
}

export function listVideoProviders(): string[] {
  return Object.keys(registry);
}

export type { VideoProvider } from './types';
