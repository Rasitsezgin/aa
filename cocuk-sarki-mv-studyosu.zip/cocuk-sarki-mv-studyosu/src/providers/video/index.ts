import { VideoProvider } from './types';
import { DemoVideoProvider } from './demo-video-provider';
import { isDemoMode, isProviderConfigured } from '@/lib/env';
import { KullaniciDostuHata } from '@/types';

const registry: Record<string, () => VideoProvider> = {
  demo: () => new DemoVideoProvider(),
  veo: () => {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const { VeoVideoProvider } = require('./veo-provider');
    return new VeoVideoProvider();
  },
  runway: () => {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const { RunwayVideoProvider } = require('./runway-provider');
    return new RunwayVideoProvider();
  },
  luma: () => {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const { LumaVideoProvider } = require('./luma-provider');
    return new LumaVideoProvider();
  }
};

/**
 * Uygulama tek bir sağlayıcıya bağlı DEĞİLDİR. Proje ayarındaki
 * `videoProviderKey` değerine göre çalışma zamanında doğru adaptör seçilir.
 *
 * ÖNEMLİ DAVRANIŞ (düzeltildi): DEMO_MODE artık bir "ZORLA GEÇERSİZ KIL"
 * anahtarı DEĞİL, yalnızca "API anahtarı eksikse nazikçe Demo Moduna düş"
 * anlamına gelir. Kullanıcı bir proje için gerçek bir sağlayıcı (Veo/Runway/
 * Luma) seçtiyse VE o sağlayıcının API anahtarı .env'de tanımlıysa, DEMO_MODE
 * ne olursa olsun GERÇEK sağlayıcı kullanılır. Böylece "API'leri bağladım ama
 * yine de demo video çıktı" sorunu bir daha yaşanmaz.
 */
export function getVideoProvider(key: string): { provider: VideoProvider; usedDemoFallback: boolean } {
  if (key === 'demo') {
    return { provider: new DemoVideoProvider(), usedDemoFallback: false };
  }

  const configured = isProviderConfigured(key);

  if (!configured) {
    if (isDemoMode()) {
      // Nazik geri düşüş: anahtar yok ama Demo Modu açık → demo ile devam et.
      return { provider: new DemoVideoProvider(), usedDemoFallback: true };
    }
    throw new KullaniciDostuHata(
      `Bu sağlayıcı için API anahtarı eksik: ${key}. Ayarlar sayfasından kontrol edin, .env dosyasına anahtarı ekleyin ya da proje ayarlarından "Demo Modu" sağlayıcısını seçin.`,
      `${key} sağlayıcısı için gerekli ortam değişkeni (.env) tanımlı değil.`
    );
  }

  const factory = registry[key];
  if (!factory) {
    throw new KullaniciDostuHata(`Bilinmeyen video sağlayıcısı: ${key}`);
  }
  return { provider: factory(), usedDemoFallback: false };
}

export function listVideoProviders(): string[] {
  return Object.keys(registry);
}

export type { VideoProvider } from './types';
