// Worker süreci giriş noktası. Next.js web sunucusundan AYRI bir process
// olarak çalıştırılır (bkz. deployment: PM2 ile iki ayrı process — "web" ve
// "worker"). Bu sayede video üretimi/FFmpeg render web isteklerini asla
// bloklamaz ve VPS yeniden başlatıldığında Redis'teki kuyruk durumu
// korunarak kaldığı yerden devam eder (bkz. §21 Resume Support).

import './workers/generate-scene.worker';
import './workers/render-video.worker';

console.log('[worker] Çocuk Şarkı MV Stüdyosu arka plan işçileri başlatıldı.');
console.log('[worker] Kuyruklar: generate-scene, render-video');

process.on('SIGTERM', () => {
  console.log('[worker] SIGTERM alındı, düzgün şekilde kapatılıyor...');
  process.exit(0);
});
