import { Worker, Job } from 'bullmq';
import { redisConnection } from '@/lib/redis';
import { processSceneGeneration } from '@/services/video-generation.service';

/**
 * Sahne üretim worker'ı. Kuyruktaki her işi işler; başarısız olursa BullMQ
 * otomatik olarak (üstel gecikmeyle) yeniden dener (retry, bkz. §9/§21).
 */
export const generateSceneWorker = new Worker(
  'generate-scene',
  async (job: Job<{ sceneId: string; jobId: string }>) => {
    return processSceneGeneration(job.data.sceneId, job.data.jobId);
  },
  { connection: redisConnection, concurrency: 3 }
);

generateSceneWorker.on('failed', (job, err) => {
  console.error(`[generate-scene] İş başarısız: ${job?.id}`, err);
});
