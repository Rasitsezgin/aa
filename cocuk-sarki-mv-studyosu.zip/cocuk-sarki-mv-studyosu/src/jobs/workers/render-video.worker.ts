import { Worker, Job } from 'bullmq';
import { redisConnection } from '@/lib/redis';
import { renderFinalVideo } from '@/services/ffmpeg.service';
import { generateAllSubtitles } from '@/services/subtitle.service';
import { generateThumbnail } from '@/services/thumbnail.service';
import { generateYoutubePublishPackage } from '@/services/youtube-package.service';

/**
 * Nihai render worker'ı: sahneler tamamlandıktan sonra FFmpeg birleştirme,
 * altyazı üretimi, thumbnail ve YouTube paketi adımlarını sırayla yürütür.
 */
export const renderVideoWorker = new Worker(
  'render-video',
  async (job: Job<{ projectId: string }>) => {
    const { projectId } = job.data;
    await job.updateProgress(10);
    const result = await renderFinalVideo(projectId);
    await job.updateProgress(60);
    await generateAllSubtitles(projectId);
    await job.updateProgress(80);
    await generateThumbnail(projectId);
    await job.updateProgress(90);
    await generateYoutubePublishPackage(projectId);
    await job.updateProgress(100);
    return result;
  },
  { connection: redisConnection, concurrency: 1 }
);

renderVideoWorker.on('failed', (job, err) => {
  console.error(`[render-video] İş başarısız: ${job?.id}`, err);
});
