'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import clsx from 'clsx';

const NAV_ITEMS = [
  { href: '/', label: 'Ana Sayfa', icon: '🏠' },
  { href: '/projeler', label: 'Projeler', icon: '📁' },
  { href: '/projeler/yeni', label: 'Yeni Proje', icon: '➕' },
  { href: '/ayarlar', label: 'Ayarlar', icon: '⚙️' }
];

export function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="w-64 shrink-0 h-screen sticky top-0 border-r border-studio-border bg-studio-panel flex flex-col">
      <div className="px-5 py-6 border-b border-studio-border">
        <div className="text-lg font-semibold flex items-center gap-2">
          <span>🎬</span>
          <span>Çocuk Şarkı MV Stüdyosu</span>
        </div>
        <div className="text-xs text-studio-muted mt-1">AI destekli müzik videosu üretimi</div>
      </div>

      <nav className="flex-1 px-3 py-4 space-y-1">
        {NAV_ITEMS.map((item) => {
          const active = pathname === item.href;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={clsx(
                'flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-colors',
                active ? 'bg-studio-accent/15 text-studio-accent2 font-medium' : 'text-studio-muted hover:bg-studio-panel2 hover:text-studio-text'
              )}
            >
              <span>{item.icon}</span>
              <span>{item.label}</span>
            </Link>
          );
        })}
      </nav>

      <div className="px-5 py-4 border-t border-studio-border text-xs text-studio-muted">
        Sürüm 0.1.0 — Demo Modu destekli
      </div>
    </aside>
  );
}
