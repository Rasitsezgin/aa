'use client';

const STATUS_CONFIG: Record<string, { label: string; className: string }> = {
  NOT_STARTED: { label: 'Başlamadı', className: 'bg-studio-panel2 text-studio-muted' },
  QUEUED: { label: 'Kuyrukta', className: 'bg-studio-panel2 text-studio-accent2' },
  SUBMITTING: { label: 'Gönderiliyor', className: 'bg-studio-accent2/15 text-studio-accent2' },
  GENERATING: { label: 'Üretiliyor', className: 'bg-studio-accent/15 text-studio-accent' },
  DOWNLOADING: { label: 'İndiriliyor', className: 'bg-studio-accent/15 text-studio-accent' },
  PROCESSING: { label: 'İşleniyor', className: 'bg-studio-accent/15 text-studio-accent' },
  COMPLETED: { label: 'Tamamlandı', className: 'bg-studio-success/15 text-studio-success' },
  FAILED: { label: 'Başarısız', className: 'bg-studio-danger/15 text-studio-danger' },
  CANCELLED: { label: 'İptal Edildi', className: 'bg-studio-panel2 text-studio-muted' },
  RETRYING: { label: 'Yeniden Deneniyor', className: 'bg-studio-warning/15 text-studio-warning' },
  DRAFT: { label: 'Taslak', className: 'bg-studio-panel2 text-studio-muted' },
  ANALYZING: { label: 'Analiz Ediliyor', className: 'bg-studio-accent2/15 text-studio-accent2' },
  STORYBOARD_READY: { label: 'Sahne Planı Hazır', className: 'bg-studio-accent2/15 text-studio-accent2' },
  RENDERING: { label: 'Render Ediliyor', className: 'bg-studio-accent/15 text-studio-accent' }
};

export function StatusBadge({ status }: { status: string }) {
  const cfg = STATUS_CONFIG[status] ?? { label: status, className: 'bg-studio-panel2 text-studio-muted' };
  return <span className={`badge ${cfg.className}`}>{cfg.label}</span>;
}
