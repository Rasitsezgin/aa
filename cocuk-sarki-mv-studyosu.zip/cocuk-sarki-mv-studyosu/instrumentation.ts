// Next.js sunucu başlarken bir kez çalışır. AÇIK MOD: giriş ekranı yoktur;
// bu hook yalnızca tek "Yerel Kullanıcı" kaydının veritabanında var olduğundan
// emin olur (bkz. src/lib/auth.ts).
export async function register() {
  if (process.env.NEXT_RUNTIME === 'nodejs') {
    const { ensureBootstrapAdmin } = await import('./src/lib/auth');
    await ensureBootstrapAdmin().catch((err) => console.error('[bootstrap] yerel kullanıcı oluşturulamadı:', err));
  }
}
