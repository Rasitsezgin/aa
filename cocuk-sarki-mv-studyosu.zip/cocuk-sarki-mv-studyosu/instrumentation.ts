// Next.js sunucu başlarken bir kez çalışır. İlk kurulumda .env'de
// ADMIN_EMAIL/ADMIN_PASSWORD tanımlıysa otomatik admin hesabı oluşturur.
export async function register() {
  if (process.env.NEXT_RUNTIME === 'nodejs') {
    const { ensureBootstrapAdmin } = await import('./src/lib/auth');
    await ensureBootstrapAdmin().catch((err) => console.error('[bootstrap] admin oluşturulamadı:', err));
  }
}
