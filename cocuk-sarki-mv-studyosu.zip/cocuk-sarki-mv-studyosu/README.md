# 🎬 Çocuk Şarkı MV Stüdyosu

AI destekli, çocuk şarkıları için müzik videosu üretim stüdyosu. Kullanıcının yüklediği
şarkı (MP3/WAV/FLAC) ve sözlerinden yola çıkarak hikâye, sahne planı, video sahneleri,
altyazılar, thumbnail ve YouTube yayın paketi üretir; sonunda kullanıcının orijinal
şarkısını nihai ses parçası olarak kullanan bir final.mp4 teslim eder.

> **Önemli — dürüst bir not:** Bu depo, spesifikasyondaki mimariyi (sağlayıcı
> soyutlaması, veritabanı şeması, iş kuyruğu, FFmpeg hattı, Türkçe arayüz) uçtan uca
> çalışan bir şekilde uygulayan **prodüksiyona hazır bir iskelettir**. **Demo Modu**
> gerçek API anahtarı gerekmeden tüm boru hattını (analiz → storyboard → sahne
> üretimi → FFmpeg birleştirme → altyazı → thumbnail → YouTube paketi) çalıştırır ve
> gerçek, oynatılabilir bir final.mp4 üretir — bu proje içinde FFmpeg komut dizisi
> ayrıca bağımsız olarak doğrulanmıştır. Gerçek Veo/Runway/Luma/Suno entegrasyonu için
> kendi API anahtarlarınızı girmeniz ve ilgili sağlayıcının güncel dokümantasyonuna göre
> `src/providers/video/*-provider.ts` dosyalarındaki uç noktaları doğrulamanız gerekir
> (sağlayıcıların API şemaları zamanla değişebilir).

---

## 1. Mimari Özeti

```
src/
  app/                Next.js sayfaları (Türkçe arayüz) + API route'ları
  providers/
    llm/               OpenAI + Demo LLM sağlayıcı adaptörleri
    video/             Veo, Runway, Luma + Demo video sağlayıcı adaptörleri
    music/             Suno (opsiyonel) müzik sağlayıcı adaptörü
  services/            Ana iş mantığı (analiz, storyboard, FFmpeg, altyazı, thumbnail, YouTube)
  jobs/                BullMQ kuyruk tanımları ve worker'lar
  lib/                 Prisma, Redis, auth, rate-limit, güvenli dosya yolları
  components/          Paylaşılan React bileşenleri
prisma/schema.prisma   Veritabanı şeması (15 model)
deploy/                Nginx örneği, VPS kurulum betiği
ecosystem.config.js    PM2 process yöneticisi yapılandırması (web + worker ayrı process)
docker-compose.yml     PostgreSQL + Redis
tests/                 Vitest testleri
scripts/demo-e2e.ts    Demo Modu uçtan uca doğrulama betiği
```

**Sağlayıcı soyutlaması:** `VideoProvider`, `LLMProvider`, `MusicProvider` arayüzleri
(`src/providers/*/types.ts`) sayesinde uygulama tek bir sağlayıcıya bağımlı değildir.
Yeni bir video sağlayıcısı eklemek için sadece bu arayüzü uygulayan bir sınıf yazıp
`src/providers/video/index.ts` içindeki `registry` nesnesine eklemeniz yeterlidir.

**Görsel süreklilik:** Her sahnenin prompt'u `assembleScenePrompt()`
(`src/services/visual-bible.service.ts`) tarafından GLOBAL STİL + KARAKTER İNCİLİ +
ORTAM İNCİLİ + SAHNE AKSİYONU + KAMERA + IŞIK + SÜREKLİLİK bilgilerinin birleşiminden
oluşturulur — karakterler sahneler arasında "yeniden icat edilmez".

**Ses kuralı:** `src/services/ffmpeg.service.ts` içindeki `renderFinalVideo()`
fonksiyonu, video modelinin ürettiği sesi asla kullanmaz; final.mp4'ün ses parçası her
zaman kullanıcının yüklediği orijinal şarkıdır (`-map 1:a:0` ile zorunlu kılınmıştır).

---

## 2. Gereksinimler

- Ubuntu 22.04+ VPS (2 vCPU / 4 GB RAM minimum; video render için daha fazlası önerilir)
- Node.js 20.x
- FFmpeg
- PostgreSQL 16 (Docker ile veya doğrudan kurulum)
- Redis 7 (Docker ile veya doğrudan kurulum)
- (Opsiyonel) Gerçek üretim için: OpenAI, Google Veo, Runway, Luma ve/veya Suno API anahtarları

---

## 3. Kurulum Adımları

### 3.1. Sistem bağımlılıklarını kurun

```bash
sudo bash deploy/vps-kurulum.sh
```

Bu betik Node.js 20, FFmpeg, Docker, PM2 ve Nginx'i kurar ve temel güvenlik duvarı
kurallarını açar. (İçeriğini kurmadan önce okumanız önerilir.)

### 3.2. Projeyi VPS'e kopyalayın

```bash
git clone <repo-url> cocuk-sarki-mv-studyosu
cd cocuk-sarki-mv-studyosu
```

### 3.3. Ortam değişkenlerini ayarlayın

```bash
cp .env.example .env
nano .env
```

Bkz. aşağıdaki **"4. Ortam Değişkenleri"** bölümü — her değişkenin ne işe yaradığı
açıklanmıştır. İlk kurulumda en azından şunları ayarlayın:

- `DATABASE_URL`, `REDIS_URL` (Docker Compose kullanıyorsanız varsayılanlar çalışır)
- `DEMO_MODE=true` (gerçek API anahtarınız olana kadar böyle bırakın)

> **Not — Açık Mod:** Bu sürümde giriş ekranı, e-posta veya parola YOKTUR.
> Uygulama açılır açılmaz doğrudan panele erişilir; hiçbir hesap oluşturmanıza
> gerek yoktur.

### 3.4. Veritabanı ve Redis'i başlatın

```bash
docker compose up -d
docker compose ps   # ikisinin de "healthy" olduğunu doğrulayın
```

### 3.5. Bağımlılıkları kurun ve veritabanını hazırlayın

```bash
npm install                  # postinstall otomatik olarak `prisma generate` çalıştırır
npx prisma migrate deploy    # tabloları oluşturur
```

### 3.6. Üretim derlemesi

```bash
npm run build
```

### 3.7. Uygulamayı PM2 ile başlatın

```bash
pm2 start ecosystem.config.js
pm2 save
pm2 startup      # verilen komutu çalıştırıp VPS yeniden başlasa da otomatik açılmasını sağlayın
```

Bu, **iki ayrı process** başlatır: `csms-web` (Next.js sunucusu, port 3000) ve
`csms-worker` (video üretimi/FFmpeg render'ı arka planda yürüten BullMQ worker'ı).
Video üretimi asla web isteklerini bloklamaz.

### 3.8. Nginx ters vekil + HTTPS

```bash
sudo cp deploy/nginx.conf.example /etc/nginx/sites-available/cocuk-sarki-studio
sudo nano /etc/nginx/sites-available/cocuk-sarki-studio   # alan adınızı girin
sudo ln -s /etc/nginx/sites-available/cocuk-sarki-studio /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
sudo certbot --nginx -d studio.example.com   # HTTPS için
```

### 3.9. Sağlık kontrolü

```bash
curl http://localhost:3000/api/health
```

`{"durum":"sağlıklı", ...}` yanıtını görmelisiniz.

---

## 4. Ortam Değişkenleri

| Değişken | Zorunlu mu? | Açıklama |
|---|---|---|
| `DATABASE_URL` | ✅ | PostgreSQL bağlantı adresi |
| `REDIS_URL` | ✅ | Redis bağlantı adresi (BullMQ kuyrukları için) |
| `DEMO_MODE` | ✅ | `true` ise tüm sağlayıcılar simüle edilir, gerçek API çağrısı yapılmaz |
| `OPENAI_API_KEY` | Opsiyonel | Şarkı analizi, storyboard, çeviri, YouTube metinleri için |
| `OPENAI_MODEL` | Opsiyonel | Varsayılan: `gpt-4o-mini` |
| `GOOGLE_AI_API_KEY` | Opsiyonel | Google Veo video üretimi için |
| `RUNWAY_API_KEY` | Opsiyonel | Runway video üretimi için |
| `LUMA_API_KEY` | Opsiyonel | Luma video üretimi için |
| `SUNO_API_KEY` | Opsiyonel | Yalnızca isteğe bağlı şarkı üretimi için — **hiçbir zaman zorunlu değildir** |
| `PROJECTS_DIR` | Opsiyonel | Proje dosyalarının saklanacağı dizin (varsayılan: `./projects`) |
| `MAX_UPLOAD_SIZE_MB` | Opsiyonel | Yüklenebilecek maksimum ses dosyası boyutu (varsayılan: 200) |
| `FFMPEG_PATH` / `FFPROBE_PATH` | Opsiyonel | FFmpeg farklı bir yoldaysa belirtin |
| `RATE_LIMIT_WINDOW_MS` / `RATE_LIMIT_MAX` | Opsiyonel | API oran sınırlama ayarları |

Bir sağlayıcının API anahtarı eksikse, uygulama **çökmez** — o sağlayıcıyı seçtiğinizde
"Bu sağlayıcı için API anahtarı eksik" şeklinde net bir Türkçe hata gösterir ve Ayarlar
sayfasında "Eksik" rozeti görürsünüz.

---

## 5. Demo Modu ile Uçtan Uca Doğrulama

`DEMO_MODE=true` iken hiçbir API anahtarı olmadan tüm iş akışını test edebilirsiniz:

1. Yeni Proje → bir MP3/WAV/FLAC yükleyin
2. Şarkı sözlerini girin
3. Video stilini ve karakterleri tanımlayın
4. Video ayarlarını seçin (sağlayıcı: **Demo Modu**)
5. "Şarkı Analizi" sekmesinden analizi çalıştırın (Demo LLM sağlayıcısı kullanılır)
6. "Sahne Planı" sekmesinden storyboard oluşturun ve onaylayın
7. "Video Üretimi" sekmesinden tüm sahneleri üretin — Demo video sağlayıcısı, her sahne
   için gerçek, oynatılabilir bir MP4 klip üretir (FFmpeg ile, renkli arka plan + sahne
   metni)
8. Tüm sahneler tamamlanınca "Final Videoyu Oluştur" düğmesine basın — FFmpeg sahneleri
   birleştirir ve **orijinal şarkınızı** final sesi olarak kullanır
9. Altyazılar, Thumbnail ve Yayın Planlayıcı sekmeleri otomatik doldurulur
10. "Çıktılar" sekmesinden `final.mp4` dosyasının sunucudaki konumunu görürsünüz
    (`projects/<proje-slug>/output/final.mp4`)

Bu akışın çekirdek FFmpeg komut dizisi (renkli sahne üretimi → birleştirme → şarkı ile
mux etme) bu proje geliştirilirken bağımsız olarak test edilmiş ve doğrulanmıştır.

---

## 6. Gerçek Sağlayıcılara Geçiş

1. `.env` dosyasında `DEMO_MODE=false` yapın
2. İlgili API anahtarını girin (örn. `OPENAI_API_KEY`, `GOOGLE_AI_API_KEY`)
3. Ayarlar sayfasında sağlayıcının "Bağlı" göründüğünü doğrulayın
4. **Önemli:** `src/providers/video/veo-provider.ts`, `runway-provider.ts`,
   `luma-provider.ts` dosyalarındaki uç noktalar ve istek gövdeleri, bu sağlayıcıların
   API'lerinin makul bir yaklaşımıyla yazılmıştır ancak **prodüksiyona almadan önce
   ilgili sağlayıcının güncel API dokümantasyonuyla karşılaştırıp doğrulamanız
   gerekir** — video üretim API'leri sürüm değiştirebilir.
5. Yeni bir proje oluşturup Video Ayarları adımında ilgili sağlayıcıyı seçin.

---

## 7. Testler

```bash
npm run test        # Vitest ile birim testleri
npm run typecheck    # TypeScript tip kontrolü
```

Testler; slug üretimi, path-traversal koruması, storyboard şema doğrulaması, Demo LLM
sağlayıcısı ve görsel tutarlılık (Visual Bible) birleştirme mantığını kapsar.

---

## 8. Sürdürme / İşletim Notları

- **Yeniden başlatma sonrası devam etme:** BullMQ + Redis, tamamlanmamış işleri kalıcı
  tutar; VPS yeniden başlarsa tamamlanan sahneler tekrar üretilmez, kuyruktaki işler
  worker yeniden başladığında devam eder.
- **Loglar:** `pm2 logs csms-web` ve `pm2 logs csms-worker`
- **Veritabanı yedekleme:** `docker exec -t <postgres-container> pg_dump -U studio_user cocuk_sarki_studio > yedek.sql`
- **Depolama temizliği:** `projects/<slug>/scenes/` dizini büyüyebilir; tamamlanan
  projelerin ham sahne dosyalarını arşivlemeyi düşünün.
- **Açık Mod / güvenlik uyarısı:** Bu sürümde giriş ekranı yoktur — sunucuya erişebilen
  herkes panele erişebilir. Bu nedenle uygulamayı **doğrudan internete açık bırakmayın**;
  ya sadece güvenilir bir ağdan (VPN, SSH tüneli) erişilebilir tutun ya da Nginx
  seviyesinde HTTP Basic Auth ekleyin (`sudo apt install apache2-utils && htpasswd -c
  /etc/nginx/.htpasswd kullanici`, ardından `deploy/nginx.conf.example` içindeki
  `location /` bloğuna `auth_basic "Stüdyo"; auth_basic_user_file /etc/nginx/.htpasswd;`
  satırlarını ekleyin).
- **Çoklu kullanıcı / hesap tabanlı girişe dönüş:** Tüm işlemler tek bir "Yerel
  Kullanıcı" (`src/lib/auth.ts`) üzerinden yürütülür. Gerçek e-posta/parola girişi veya
  çok kullanıcılı bir kuruluma geçmek isterseniz `src/lib/auth.ts`'i NextAuth.js ile
  değiştirmeniz önerilir (veritabanı `User` modeli buna zaten hazırdır: passwordHash,
  role vb. alanlar mevcuttur).

---

## 9. Bilinen Sınırlamalar (şeffaf olmak adına)

- Gerçek video sağlayıcı adaptörleri (Veo/Runway/Luma), sağlayıcıların genel API
  desenlerine göre yazılmıştır; ilk gerçek kullanımdan önce doğrulama gerektirir.
- Kelime bazlı kesin altyazı zamanlaması (forced alignment) dahil değildir; satır
  bazlı, sahne sürelerine orantılı bir zamanlama kullanılır. Daha hassas zamanlama için
  bir konuşma-metin hizalama servisi (örn. WhisperX) entegre edilebilir.
- Çok kullanıcılı/kurumsal kimlik doğrulama (SSO, roller, davetler) temel düzeydedir.
- Maliyet tahmini (§10), sağlayıcı fiyatlandırması genel olarak yayınlanmadığından
  yalnızca Demo Modu için tam doğrudur; gerçek sağlayıcılar için kendi fiyat
  tablonuzu `estimateGenerationCost()` içine eklemeniz gerekir.
